import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import * as moment from 'moment';
import { ConsentService } from '../services/consent.service';
import { ScrollerService } from '../services/scroller-service.service';
import { ToasterService } from '../services/toaster.service';
import { WorkflowService } from '../services/workflow.service';
import { SortingType } from '../shared/enums/sorting-type';
import { ListModel } from '../shared/models/list-model';
import { Response } from '../shared/models/response';
import { SearchFilter } from '../shared/models/search-filter';

@Component({
  selector: 'app-consents',
  templateUrl: './consents.component.html',
  styleUrls: ['./consents.component.scss'],
  providers: [ConsentService]
})
export class ConsentsComponent implements OnInit {

  consent:boolean;
  consentsuccess:boolean;
  communiction:boolean;
  channelSelected: boolean;

  constructor(public consentService: ConsentService, private toast: ToasterService, private route: ActivatedRoute) {

  }

  ngOnInit() {
    this.route.queryParams.subscribe(params => {
      if(params?.uuid) {
        this.consentService.getUserDetails(params.uuid);
      }
    })
    this.communiction = true;
    this.consentsuccess = false;
    this.channelSelected = false;
  }

  authenticatefun(user, form){
    this.consentService.submitConsent(user).subscribe(res=> {
      if(!res?.isError) {
        this.consentsuccess = true;
      } else {
        this.toast.showErrorMessage(res?.message)
      }
    });
  }

  channelSelection(channels) {
    this.channelSelected = channels.reduce(( pre, cur) => (pre || cur.selected), false);
  }
}
