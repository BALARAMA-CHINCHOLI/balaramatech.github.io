import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ConsentsComponent } from './consents.component';
import { ConsentsRoutingModule } from './consents-routing.module';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    ConsentsRoutingModule
  ],
  declarations: [ConsentsComponent]
})
export class ConsentsModule { }
