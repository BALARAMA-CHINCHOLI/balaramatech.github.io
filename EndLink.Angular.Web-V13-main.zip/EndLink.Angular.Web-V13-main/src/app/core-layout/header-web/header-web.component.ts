import { Component, HostListener, OnInit } from '@angular/core';
import {
  Directive,
  ViewChild ,
  ElementRef,Renderer2 ,
} from '@angular/core';

import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { LandingPageService } from 'src/app/services/landing-page.service';
import { LoaderService } from 'src/app/services/loader.service';
import { User } from 'src/app/shared/models/user';
import { LoginthemeService } from '../../services/logintheme.services';
import { loginTheme } from '../../shared/models/login-theme';
import { Response } from 'src/app/shared/models/response';
import { NotificationService } from 'src/app/services/notification.service';
import { SearchFilter } from 'src/app/shared/models/search-filter';
import { SortingType } from 'src/app/shared/enums/sorting-type';
import { Notification } from 'src/app/shared/models/notification';
import { NotificationType } from 'src/app/shared/enums/notification-type';
import { paths } from 'src/app/shared/constants';
//import { ThemeService } from '../theme/theme.service';
// import { ThemeService } from '../../theme/theme.service';
declare var $: any;

@Component({
  selector: 'app-header-web',
  templateUrl: './header-web.component.html',
  styleUrls: ['./header-web.component.scss'],
})
export class HeaderWebComponent implements OnInit {
  model: loginTheme = new loginTheme();
  isExpanded: boolean = true;
  prevItem: any;
  user: User = null;
  isUserAvail = '';
  navMode = 'side';
  currentobj: any;
  themeId: number;
  selectedtheme: loginTheme = { "ThemeId": 0 };
  lighttheme: boolean = true;
  darktheme: boolean;
  notify: boolean = false;

  notifications: Notification[] = [];
  notificationsCount: string = '';


  @ViewChild('notifywrapper') notifywrapper: ElementRef;


  onScrollDown() {
  }

  onUp() {
  }

  selectedValue: string;

  themestypes: any[] = [
    { value: 1, viewValue: "Light" },
    { value: 2, viewValue: "Dark" },

  ];

  menu = [];

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    if (window.innerWidth < 760) {
      this.navMode = 'over';
    } else {
      this.navMode = 'side';
    }
  }

  constructor(
    public loader: LoaderService,
    private auth: AuthenticationService,
    private landing: LandingPageService,
    private router: Router,
    private theme: LoginthemeService,
    private notificationService: NotificationService,
    private renderer: Renderer2
  ) { 

    this.renderer.listen('window', 'click',(e:Event)=>{
    
     if(e.target !== this.notifywrapper.nativeElement){
         this.notify=false;
     }
 });
 
  }

  ngOnInit() {
    this.auth.currentUser.subscribe((user) => {
      this.user = user;

      if (this.user) {
        this.loadNotifications();
      }
    });
    this.landing.menus.subscribe((data: any) => {
      this.menu = data;
    });


    this.currentobj = localStorage.getItem("endlink.currentUser")
    if (this.currentobj) {
      const obj = JSON.parse(this.currentobj);
      this.themeId = obj.themeId
      if (this.themeId != null) {
        if (this.themeId == 2) {
          document.body.classList.add("darkMode");
          this.lighttheme = true;
          this.darktheme = false;
        }
        else {
          document.body.classList.remove("darkMode");
          this.lighttheme = false;
          this.darktheme = true;
        }
      }
      else {
        document.body.classList.remove("darkMode");
        this.lighttheme = false;
        this.darktheme = true;
      }
    } else {
      this.lighttheme = false;
      this.darktheme = true;
    }

  }

  loadNotifications() {
    this.notifications = [];
    this.notificationsCount = '';
    this.notificationService.list$.subscribe((notifications: Notification[]) => {
      this.notifications = notifications;

      if (this.notifications && this.notifications.length > 0) {
        this.notificationsCount = this.notifications.length.toString();
      } else {
        this.notificationsCount = '';
      }
    });

    this.notificationService.load();
  }

  toggleNotifications() {
    this.notify = !this.notify;

    if (this.notify && this.notifications.length > 0) {
      this.notificationService.markAsRead().subscribe(() => {
        this.notificationsCount = '';
      });
    }
  }

  notificationRedirect(item: Notification) {
    switch (item.notificationType) {
      case NotificationType.Approval:
        this.router.navigateByUrl(paths.approvalView + item.referenceId);
        break;
      case NotificationType.BusinessUnit:
        this.router.navigateByUrl(paths.businessDetails + item.referenceId);
        break;
      case NotificationType.Campaign:
        this.router.navigateByUrl(paths.campaignView + item.referenceId);
        break;
      case NotificationType.Workflow:
        this.router.navigateByUrl(paths.workflowView + item.referenceId);
        break;
    }
  }

  themes(event) {
    this.model.ThemeId = event;
    this.theme.update(this.model).subscribe((response: Response) => {
      if (this.model.ThemeId == 2) {
        document.body.classList.add("darkMode");
        var selthm = JSON.parse(localStorage.getItem("endlink.currentUser"));
        selthm.themeId = event;
        window.localStorage.setItem("endlink.currentUser", JSON.stringify(selthm));
        this.lighttheme = true;
        this.darktheme = false;
      }
      else {
        document.body.classList.remove("darkMode");
        this.lighttheme = false;
        this.darktheme = true;
        var selthm = JSON.parse(localStorage.getItem("endlink.currentUser"));
        selthm.themeId = event;

        window.localStorage.setItem("endlink.currentUser", JSON.stringify(selthm));

      }
    });
  }

  logout() {
    this.auth.logout();
    this.router.navigate(['/auth']);
  }

  getAlias() {
    if (!this.user) {
      return '';
    }

    return this.user.name.substring(0, 1);
  }

  menuExpand(item) {
    if (this.prevItem?.name != item.name && !!this.prevItem?.children) {
      let isItemAvail = this.prevItem.children.findIndex((menu) => {
        if (menu.name == item.name) {
          return true;
        } else if (!!menu.children) {
          return !!menu.children.find((submenu) => submenu.name == item.name);
        }
        return false;
      });
      if (isItemAvail == -1) {
        this.prevItem.isExpanded = false;
      }
    }
    if (item.icon) {
      this.prevItem = item;
    }
    item.isExpanded = !item.isExpanded;
  }
}
