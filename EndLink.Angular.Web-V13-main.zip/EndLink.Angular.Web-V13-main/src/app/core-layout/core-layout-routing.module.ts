import { AuthLoadGuard } from './../auth/auth-load.guard';
import { AuthGuard } from 'src/app/shared/helpers/auth.guard';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { CoreComponent } from './core.component';

const routes: Routes = [
  {
    path: '',
    component: CoreComponent,
    children: [
      {
        path: 'settings',
        loadChildren: () =>
          import('../settings/settings.module').then((m) => m.SettingsModule),
        data: { breadcrumb: 'Settings' },
        canLoad: [AuthLoadGuard],
      },
      {
        path: 'comunity',
        loadChildren: () =>
          import('../comunity/comunity.module').then((m) => m.ComunityModule),
        data: { breadcrumb: 'Community' },
        canLoad: [AuthLoadGuard],
      },
      {
        path: 'campaign',
        loadChildren: () =>
          import('../campaign/campaign.module').then((m) => m.CampaignModule),
        data: {
          breadcrumb: 'Campaigns',
          url: '/campaign',
          title: 'Campaign List',
        },
        canLoad: [AuthLoadGuard],
      },
      {
        path: 'auth',
        loadChildren: () =>
          import('../auth/auth.module').then((m) => m.AuthModule),
      },
      {
        path: 'dashboard',
        loadChildren: () =>
          import('../dashboard/dashboard.module').then(
            (m) => m.DashboardModule
          ),
        canLoad: [AuthLoadGuard],
        data: { title: '' }
      },
      {
        path: 'report',
        loadChildren: () =>
          import('../reports/reports.module').then(
            (m) => m.ReportsModule
          ),
        data: {
          breadcrumb: 'Reports',
          title: 'Reports',
        },
        canLoad: [AuthLoadGuard],
      },

      {
        path: 'profile',
        loadChildren: () =>
          import('../profiles/profiles.module').then(
            (m) => m.ProfilesModule
          ),
        data: {
          breadcrumb: 'Profile',
          title: 'Profile',
        },
        canLoad: [AuthLoadGuard],
      },
      {
        path: 'consent',
        loadChildren: () =>
          import('../consents/consents.module').then(
            (m) => m.ConsentsModule
          ),
      },
      {
        path: 'unauthorised',
        loadChildren: () =>
          import('../unauthorised/unauthorised.module').then(
            (m) => m.UnauthorisedModule
          ),
      },
      {
        path: 'workflow',
        loadChildren: () =>
          import('../workflow/workflow.module').then((m) => m.WorkflowModule),
        data: {
          breadcrumb: 'Workflows',
          title: 'Workflows List',
        },
        canLoad: [AuthLoadGuard],
      },
      {
        path: 'mediaLibrary',
        loadChildren: () =>
          import('../media-library/media-library.module').then(
            (m) => m.MediaLibraryModule
          ),
        data: {
          breadcrumb: 'Media Library',
        },
        canLoad: [AuthLoadGuard],
      },
      {
        path: 'users',
        loadChildren: () =>
          import('../users/users.module').then((m) => m.UsersModule),
        data: {
          breadcrumb: 'Manage Users',
        },
        canLoad: [AuthLoadGuard],
      },
      {
        path: 'approvals',
        loadChildren: () => import('../settings/approvals/approvals.module').then(m => m.ApprovalsModule),
        data: {
          breadcrumb: 'Approvals',
          url: 'approvals',
          title: 'Approvals'
        },
        canLoad: [AuthLoadGuard],
      },
      {
        path: 'notfound',
        loadChildren: () => import('../../app/notfound/notfound.module').then(m => m.NotfoundModule)
      },
      {
        path: '',
        redirectTo: 'dashboard'
      },
      {
        path: '**',
        redirectTo: 'notfound'
      }
      // {
      //   path: 'workflow',
      //   loadChildren: () => import('../workflow/workflow.module').then(m => m.WorkflowModule)
      // }
    ],
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CoreLayoutRoutingModule { }
