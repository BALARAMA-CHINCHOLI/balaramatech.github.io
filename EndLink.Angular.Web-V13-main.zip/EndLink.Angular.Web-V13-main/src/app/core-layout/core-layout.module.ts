import { AuthLoadGuard } from './../auth/auth-load.guard';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CoreLayoutRoutingModule } from './core-layout-routing.module';
import { CoreComponent } from './core.component';
import { SharedModule } from '../shared/shared.module';
import { BreadcrumbComponent } from '../shared/components/breadcrumb/breadcrumb.component';
import { HeaderWebComponent } from './header-web/header-web.component';
import { HeaderMobileComponent } from './header-mobile/header-mobile.component';
import { FooterComponent } from './footer/footer.component';
import { FooterMobileComponent } from './footer-mobile/footer-mobile.component';
import { InfiniteScrollerDirective } from '../shared/directives/infinite-scroller.directive';
import {ScrollingModule} from '@angular/cdk/scrolling';

import { ThemeModule } from '../theme/theme.module';
import { lightTheme } from '../theme/light-theme';
import { darkTheme } from '../theme/dark-theme';

@NgModule({
  declarations: [CoreComponent, BreadcrumbComponent, HeaderWebComponent, HeaderMobileComponent, FooterComponent,
     FooterMobileComponent,
     InfiniteScrollerDirective
    ],
  imports: [
    CommonModule,
    CoreLayoutRoutingModule,
    SharedModule,
    ScrollingModule,
    ThemeModule.forRoot({
      themes: [lightTheme, darkTheme],
      active: 'light'
    }),
  ],
  providers: [AuthLoadGuard]
})
export class CoreLayoutModule { }
