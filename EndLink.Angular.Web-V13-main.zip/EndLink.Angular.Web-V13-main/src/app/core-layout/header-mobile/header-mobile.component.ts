import { Component, HostListener, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { BreadcrumbService } from 'src/app/services/breadcrumb.service';
import { LoaderService } from 'src/app/services/loader.service';
import { User } from 'src/app/shared/models/user';

@Component({
  selector: 'app-header-mobile',
  templateUrl: './header-mobile.component.html',
  styleUrls: ['./header-mobile.component.scss']
})
export class HeaderMobileComponent implements OnInit {
  isExpanded :boolean = true;
  prevItem:any;
  user: User = null;
  isUserAvail = '';
  navMode = 'side';
  currentPage = '';
  menu=[{
    name:"Home",icon:'home',routeLink:'/settings',isLink:true,isActive:true,isExpanded:false
  },
  {
    name: "Community", children: [
      {
        name: "Members", children: [
          {
            name: "Patients", routeLink: '/comunity/members', isLink: true, isActive: false, isExpanded: false
          },
          {
            name: "Employees", routeLink: '/comunity/members/employee', isLink: true, isActive: false, isExpanded: false
          },
          // {
          //   name: "Caregivers", routeLink: '/comunity/members/caregivers', isLink: true, isActive: false, isExpanded: false
          // }
        ],
        isLink: false, isActive: false, isExpanded: false
      },
      {
        name: "Group", routeLink: '/comunity/groups', isLink: true, isActive: true, isExpanded: false
      }
    ],
    icon: 'people', isLink: false, isActive: false, isExpanded: false,
  },
  {
    name: "Campaign", icon: 'chat_bubble_outline', routeLink: '/campaign', isLink: true, isActive: true, isExpanded: false
  },
  {
    name: "Workflows", icon: 'work', routeLink: '/settings', isLink: true, isActive: true, isExpanded: false
  },

  {
    name: "Media Library", children: [
      {
        name: "Audio", routeLink: '/settings', isLink: true, isActive: true, isExpanded: false
      },
      {
        name: "Html", routeLink: '/settings', isLink: true, isActive: true, isExpanded: false
      },
    ], icon: 'perm_media', isLink: false, isActive: false, isExpanded: false
  },
  {
    name: "Settings", children: [
      {
        name: "Locations", routeLink: '/settings', isLink: true, isActive: true, isExpanded: false
      },
      {
        name: "Appointment Types", routeLink: '/settings/appointment', isLink: true, isActive: true, isExpanded: false
      },
      {
        name: "Resources", routeLink: '/settings/resource', isLink: true, isActive: true, isExpanded: false
      },
      {
        name: "Business Unit", routeLink: '/settings/business', isLink: true, isActive: true, isExpanded: false
      }
    ], icon: 'settings', isLink: false, isActive: false, isExpanded: false
  },
  {
    name: "Reports", icon: 'bar_chart', routeLink: '/settings', isLink: true, isActive: true, isExpanded: false
  },]

  @HostListener('window:resize', ['$event'])
  onResize(event) {
    if(window.innerWidth < 760) {
      this.navMode = 'over'
    } else {
      this.navMode = 'side'
    }
  }
  title = '';
  isSinglePage = false;
  @ViewChild('drawer') drawer;

  constructor(public loader: LoaderService, private auth: AuthenticationService, 
    private breadcrumb : BreadcrumbService, private router: Router) { }

  ngOnInit() {    
    this.breadcrumb.currentData.subscribe((data:any) => {
      this.title = data.title;
      this.isSinglePage = data.isSinglePage;
    })
    this.auth.currentUser.subscribe(user => {
      this.user = user;
    });

  }

  onScrollDown() {
  }

  back() {
    window.history.back();
  }

  goTo(link) {
    this.drawer.toggle();
    this.router.navigate([link]);
  }

  getAlias() {
    if (!this.user) {
      return '';
    }

    return this.user.name.substring(0, 1);
  }

  menuExpand(item) {
    // if(this.prevItem)
    // {
    //   this.prevItem.isExpanded=false;

    // }
    // if(item.icon)
    // {
    //   this.prevItem=item;
    // }
    item.isExpanded = !item.isExpanded;

  }
}
