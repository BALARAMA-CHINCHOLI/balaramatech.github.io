import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AppointmentService } from 'src/app/services/dataServices/appointment.service';
import { ScrollerService } from 'src/app/services/scroller-service.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { ConfirmationComponent } from 'src/app/shared/components/confirmation/confirmation.component';
import { messages } from 'src/app/shared/constants';
import { SortingType } from 'src/app/shared/enums/sorting-type';
import { Appointment } from 'src/app/shared/models/appointment';
import { SearchFilter } from 'src/app/shared/models/search-filter';
import { ListModel } from 'src/app/shared/models/list-model';

@Component({
  selector: 'app-Appointment',
  templateUrl: './Appointment.component.html',
  styleUrls: ['./Appointment.component.scss'],
})
export class AppointmentComponent implements OnInit, OnDestroy {
  appointmentFilter: SearchFilter = {
    paging: {
      pageNumber: 1,
      pageSize: 10,
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'Name',
    },
  };

  list: ListModel<Appointment> = {
    list: [],
    hasNextPage: false,
  };

  pageData: any = {
    pageSize: 10,
    currentPage: 1,
    totalItems: 20,
  };
  tableData: any = {
    headerData: [],
    rowData: [],
    noRecordFound: true,
  };

  list$: any;
  scroller$: any;

  constructor(
    private dialog: MatDialog,
    private appointmentService: AppointmentService,
    private toaster: ToasterService,
    private router: Router,
    private scroller: ScrollerService
  ) {}

  ngOnInit() {
    this.getAppointments();
    this.tableData.noRecordFound = true;
    this.tableData.headerData = header_data;

    this.scroller$ = this.scroller.scroller$
      .pipe
      //throttle(ev => this.employeeList$)
      ()
      .subscribe((res) => {
        if (this.list.hasNextPage) {
          this.appointmentFilter.paging.pageNumber++;
          this.getAppointments();
        }
      });
  }

  parseTableData(data) {
    return new Appointment(data);
  }

  getAppointments() {
    this.list$ = this.appointmentService
      .list(this.appointmentFilter)
      .subscribe((data: any) => {
        if (this.appointmentFilter.paging.pageNumber == 1) {
          this.list = data.responseObject;
          this.tableData.rowData = [];
        } else {
          data.responseObject.list.forEach((item) => {
            this.list.list.push(item);
          });
        }

        this.tableData.rowData = this.list.list;

        if (this.list.list.length > 0) {
          this.tableData.noRecordFound = false;
        }
        this.list.hasNextPage =
          data.responseObject.list && data.responseObject.list.length > 0;
      });
  }

  public changeStatus(appointment: Appointment) {
    this.appointmentService.update(appointment).subscribe((res: any) => {
      if (res.isError) {
        this.toaster.showErrorMessage(res.message);
        appointment.isActive = !appointment.isActive;
      }
    });
  }

  tableActions(event) {
    switch (event.action) {
      case 'view': {
        this.appointmentService.selectedAppointment = event.rowData;
        this.router.navigate([
          '/settings/appointment/details/' + event.rowData.id,
        ]);
        break;
      }
      case 'edit': {
        this.appointmentService.selectedAppointment = event.rowData;
        this.router.navigate(
          ['/settings/appointment/edit/' + event.rowData.id],
          { queryParams: { type: 'edit' } }
        );
        break;
      }
      case 'sort': {
        this.appointmentFilter.paging.pageNumber = 1;
        this.appointmentFilter.sorting = {
          order: event.filterData.sortOrder,
          sortBy: event.filterData.sortHeader,
        };

        this.getAppointments();
        break;
      }
      case 'switch': {
        const apptmnt = this.tableData.rowData.find(
          (x) => x.id == event.rowData.id
        );

        if (apptmnt == null) {
          return;
        }
        let statusSwitch = this.dialog.open(ConfirmationComponent, {
          data: {
            message: 'Are you sure you want to change this status?',
            icon: 'warning',
            action: 'Update',
          },
          width: '30vw',
        });
        statusSwitch.afterClosed().subscribe((result) => {
          if (result) {
            this.changeStatus(apptmnt);
          } else {
            event.rowData.isActive = !event.rowData.isActive;
          }
        });
        break;
      }
      case 'search': {
        this.appointmentFilter.SearchText = event.filterData.globalSearch;
        this.appointmentFilter.paging.pageNumber = 1;
        this.getAppointments();
        break;
      }
      case 'clear': {
        this.appointmentFilter.SearchText = '';
        this.appointmentFilter.paging.pageNumber = 1;
        this.getAppointments();
        break;
      }
    }
  }

  public ngOnDestroy() {
    this.list$.unsubscribe();
    this.scroller$.unsubscribe();
  }
}

export const header_data: any[] = [
  {
    title: 'Name',
    type: 'text',
    prop: 'name',
    sort: true,
    isFilter: true,
    isAsc: false,
    isDes: false,
  },
  {
    title: 'Code',
    type: 'text',
    prop: 'code',
    sort: true,
    isFilter: true,
    isAsc: false,
    isDes: false,
  },
  {
    title: 'Description',
    type: 'text',
    prop: 'description',
    sort: true,
    isFilter: true,
    isAsc: false,
    isDes: false,
  },
  {
    title: 'Status',
    type: 'slide',
    prop: 'isActive',
    sort: false,
    isFilter: false,
  },
];
