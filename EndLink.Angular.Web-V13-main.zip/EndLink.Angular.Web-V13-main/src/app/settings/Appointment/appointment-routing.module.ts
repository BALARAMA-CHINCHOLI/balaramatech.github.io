import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddAppointmentComponent } from './add-appointment/add-appointment.component';
import { AppointmentComponent } from './Appointment.component';

const routes: Routes = [
  {
    path : '',
    pathMatch: 'full',
    component: AppointmentComponent
  },
  {
    path : 'addAppointment',
    component: AddAppointmentComponent,
    data: { breadcrumb: 'Add Appointment Type', title: 'Add Appointment Type', isSinglePage: true }
  },
  {
    path: 'details/:id',
    component: AddAppointmentComponent,
    data: { breadcrumb: 'View Appointment Type', title: 'View Appointment Type', isSinglePage: true }
  },
  {
    path: 'edit/:id',
    component: AddAppointmentComponent,
    data: { breadcrumb: 'Edit Appointment Type', title: 'Edit Appointment Type', isSinglePage: true }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AppointmentRoutingModule { }
