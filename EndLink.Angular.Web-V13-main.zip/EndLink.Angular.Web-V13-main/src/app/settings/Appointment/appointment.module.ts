import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AppointmentRoutingModule } from './appointment-routing.module';
import { AppointmentComponent } from './Appointment.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { AddAppointmentComponent } from './add-appointment/add-appointment.component';
import { FormsModule } from '@angular/forms';


@NgModule({
  declarations: [AppointmentComponent, AddAppointmentComponent],
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    AppointmentRoutingModule
  ]
})
export class AppointmentModule { }
