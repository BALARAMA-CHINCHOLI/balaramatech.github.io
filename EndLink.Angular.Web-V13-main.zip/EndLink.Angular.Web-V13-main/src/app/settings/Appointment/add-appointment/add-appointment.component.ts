import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { isEmpty } from 'rxjs/operators';
import { AppointmentService } from 'src/app/services/dataServices/appointment.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { SuccessPopupComponent } from 'src/app/shared/components/success-popup/success-popup.component';
import { Appointment } from 'src/app/shared/models/appointment';

@Component({
  selector: 'app-add-appointment',
  templateUrl: './add-appointment.component.html',
  styleUrls: ['./add-appointment.component.scss']
})
export class AddAppointmentComponent implements OnInit {
  submitted: boolean = false;

  isUpdate:boolean = false;
  isDisabled:boolean = false;
  formValues:Appointment = new Appointment({
    name: '',
    code: '',
    description: ''
  });
  clist: any;
  id: any;
  name: boolean;
  desc: boolean;
  code1: boolean;
  constructor(private route: ActivatedRoute, private appointmentService: AppointmentService,
    private dialog: MatDialog, private router: Router, private toastr: ToasterService) { }

  ngOnInit(): void {
    this.route.params.subscribe(param => {
      if(!!param?.id) {
        this.isUpdate = true;
        if(!!!this.appointmentService.selectedAppointment) {
          this.appointmentService.getAppiontment(param.id).subscribe((res:any)=> {
            if(!res.isError) {
              this.formValues = res.responseObject;
            } else {
              this.toastr.showErrorMessage(res.message);
            }
          })
        } else {
          this.formValues = this.appointmentService.selectedAppointment;
        }
        this.isDisabled = (this.route.snapshot.url.join().split(',')[0] != 'edit');
      }
     
    });

  }
  // space(event:any){
  //    if(event.target.selectionStart === 0 && event.code === "Space"){
  //     event.preventDefault();
  // }
  // }
  space(event){
    // this.formValues.name=this.formValues.name.replace(/^\s+|\s+$/g, '');
    // this.formValues.code=this.formValues.code.replace(/^\s+|\s+$/g, '');
    // this.formValues.description=this.formValues.description.replace(/^\s+|\s+$/g, '')
    this.formValues.name=this.formValues.name?.trim();
    this.formValues.code=this.formValues.code?.trim();
    this.formValues.description=this.formValues.description?.trim()
      switch (this.id) {
        case '1': {
          if (this.formValues.name.length==null) {
            this.name = false
  
          }
          else {
            this.name = true
          }
        }
          break;
        case '2': {
          
            if (this.formValues.code.length==null) {
              this.code1 = false
    
            }
            else {
              this.code1 = true
            }
          }
          break;
          case '3': {
          
            if (this.formValues.description.length==null) {
              this.desc = false
    
            }
            else {
              this.desc = true
            }
          }
          break;  
        }
      }
  submit(isValid) {
    if(isValid) {
      this.submitted=false;
      if(this.isUpdate) {
        if(isValid) {
          this.submitted=true; 
          this.appointmentService.update(this.formValues).subscribe((res:any)=>{
          this.submitted=false;
          if(!res.isError) {
            let successDialog = this.dialog.open(SuccessPopupComponent, {data: {successMessage: 'Appointment Type updated successfully'}});
            successDialog.afterClosed().subscribe(res=> this.router.navigate(['/settings/appointment']))
          } 
        
          else {
            this.toastr.showErrorMessage(res.message);
          }
        
          });
      
      }  } else {
        this.submitted=true;
        this.appointmentService.create(this.formValues).subscribe((res:any)=>{
          this.submitted=false;
          if(!res.isError) {
            let successDialog = this.dialog.open(SuccessPopupComponent, {data: {successMessage: 'Appointment Type added successfully'}});
            successDialog.afterClosed().subscribe(res=> this.router.navigate(['/settings/appointment']))
          }else {
            this.toastr.showErrorMessage(res.message);
          }
        });
      }
    }
  }

  back() {
    window.history.back();
  }

  ngOnDestroy() {
    this.appointmentService.selectedAppointment = null;
  }

}
