import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AppointmentComponent } from './Appointment/Appointment.component';
import { BusinessUnitComponent } from './businessUnit/businessUnit.component';
import { LocationComponent } from './location/location.component';
import { ResourcesComponent } from './resources/resources.component';
import { OrganizationComponent } from './organization/organization.component';




const routes: Routes = [
  {
    path : '',
    children: [
      {
        path: 'location',
        loadChildren: () => import('./location/location.module').then(m => m.LocationModule),
        data: {
          breadcrumb: 'Locations',
          url : 'settings/location',
          title: 'Locations'
        }
      },
      {
        path: 'appointment',
        loadChildren: () => import('./Appointment/appointment.module').then(m => m.AppointmentModule),
        data: {
          breadcrumb: 'Appointment Types',
          url : 'settings/appointment',
          title: 'Appointment Types'
        }
      },
      {
        path: 'resource',
        loadChildren: () => import('./resources/resources.module').then(m => m.ResourcesModule),
        data: {
          breadcrumb: 'Resources',
          url : 'settings/resource',
          title: 'Resources'
        }
      },
      {
        path: 'business',
        loadChildren: () => import('./businessUnit/business-unit.module').then(m => m.BusinessUnitModule),
        data: {
          breadcrumb: 'Business Units',
          url : 'settings/business',
          title: 'Business Units'
        }
      },
      {
        path: 'eventTypes',
        loadChildren: () => import('./event-type/event-type.module').then(m => m.EventTypeModule),
        data: {
          breadcrumb: 'Data Source',
          url : 'settings/eventTypes',
          title: 'Data Source'
        }
      },
      {
        path: 'organization',
        loadChildren: () => import('./organization/organization.module').then(m => m.OrganizationModule),
        data: {
          breadcrumb: 'Organization',
          url: 'settings/organization',
          title: 'Organization'
        }
      },
      {
        path: 'provider',
        loadChildren: () => import('./provider/provider.module').then(m => m.ProviderModule),
        data: {
          breadcrumb: 'Entity',
          url: 'settings/provider',
          title: 'Entity'
        }
      },
      
      {
        path: 'rules',
        loadChildren: () => import('./rules/rules.module').then(m => m.RulesModule),
        data: {
          breadcrumb: 'Rules',
          url: 'settings/rules',
          title: 'Rules'
        }
      },
      { path: '',   redirectTo: 'location', pathMatch: 'full' }
    ]
  },
  {path: '**', redirectTo: 'notfound'}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class SettingsRoutingModule { }
