import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddBusinessComponent } from './add-business/add-business.component';
import { BusinessUnitComponent } from './businessUnit.component';

const routes: Routes = [
  {
    path : '',
    pathMatch: 'full',
    component: BusinessUnitComponent
  },
  {
    path : 'addBusiness',
    component: AddBusinessComponent,
    data: { breadcrumb: 'Add Business Unit', title: 'Add Business Unit', isSinglePage: true }
  }, 
  {
    path: 'details/:id',
    component: AddBusinessComponent,
    data: { breadcrumb: 'View Business Unit', title: 'View Business Unit', isSinglePage: true }
  },
  {
    path: 'edit/:id',
    component: AddBusinessComponent,
    data: { breadcrumb: 'Edit Business Unit', title: 'Edit Business Unit', isSinglePage: true }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class BusinessUnitRoutingModule { }
