import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { BusinessUnitRoutingModule } from './business-unit-routing.module';
import { AddBusinessComponent } from './add-business/add-business.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { BusinessUnitComponent } from './businessUnit.component';


@NgModule({
  declarations: [BusinessUnitComponent, AddBusinessComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    BusinessUnitRoutingModule
  ]
})
export class BusinessUnitModule { }
