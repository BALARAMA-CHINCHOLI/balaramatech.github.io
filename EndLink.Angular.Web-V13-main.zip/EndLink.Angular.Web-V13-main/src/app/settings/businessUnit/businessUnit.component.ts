import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { BusinessUnitService } from 'src/app/services/dataServices/business-unit.service';
import { ScrollerService } from 'src/app/services/scroller-service.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { ConfirmationComponent } from 'src/app/shared/components/confirmation/confirmation.component';
import { messages } from 'src/app/shared/constants';
import { SortingType } from 'src/app/shared/enums/sorting-type';
import { BusinessUnit } from 'src/app/shared/models/business-unit';
import { ListModel } from 'src/app/shared/models/list-model';
import { SearchFilter } from 'src/app/shared/models/search-filter';

@Component({
  selector: 'app-businessUnit',
  templateUrl: './businessUnit.component.html',
  styleUrls: ['./businessUnit.component.scss'],
})
export class BusinessUnitComponent implements OnInit, OnDestroy {
  bUnitFilter: SearchFilter = {
    paging: {
      pageNumber: 1,
      pageSize: 10,
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'Name',
    },
  };

  list: ListModel<BusinessUnit> = {
    list: [],
    hasNextPage: false,
  };

  pageData: any = {
    pageSize: 10,
    currentPage: 1,
    totalItems: 20,
  };
  tableData: any = {
    headerData: [],
    rowData: [],
    noRecordFound: true,
  };

  list$: any;
  scroller$: any;

  constructor(
    private dialog: MatDialog,
    private businessUnitService: BusinessUnitService,
    private toaster: ToasterService,
    private router: Router,
    private scroller: ScrollerService
  ) {}

  ngOnInit() {
    this.getBUnits();
    this.tableData.noRecordFound = true;
    this.tableData.headerData = header_data;

    this.scroller$ = this.scroller.scroller$.subscribe((res) => {
      if (this.list.hasNextPage) {
        this.bUnitFilter.paging.pageNumber++;
        this.getBUnits();
      }
    });
  }

  parseTableData(data) {
    return new BusinessUnit(data);
  }

  getBUnits() {
    this.list$ = this.businessUnitService
      .list(this.bUnitFilter)
      .subscribe((data: any) => {
        if (this.bUnitFilter.paging.pageNumber == 1) {
          this.list = data.responseObject;
          this.tableData.rowData = [];
        } else {
          data.responseObject.list.forEach((item) => {
            this.list.list.push(item);
          });
        }

        this.tableData.rowData = this.list.list;

        if (this.list.list.length > 0) {
          this.tableData.noRecordFound = false;
        }
        this.list.hasNextPage =
          data.responseObject.list && data.responseObject.list.length > 0;
      });
  }

  public changeStatus(businessUnit: BusinessUnit) {
    this.businessUnitService.statusUpdate(businessUnit).subscribe((res: any) => {
      if (res.isError) {
        this.toaster.showErrorMessage(res.message);
        businessUnit.isActive = !businessUnit.isActive;
      }
    });
  }

  tableActions(event) {
    switch (event.action) {
      case 'view': {
        this.businessUnitService.selectedbusinessUnit = event.rowData;
        this.router.navigate([
          '/settings/business/details/' + event.rowData.id,
        ]);
        break;
      }
      case 'edit': {
        this.businessUnitService.selectedbusinessUnit = event.rowData;
        this.router.navigate(['/settings/business/edit/' + event.rowData.id], {
          queryParams: { type: 'edit' },
        });
        break;
      }
      case 'sort': {
        this.bUnitFilter.paging.pageNumber = 1;
        this.bUnitFilter.sorting = {
          order: event.filterData.sortOrder,
          sortBy: event.filterData.sortHeader,
        };

        this.getBUnits();
        break;
      }
      case 'switch': {
        const businessUnit = this.list.list.find(
          (x) => x.id == event.rowData.id
        );

        if (businessUnit == null) {
          return;
        }

        let statusSwitch = this.dialog.open(ConfirmationComponent, {
          data: {
            message: 'Are you sure you want to change this status?',
            icon: 'warning',
            action: 'Update',
          },
          width: '30vw',
        });
        statusSwitch.afterClosed().subscribe((result) => {
          if (result) {
            this.changeStatus(businessUnit);
          } else {
            event.rowData.isActive = !event.rowData.isActive;
          }
        });
        break;
      }
      case 'search': {
        this.bUnitFilter.SearchText = event.filterData.globalSearch;
        this.bUnitFilter.paging.pageNumber = 1;
        this.getBUnits();
        break;
      }
      case 'clear': {
        this.bUnitFilter.SearchText = '';
        this.bUnitFilter.paging.pageNumber = 1;
        this.getBUnits();
        break;
      }
    }
  }

  public ngOnDestroy() {
    this.list$.unsubscribe();
    this.scroller$.unsubscribe();
  }
}

export const header_data: any[] = [
  {
    title: 'Name',
    type: 'text',
    prop: 'name',
    sort: true,
    isFilter: true,
    isAsc: false,
    isDes: false,
  },
  {
    title: 'Description',
    type: 'text',
    prop: 'description',
    sort: true,
    isFilter: true,
    isAsc: false,
    isDes: false,
  },
  {
    title: 'Status',
    type: 'slide',
    prop: 'isActive',
    sort: false,
    isFilter: false,
  },
];
