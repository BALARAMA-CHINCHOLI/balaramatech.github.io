import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { BusinessUnitService } from 'src/app/services/dataServices/business-unit.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { BusinessUnit } from 'src/app/shared/models/business-unit';
import { SuccessPopupComponent } from '../../../shared/components/success-popup/success-popup.component';
import * as $ from 'jquery';
import { MinLengthValidator } from '@angular/forms';
import { BreakpointObserver } from '@angular/cdk/layout';

export class MyService {

}
@Component({
  selector: 'app-add-business',
  templateUrl: './add-business.component.html',
  styleUrls: ['./add-business.component.scss']
})
export class AddBusinessComponent implements OnInit {
  submitted: boolean = false;
  sms_thld: boolean;
  voice_thld: boolean ;
  mms_thld: boolean;
  email_thld: boolean ;
  desc:any;
  // isEnabled: boolean = true;
  formValues: BusinessUnit = new BusinessUnit({
    name: '',
    description: '',
    email:'',
    allocatedSMS: 0,
    allocatedVoice: 0,
    allocatedMMS: 0,
    allocatedEmail: 0,
    smsThreshold: 0,
    mmsThreshold: 0,
    voiceThreshold: 0,
    emailThreshold: 0,
    isActive: true,

  });
  formValues1 = {
    sms: null,
  }
  isUpdate: boolean;
  isDisabled: boolean;
  isEditable: boolean;
  value: any;
  totval: any;
  maxLength: number;
  currentVal: any;
  flg: boolean;
  flg1: boolean;
  flg2: boolean;
  flg3: boolean;
  selected: string[] = []

 id: any;
  desc1: any;
  data: boolean;
  data1: boolean;
  name: boolean;
  semail: boolean;
  sname: boolean;
  sdesc: boolean;

  constructor(private route: ActivatedRoute, private businessUnitService: BusinessUnitService,
    private toastr: ToasterService, private dialog: MatDialog, private router: Router) { }

  ngOnInit(): void {
    this.route.params.subscribe(param => {
      if (!!param?.id) {
        this.isUpdate = true;
        if (!!!this.businessUnitService.selectedbusinessUnit) {
          this.businessUnitService.getBusinessUnit(param.id).subscribe((res: any) => {
            if (!res.isError) {
              this.formValues = new BusinessUnit(res.responseObject);
            } else {
              this.toastr.showErrorMessage(res.message);
            }
          })
        } else {
          this.formValues = this.businessUnitService.selectedbusinessUnit;
        }
        this.isDisabled = (this.route.snapshot.url.join().split(',')[0] != 'edit');
      }
    });
  }

  onChangeEvent(event: any) {
    this.totval = event.target.value;
    this.id = event.target.id;
    switch (this.id) {
      case '1': {
        if (this.totval.length < 1) {
          this.sms_thld = true;
        }
        else {
          this.sms_thld = false;
        }
      }
        break;

      case '2': {
        if (this.totval.length < 1) {
          this.voice_thld = true;
        }
        else {
          this.voice_thld = false;
        }
      }
        break;


      case '3': {
        if (this.totval.length < 1) {
          this.mms_thld = true;
        }
        else {
          this.mms_thld = false;
        }
      }
        break;

      case '4': {
        if (this.totval.length < 1) {
          this.email_thld= true;
        }
        else {
          this.email_thld = false;
        }
      }
        break;

    }
  }

  getValue(event: any) {
    this.currentVal = event.target.value;
    switch (this.id) {
      case '1': {
        if (this.currentVal > 100) {
          this.flg = true

        }
        else {
          this.flg = false
        }
      }
        break;
      case '2': {
        if (this.currentVal > 100) {
          this.flg1 = true;
        }
        else {
          this.flg1 = false;
        }
      }
        break;
      case '3': {
        if (this.currentVal > 100) {
          this.flg2 = true;
        }
        else {
          this.flg2 = false;
        }
      }
        break;
      case '4': {
        if (this.currentVal > 100) {
          this.flg3 = true;
        }
        else {
          this.flg3 = false;
        }
      }
        break;
    }
  }

  submit(isValid) {
    this.submitted = true;
    // this.formValues.name=this.formValues.name.replace(/^\s+|\s+$/g, '');
    // this.formValues.description=this.formValues.description.replace(/^\s+|\s+$/g, '');
    if (isValid) {
    if (this.isUpdate) {
        if (this.formValues.smsThreshold <= 100 && this.formValues.voiceThreshold <= 100 &&
            this.formValues.mmsThreshold <= 100 && this.formValues.emailThreshold <= 100)
        {
          this.businessUnitService.update(this.formValues).subscribe((res: any) => {
            this.submitted = false;
            if (!res.isError) {
              let successDialog = this.dialog.open(SuccessPopupComponent, { data: { successMessage: 'Business Unit updated successfully' } });
              successDialog.afterClosed().subscribe(res => this.router.navigate(['/settings/business']))
            } else {
              this.toastr.showErrorMessage(res.message);
            }
          });
        } else {
          this.toastr.showErrorMessage("Please enter valid data");
        }
      } else {
        if(!this.formValues.description.trim().length){
          this.toastr.showErrorMessage("plz add valid description");
          return;
        }
        if(this.formValues.allocatedVoice!=null || this.formValues.allocatedSMS!=null 
            ||this.formValues.allocatedMMS!=null||this.formValues.allocatedEmail!=null)
            {
                 if(this.formValues.allocatedSMS!=0)
                   {
                 if(this.formValues.smsThreshold==null || this.formValues.smsThreshold==0)
                   {
                    this.toastr.showErrorMessage("Add SMSthreshold value ");
                    return;
                  } 
                }
                if(this.formValues.allocatedVoice!=0){
                  if(this.formValues.voiceThreshold==null || this.formValues.voiceThreshold==0)
                 {
                 this.toastr.showErrorMessage("Add Voicethreshold value");
                 return;
                 }
               }
           if(this.formValues.allocatedMMS!=0)
           {
             if(this.formValues.mmsThreshold ==null || this.formValues.mmsThreshold ==0 )
               {
            this.toastr.showErrorMessage("Add mmsthreshold value");
            return;
          }
          if(this.formValues.allocatedEmail!=0){
            if(this.formValues.emailThreshold ==null ||this.formValues.emailThreshold ==0 ) 
            {
              this.toastr.showErrorMessage("Add Emailthreshold value");
              return;
            }
          }
        }
         
      }
        if(this.formValues.smsThreshold > 100 
         || this.formValues.mmsThreshold> 100 || this.formValues.voiceThreshold >100
          || this.formValues.emailThreshold > 100)
          {this.toastr.showErrorMessage("Please add valid data");
          return;
        }
        // this.formValues.description=this.formValues.description.trimRight();
        this.businessUnitService.create(this.formValues).subscribe((res: any) => {
          this.submitted = false;
          if (!res.isError) {
            let successDialog = this.dialog.open(SuccessPopupComponent, { data: { successMessage: 'Business Unit added successfully' } });
            successDialog.afterClosed().subscribe(res => this.router.navigate(['/settings/business']))
          } else {
            this.toastr.showErrorMessage(res.message);
          }
        });
      }
    }
  }

  back() {
    window.history.back();
  }

  ngOnDestroy() {
    this.businessUnitService.selectedbusinessUnit = null;
  }
  checkRegex(value, reg) {
    let exp = new RegExp(reg);
    if (!value.key.match(exp)) {
      value.preventDefault();
      return false;
    }
    return true;
  }
  space(event){
    this.formValues.name=this.formValues.name?.trim();
    this.formValues.description=this.formValues.description?.trim();
    switch (this.id) {
      case '1': {
        if (this.formValues.name.length==null) {
          this.sname = false

        }
        else {
          this.sname = true
        }
      }
        break;
        case '2': {
        
          if (this.formValues.description.length==null) {
            this.sdesc = false
            }
          else {
            this.sdesc = true
          }
        }
        break; 
      case '3': {
        
          if (this.formValues.email.length==null) {
            this.semail = false
  
          }
          else {
            this.semail = true
          }
        }
        break;
       

  }
   
      }
  checkEmptyValues() {
    if (this.formValues.allocatedVoice == 0 || this.formValues.allocatedVoice == null)
    {
      this.formValues.allocatedVoice = 0;
      this.formValues.voiceThreshold = 0; 
    }
    if (this.formValues.allocatedEmail == 0 || this.formValues.allocatedEmail == null)
    {
      this.formValues.allocatedEmail = 0;
      this.formValues.emailThreshold = 0;
    }
    if (this.formValues.allocatedSMS == 0 || this.formValues.allocatedSMS == null)
    {
      this.formValues.allocatedSMS = 0;
      this.formValues.smsThreshold = 0; 
    }
    if (this.formValues.allocatedMMS == 0 || this.formValues.allocatedMMS == null)
    {
      this.formValues.allocatedMMS = 0;
      this.formValues.mmsThreshold = 0; 
    }
  }

}
