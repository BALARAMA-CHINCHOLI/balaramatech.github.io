import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { SettingsRoutingModule } from './settings-routing.module';
import { SettingsComponent } from './settings.component';
import {Ng2TelInputModule} from 'ng2-tel-input';


@NgModule({
  imports: [
    CommonModule,
    Ng2TelInputModule,
    SettingsRoutingModule
  ],
  declarations: [SettingsComponent
  ]
})
export class SettingsModule { }
