import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '../../shared/shared.module';
import { AddRulesComponent } from './add/add-rules.component';
import { RulesRoutingModule } from './rules-routing.module';
import { RulesComponent } from './rules.component';
import { ViewRulesComponent } from './view/view-rules.component';


@NgModule({
  declarations: [
    RulesComponent,
    ViewRulesComponent,
    AddRulesComponent
  ],
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    RulesRoutingModule
  ]
})
export class RulesModule { }
