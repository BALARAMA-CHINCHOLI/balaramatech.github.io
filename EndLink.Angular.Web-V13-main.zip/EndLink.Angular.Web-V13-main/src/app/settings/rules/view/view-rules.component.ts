import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RuleService } from 'src/app/services/rule.service';
import { paths } from 'src/app/shared/constants';
import { Response } from 'src/app/shared/models/response';
import { Rule } from 'src/app/shared/models/rule';

@Component({
  selector: 'app-view-rules',
  templateUrl: './view-rules.component.html',
  styleUrls: ['./view-rules.component.scss']
})
export class ViewRulesComponent implements OnInit {

  rule: Rule = null;
  id: number;

  constructor(private ruleService: RuleService,
    private route: ActivatedRoute,
    private router: Router) {
  }

  ngOnInit() {
    this.route.params.subscribe(data => {
      this.id = +data['id'];

      this.getRule();
    });
  }

  getRule() {
    this.ruleService.get(this.id).subscribe((data: Response) => {
      this.rule = data.responseObject;
      this.setGroupPosition();
    });
  }


  private setGroupPosition() {
    var current = 0;
    this.rule.ruleDetails.forEach((item, index) => {
      if (item.group > 0) {

        // first item
        if (current == 0) {
          item.groupPosition = 'First';
          current = item.group;
        } else {
          var nextItemGroup = 0;
          if ((index + 1) <= this.rule.ruleDetails.length - 1) {
            nextItemGroup = this.rule.ruleDetails[index + 1].group;
          }

          if (nextItemGroup == item.group) {
            item.groupPosition = 'Intermediate';
          } else {
            item.groupPosition = 'Last';
            current = 0;
          }
        }
      }
    });
  }

  goBack() {
    this.router.navigate([paths.rulesList]);
  }
}
