import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { RuleService } from 'src/app/services/rule.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { ConfirmationComponent } from 'src/app/shared/components/confirmation/confirmation.component';
import { SuccessPopupComponent } from 'src/app/shared/components/success-popup/success-popup.component';
import { messages, paths } from 'src/app/shared/constants';
import { SortingType } from 'src/app/shared/enums/sorting-type';
import { ListModel } from 'src/app/shared/models/list-model';
import { Rule } from 'src/app/shared/models/rule';
import { RuleFilter } from 'src/app/shared/models/rule-filter';
import { ScrollerService } from '../../services/scroller-service.service';

@Component({
  selector: 'app-Rules',
  templateUrl: './Rules.component.html',
  styleUrls: ['./Rules.component.scss'],
})
export class RulesComponent implements OnInit {

  private header_data: any[] = [
    { title: "Rule Name", type: "text", prop: 'name', sortProp: 'name', sort: true, isFilter: true, isAsc: false, isDes: false },
    { title: "Description", type: "text", prop: 'description', sortProp: 'description', sort: true, isFilter: true, isAsc: false, isDes: false },
    { title: "Data Source", type: "text", prop: 'eventTypeName', sortProp: 'eventTypeName', isFilter: true, isAsc: false, isDes: false, },
    { title: "Workflow", type: "text", prop: 'workFlow', isFilter: true, isAsc: false, isDes: false, },
    { title: "Status", type: "slide", prop: 'isActive', sortProp: 'isActive', isFilter: true, isAsc: false, isDes: false, },
  ];

  tableData: any = {
    headerData: [],
    rowData: [],
    noRecordFound: true
  };

  filter: RuleFilter = {
    eventTypeId: 0,
    SearchText: '',
    paging: {
      pageNumber: 1,
      pageSize: 10
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'Name'
    }
  };

  list: ListModel<any> = {
    list: [],
    hasNextPage: false
  };
  ruleList$: any;
  scroller$: any;

  constructor(private router: Router,
    private dialog: MatDialog,
    private ruleService: RuleService,
    private toasterService: ToasterService,
    private scroller: ScrollerService) {

  }

  ngOnInit() {
    this.tableData.noRecordFound = true;
    this.tableData.headerData = this.header_data;
    this.scroller$ = this.scroller.scroller$
      .pipe
      ()
      .subscribe((res) => {
        if (this.list.hasNextPage) {
          this.filter.paging.pageNumber++;
          this.getRules();
        }
      });
    this.getRules();
  }

  getRules() {
    this.ruleList$ = this.ruleService
      .list(this.filter)
      .subscribe((data) => {
        if (this.filter.paging.pageNumber == 1) {
          this.list = data.responseObject;
          this.tableData.rowData = [];
        } else {
          data.responseObject.list.forEach((item) => {
            this.list.list.push(item);
          });
        }

        const tableData = [];
        this.list.list.forEach((item) => {
          tableData.push({
            id: item.id,
            name: item.name,
            description: item.description,
            eventTypeName: item.eventType.name,
            workFlow: item.workflow.length,
            isActive: item.isActive
          });
        });

        this.tableData.rowData = tableData;

        if (this.list.list.length > 0) {
          this.tableData.noRecordFound = false;
        }

        this.list.hasNextPage =
          data.responseObject.list && data.responseObject.list.length > 0;
      });
  }

  search() {
    this.filter.paging.pageNumber = 1;
    this.getRules();
  }

  filterByStatus(event): void {
    this.filter.filter = {
      FilterBy: 'Status',
      Value: event || '',
    };
    this.filter.paging.pageNumber = 1;
    this.getRules();
  }

  delete(id: number) {
    this.ruleService.delete(id).subscribe(() => {
      this.filter.paging.pageNumber = 1;
      this.getRules();
    });
  }

  changeStatus(rule: Rule) {
    rule.isActive = !rule.isActive;
    this.ruleService.update(rule).subscribe((res: any) => {
      if (res.isError) {
        this.toasterService.showErrorMessage(res.message);
        rule.isActive = !rule.isActive;
      }
    });
  }

  tableActions(event) {
    switch (event.action) {
      case 'view': {
        this.router.navigate([paths.rulesView + event.rowData.id]);
        break;
      }
      case 'edit': {
        this.router.navigate([paths.rulesEdit + event.rowData.id]);
        break;
      }
      case 'navigate': {
        this.router.navigate([event.rowData.url]);
      }
      case 'search': {
        this.filter.SearchText = event.filterData.globalSearch;
        this.filter.paging.pageNumber = 1;
        break;
      }
      case 'switch': {
        const rule = this.list.list.find((x) => x.id == event.rowData.id);

        if (rule == null) {
          return;
        }

        let statusSwitch = this.dialog.open(ConfirmationComponent, {
          data: {
            message: 'Are you sure you want to change this status?',
            icon: 'warning',
            action: 'Update',
          },
          width: '30vw',
        });
        statusSwitch.afterClosed().subscribe((result) => {
          if (result) {
            this.changeStatus(rule);
          } else {
            event.rowData.isActive = !event.rowData.isActive;
          }
        });
        break;
      }
      case 'sort': {
        this.filter.paging.pageNumber = 1;
        this.filter.sorting = {
          order: event.filterData.sortOrder,
          sortBy: event.filterData.sortHeader
        };
        this.getRules();
        break;
      }
      case 'delete': {
        const item = this.list.list.find((x) => x.id == event.rowData.id);

        if (item == null) {
          return;
        }

        if(item.workflow && item.workflow.length > 0) {
          this.dialog.open(SuccessPopupComponent, {data: {title: 'Error', successMessage: item.workflow.length + ' workflows are attached with this rule and hence can not delete.'}});
          return;
        }

        let del = this.dialog.open(ConfirmationComponent, {
          data: {
            message: 'Are you sure you want to delete this Rule?',
            icon: 'delete',
            action: 'Delete',
          },
        });
        del.afterClosed().subscribe((result) => {
          if (result) {
            this.delete(item.id);
          }
        });
        break;
      }
    }
  }
  public ngOnDestroy() {
    this.ruleList$.unsubscribe();
    this.scroller$.unsubscribe();
  }
}
