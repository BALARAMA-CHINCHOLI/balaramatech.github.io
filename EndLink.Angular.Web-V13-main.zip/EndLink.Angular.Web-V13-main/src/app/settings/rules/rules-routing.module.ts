import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddRulesComponent } from './add/add-rules.component';
import { RulesComponent } from './rules.component';
import { ViewRulesComponent } from './view/view-rules.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: RulesComponent
  },
  {
    path: 'add',
    component: AddRulesComponent,
    data: { breadcrumb: 'Add Rule', title: 'Add Rule', isSinglePage: true }
  },
  {
    path: 'view/:id',
    component: ViewRulesComponent,
    data: { breadcrumb: 'View Rule', title: 'View Rule', isSinglePage: true }
  },
  {
    path: 'edit/:id',
    component: AddRulesComponent,
    data: { breadcrumb: 'Edit Rule', title: 'Edit Rule', isSinglePage: true }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class RulesRoutingModule { }
