import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EventTypeRoutingModule } from './event-type-routing.module';
import { EventTypeComponent } from './event-type.component';
import { AddEventTypeComponent } from './add-event-type/add-event-type.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ViewEventTypeComponent } from './view-event-type/view-event-type.component';


@NgModule({
  declarations: [EventTypeComponent, AddEventTypeComponent, ViewEventTypeComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    EventTypeRoutingModule,
    SharedModule
  ]
})
export class EventTypeModule { }
