import { Component, OnInit } from '@angular/core';
import { COMMA, ENTER, SPACE } from '@angular/cdk/keycodes';
import { MatChipInputEvent } from '@angular/material/chips';
import { EventWorkflowType, Parameter, WrokflowType } from 'src/app/shared/models/event-workflowType';
import { EventWorkflowTypeService } from 'src/app/services/event-workflowType.service';
import { messages, paths } from 'src/app/shared/constants';
import { SuccessPopupComponent } from 'src/app/shared/components/success-popup/success-popup.component';
import { ActivatedRoute, Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { ToasterService } from 'src/app/services/toaster.service';
import { ConfirmationComponent } from 'src/app/shared/components/confirmation/confirmation.component';
import { EventTypeParameterService } from 'src/app/services/event-type-parameter.service';
interface Food {
  value: string;
  viewValue: string;
}
@Component({
  selector: 'app-view-event-type',
  templateUrl: './view-event-type.component.html',
  styleUrls: ['./view-event-type.component.scss']
})
export class ViewEventTypeComponent implements OnInit {
  public fieldArray: Array<any> = [];
  public newAttribute: any = {};
  value: any;

  addFieldValue() {
    this.fieldArray.push(this.newAttribute);
    this.newAttribute = {};
  }

  deleteFieldValue(index) {
    this.fieldArray.splice(index, 1);
  }

  selectedValue: string;

  Datatypes: any[] = [
    { value: 1, viewValue: "Number" },
    { value: 2, viewValue: "Boolean" },
    { value: 3, viewValue: "Text" },
    { value: 4, viewValue: "Date" }
  ];

  paramDatatypes: Parameter[] = [
    { Id: 0, Parameter: '', Description: '', DataType: '3', Merg: '', ErrStatus: false, ErrStatus2: true, value: '', viewValue: 'Text', IsIdentifier: true/*, PropertiesValue: []*/ }
  ];

  separatorKeysCodes: number[] = [ENTER, COMMA, SPACE];
  parameters: Parameter[] = [
    { Id: 0, Parameter: '', Description: '', DataType: '3', Merg: '', ErrStatus: false, ErrStatus2: true, value: '', viewValue: 'Text', IsIdentifier: true/*, PropertiesValue: []*/ }
  ];

  WorkflowName: string;
  WorkflowDesciption: string;
  wrokflowType: WrokflowType = <WrokflowType>{};
  jsonObject: EventWorkflowType = <EventWorkflowType>{};
  isDisabled: boolean = false;
  isUpdate: boolean = false;
  submitted: boolean = false;
  formValues: EventWorkflowType = new EventWorkflowType();
  isUniquePname: boolean = false;
  isAvailablePtype: boolean = false;
  parameterNameCheck: boolean = false;
  jsonObjectValue: EventWorkflowType = <EventWorkflowType>{};
  constructor(private eventWorkflowTypeService: EventWorkflowTypeService, private router: Router,
    private toastr: ToasterService, private dialog: MatDialog, private route: ActivatedRoute, private eventTypeParamService: EventTypeParameterService) { }


  ngOnInit() {
    this.route.params.subscribe(param => {
      if (!!param?.id) {
        this.getEventTypeDetails(param.id);
        this.isUpdate = true;
        this.isDisabled = (this.route.snapshot.url.join().split(',')[0] != 'edit');
      }
    });
  }

  getEventTypeDetails(Id: number) {
    this.eventWorkflowTypeService.get(Id).subscribe((res: any) => {
      if (!res.isError) {
        this.jsonObjectValue = JSON.parse(res.responseObject);
        this.jsonObject = JSON.parse(res.responseObject);
        this.WorkflowName = this.jsonObject[0].WrokflowType.Name;
        this.WorkflowDesciption = this.jsonObject[0].WrokflowType.Description;
        this.paramDatatypes = this.jsonObject[0].WrokflowType.Properties;
        for (let i = 0; i < this.paramDatatypes.length; i++) {
          if (this.paramDatatypes[i].DataType == this.Datatypes[0].value || this.paramDatatypes[i].DataType == this.Datatypes[1].value ||
            this.paramDatatypes[i].DataType == this.Datatypes[2].value || this.paramDatatypes[i].DataType == this.Datatypes[3].value) {
            if (this.paramDatatypes[i].DataType == this.Datatypes[0].value) {
              this.paramDatatypes[i].viewValue = this.Datatypes[0].viewValue;
            }
            if (this.paramDatatypes[i].DataType == this.Datatypes[1].value) {
              this.paramDatatypes[i].viewValue = this.Datatypes[1].viewValue;
            }
            if (this.paramDatatypes[i].DataType == this.Datatypes[2].value) {
              this.paramDatatypes[i].viewValue = this.Datatypes[2].viewValue;
            }
            if (this.paramDatatypes[i].DataType == this.Datatypes[3].value) {
              this.paramDatatypes[i].viewValue = this.Datatypes[3].viewValue;
            }
          }
        }
      }
      else {
        this.toastr.showErrorMessage(res.message);
      }
    })
  }

  //add(event: MatChipInputEvent, index): void {
  //  const input = event.input;
  //  const value = event.value;
  //  if ((value || '').trim()) {
  //    this.parameters[index].PropertiesValue.push({ Id: 0, Value: value.trim() });
  //  }
  //  // Reset the input value
  //  if (event.value) {
  //    event.value = '';
  //  }
  //}

  uniqueProperty(param, i) {

    for (let i = 0; i < this.paramDatatypes.length; i++) {
      for (let j = 0; j < this.paramDatatypes.length; j++) {
        if (i == j) {
          this.paramDatatypes[i].ErrStatus = false;
        }
        else {
          if (this.paramDatatypes[i].Parameter == this.paramDatatypes[j].Parameter) {
            this.paramDatatypes[i].ErrStatus = true;
            break;
          }
          else {
            this.paramDatatypes[i].ErrStatus = false;
          }
        }
      }
    }
  }

  //validation for property type
  invalidPropertyDatatype(param, i) {
    let p = i;
    for (let i = p; i < this.paramDatatypes.length; i++) {
      if (param == this.Datatypes[0].viewValue || param == this.Datatypes[1].viewValue ||
        param == this.Datatypes[2].viewValue || param == this.Datatypes[3].viewValue) {
        this.paramDatatypes[i].ErrStatus2 = true;
        if (param == this.Datatypes[0].viewValue) {
          this.paramDatatypes[i].DataType = this.Datatypes[0].value;
          break;
        }
        if (param == this.Datatypes[1].viewValue) {
          this.paramDatatypes[i].DataType = this.Datatypes[1].value;
          break;
        }
        if (param == this.Datatypes[2].viewValue) {
          this.paramDatatypes[i].DataType = this.Datatypes[2].value;
          break;
        }
        if (param == this.Datatypes[3].viewValue) {
          this.paramDatatypes[i].DataType = this.Datatypes[3].value;
          break;
        }

      }
      else {
        this.paramDatatypes[i].ErrStatus2 = false;
        break;
      }
    }
  }


  removeParamRow(param, i) {
    let del = this.dialog.open(ConfirmationComponent, {
      data: {
        message: 'Are you sure you want to delete this Property?',
        icon: 'warning',
        action: 'Delete',
      },
      width: '30vw',
    });
    del.afterClosed().subscribe((result) => {
      if (!result) {
        return;
      }

      if (param.Id > 0) {
        this.eventTypeParamService.checkDelete(param.Id).subscribe((data) => {
          if (data.responseObject) {
            this.paramDatatypes.splice(i, 1);
          } else {
            this.toastr.showErrorMessage(data.message);
          }
        });
      } else {
        this.paramDatatypes.splice(i, 1);
      }
    });
  }

  addParamRow() {
    this.paramDatatypes.push({ Id: 0, Parameter: '', Description: '', DataType: '', Merg: '', ErrStatus: false, ErrStatus2: true, value: '', viewValue: '', IsIdentifier: false/*, PropertiesValue: []*/ });
  }

  back() {
    window.history.back();
  }

  assignvalue(param, i) {
    this.paramDatatypes[i]["Parameter"] = param;
    this.paramDatatypes[i]["Merg"] = "<%" + param + "%>";
  }

  exportEventTypes() {
    const data = {
      name: this.WorkflowName,
      types: this.paramDatatypes
    };
    const element = document.createElement('a');
    const fileType = 'text/json';
    element.setAttribute('href', `data:${fileType};charset=utf-8,${encodeURIComponent(JSON.stringify(data))}`);
    element.setAttribute('download', this.WorkflowName + '.json');

    var event = new MouseEvent("click");
    element.dispatchEvent(event);
  }

  SaveWorkflowType(form) {
    if (form.valid) {
      if (this.isUpdate) {
        this.jsonObject[0].WrokflowType.Name = this.WorkflowName;
        this.jsonObject[0].WrokflowType.Description = this.WorkflowDesciption;
        this.wrokflowType.Properties = this.paramDatatypes;
        this.jsonObject.WrokflowType = this.wrokflowType;
        if (JSON.stringify(this.jsonObjectValue) !== JSON.stringify(this.jsonObject)) {
          this.eventWorkflowTypeService.update(this.jsonObject).subscribe((res: any) => {
            this.submitted = false;
            if (!res.isError) {
              let successDialog = this.dialog.open(SuccessPopupComponent, {
                data: { successMessage: messages.WorkflowTypeUpdateSuccess },
              });
              successDialog
                .afterClosed()
                .subscribe((res) => this.router.navigate([paths.eventTypesList]));
            } else {
              this.toastr.showErrorMessage(res.message);
            }
          });
        }
      } else {
        this.wrokflowType.Name = this.WorkflowName;
        this.wrokflowType.Description = this.WorkflowDesciption;
        this.wrokflowType.Properties = this.paramDatatypes;
        this.jsonObject.WrokflowType = this.wrokflowType;
        this.eventWorkflowTypeService
          .create(this.jsonObject)
          .subscribe((res: any) => {
            if (!res.isError) {
              let successDialog = this.dialog.open(SuccessPopupComponent, {
                data: { successMessage: messages.WorkflowTypeCreateSuccess },
              });
              successDialog
                .afterClosed()
                .subscribe((res) => this.router.navigate([paths.eventTypesList]));
            } else {
              this.toastr.showErrorMessage(res.message);
            }
          });
      }
    }
  }

  file: any;
  isValidFile: boolean = true;
  fileContent: any[];
  tempData: any[];
  contentOfFileLoaded: any;
  text: any = [];
  tempObject: any = [];
  fileChanged(event) {

    this.file = event.target.files[0];
    var ext = this.file.name.substring(this.file.name.lastIndexOf('.') + 1);
    if (ext.toLowerCase() == 'json' || ext.toLowerCase() == 'csv' || this.file.name == null) {
      this.isValidFile = true;
    }
    else {
      this.isValidFile = false;
    }
    //uploading file
    const fileReader = new FileReader();
    fileReader.readAsText(this.file);
    fileReader.onload = () => {
      var ext = this.file.name.substring(this.file.name.lastIndexOf('.') + 1);
      if (ext.toLowerCase() == 'json') {
        this.parameters = (JSON.parse(fileReader.result.toString()));
        this.paramDatatypes = [];
        for (let i = 0; i < this.parameters.length; i++) {
          for (let j = 0; j < this.parameters.length; j++) {
            if (i == j) {
              this.parameterNameCheck = false;
            }
            else {
              if (this.parameters[i].Parameter == this.parameters[j].Parameter) {
                this.parameterNameCheck = true;
                break;
              }
              else {
                this.parameterNameCheck = false;
              }
            }
          }

          if (this.parameters[i].DataType == this.Datatypes[0].viewValue || this.parameters[i].DataType == this.Datatypes[1].viewValue ||
            this.parameters[i].DataType == this.Datatypes[2].viewValue || this.parameters[i].DataType == this.Datatypes[3].viewValue) {
            this.isAvailablePtype = true;
            if (this.parameters[i].DataType == this.Datatypes[0].viewValue) {
              this.parameters[i].value = this.Datatypes[0].value;
              this.parameters[i].viewValue = this.Datatypes[0].viewValue;
            }
            if (this.parameters[i].DataType == this.Datatypes[1].viewValue) {
              this.parameters[i].value = this.Datatypes[1].value;
              this.parameters[i].viewValue = this.Datatypes[1].viewValue;
            }
            if (this.parameters[i].DataType == this.Datatypes[2].viewValue) {
              this.parameters[i].value = this.Datatypes[2].value;
              this.parameters[i].viewValue = this.Datatypes[2].viewValue;
            }
            if (this.parameters[i].DataType == this.Datatypes[3].viewValue) {
              this.parameters[i].value = this.Datatypes[3].value;
              this.parameters[i].viewValue = this.Datatypes[3].viewValue;
            }
          }
          else {
            this.isAvailablePtype = false;
            this.parameters[i].value = '';
            this.parameters[i].viewValue = '';
          }

          let tempObj = { 'Id': 0, 'Parameter': this.parameters[i].Parameter, 'Description': '', 'IsIdentifier': false, 'DataType': this.parameters[i].value, 'Merg': "<%" + this.parameters[i].Parameter + "%>", 'ErrStatus': this.parameterNameCheck, 'ErrStatus2': this.isAvailablePtype, 'value': this.parameters[i].value, 'viewValue': this.parameters[i].viewValue };
          this.paramDatatypes.push(tempObj);
        }
      }
      else if (ext.toLowerCase() == 'csv') {
        this.text = fileReader.result;
        let csvToRowArray = this.text.split("\r\n");
        this.parameters = [];
        for (let index = 1; index < csvToRowArray.length - 1; index++) {
          let row = csvToRowArray[index].split(",");
          this.tempObject = { 'Id': 0, 'Parameter': row[0], 'Description': '', 'DataType': row[1], 'Merg': row[2], ErrStatus: false, ErrStatus2: true /*, 'Status': true*/ };
          this.parameters.push(this.tempObject);
        }
        this.paramDatatypes = [];
        for (let i = 0; i < this.parameters.length; i++) {
          for (let j = 0; j < this.parameters.length; j++) {
            if (i == j) {
              this.parameterNameCheck = false;
            }
            else {
              if (this.parameters[i].Parameter == this.parameters[j].Parameter) {
                this.parameterNameCheck = true;
                break;
              }
              else {
                this.parameterNameCheck = false;
              }
            }
          }

          if (this.parameters[i].DataType == this.Datatypes[0].viewValue || this.parameters[i].DataType == this.Datatypes[1].viewValue ||
            this.parameters[i].DataType == this.Datatypes[2].viewValue || this.parameters[i].DataType == this.Datatypes[3].viewValue) {
            this.isAvailablePtype = true;
            if (this.parameters[i].DataType == this.Datatypes[0].viewValue) {
              this.parameters[i].value = this.Datatypes[0].value;
              this.parameters[i].viewValue = this.Datatypes[0].viewValue;
            }
            if (this.parameters[i].DataType == this.Datatypes[1].viewValue) {
              this.parameters[i].value = this.Datatypes[1].value;
              this.parameters[i].viewValue = this.Datatypes[1].viewValue;
            }
            if (this.parameters[i].DataType == this.Datatypes[2].viewValue) {
              this.parameters[i].value = this.Datatypes[2].value;
              this.parameters[i].viewValue = this.Datatypes[2].viewValue;
            }
            if (this.parameters[i].DataType == this.Datatypes[3].viewValue) {
              this.parameters[i].value = this.Datatypes[3].value;
              this.parameters[i].viewValue = this.Datatypes[3].viewValue;
            }
          }
          else {
            this.isAvailablePtype = false;
            this.parameters[i].value = '';
            this.parameters[i].viewValue = '';
          }
          let tempObject = { 'Id': 0, 'Parameter': this.parameters[i].Parameter, 'Description': '', 'IsIdentifier': false, 'DataType': this.parameters[i].value, 'Merg': "<%" + this.parameters[i].Parameter + "%>", 'ErrStatus': this.parameterNameCheck, 'ErrStatus2': this.isAvailablePtype, 'value': this.parameters[i].value, 'viewValue': this.parameters[i].viewValue };
          this.paramDatatypes.push(tempObject);
        }
      };
    }
    fileReader.onerror = (error) => {
    }
  }
}
