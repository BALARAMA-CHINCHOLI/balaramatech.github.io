import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewEventTypeComponent } from './view-event-type.component';

describe('ViewEventTypeComponent', () => {
  let component: ViewEventTypeComponent;
  let fixture: ComponentFixture<ViewEventTypeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ ViewEventTypeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(ViewEventTypeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
