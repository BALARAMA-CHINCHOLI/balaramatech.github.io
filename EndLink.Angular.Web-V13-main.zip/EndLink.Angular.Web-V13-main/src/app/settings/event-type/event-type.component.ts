import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { EventWorkflowTypeService } from 'src/app/services/event-workflowType.service';
import { ScrollerService } from 'src/app/services/scroller-service.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { ConfirmationComponent } from 'src/app/shared/components/confirmation/confirmation.component';
import { SuccessPopupComponent } from 'src/app/shared/components/success-popup/success-popup.component';
import { messages, paths } from 'src/app/shared/constants';
import { SortingType } from 'src/app/shared/enums/sorting-type';
import { EventTypeList, WorkflowTypeFilter } from 'src/app/shared/models/event-workflowType';
import { ListModel } from 'src/app/shared/models/list-model';
import { SearchFilter } from 'src/app/shared/models/search-filter';

@Component({
  selector: 'app-event-type',
  templateUrl: './event-type.component.html',
  styleUrls: ['./event-type.component.scss']
})
export class EventTypeComponent implements OnInit {
  filter: SearchFilter = {
    SearchText: '',
    paging: {
      pageNumber: 1,
      pageSize: 10
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'CreatedOn'
    }
  };

  list: ListModel<EventTypeList> = {
    list: [],
    hasNextPage: false
  };

  EventTypeList$: any;
  scroller$: any;
  searchSubject: Subject<string> = new Subject<string>();
  constructor(private eventWorkflowTypeService: EventWorkflowTypeService, private router: Router,
    private toastr: ToasterService, private dialog: MatDialog, private scroller: ScrollerService) { }
  private header_data: any[] = [
    { title: "Data Source", type: "text", prop: 'name', sortProp: 'name', sort: true, isFilter: true, isAsc: false, isDes: false },
    { title: "Description", type: "text", prop: 'description', sortProp: 'description', sort: true, isFilter: true, isAsc: false, isDes: false },
    { title: "Parameters", type: "parameterstext", prop: 'parameters', sortProp: 'parameters', isFilter: true, isAsc: false, isDes: false, }
  ];
  tableData: any = {
    headerData: [],
    rowData: [],
    noRecordFound: true
  }
  ngOnInit() {
    this.getWorkflowType();
    this.tableData.noRecordFound = true;
    this.tableData.headerData = this.header_data;
    this.scroller$ = this.scroller.scroller$.pipe(
    ).subscribe(res => {
      if (this.list.hasNextPage) {
        this.filter.paging.pageNumber++;
        this.getWorkflowType();
      }
    });
    this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe((model) => {
        this.filter.paging.pageNumber = 1;
        this.getWorkflowType();
      });
  }

  search(event): void {
    this.searchSubject.next(event);
  }

  tableActions(event) {
    switch (event.action) {
      case 'view': {
        this.router.navigate([paths.eventTypesView + event.rowData.id]);
        break;
      }
      case 'edit': {
        this.router.navigate([paths.eventTypesEdit + event.rowData.id]);
        break;
      }
      case 'navigate': {
        this.router.navigate([event.rowData.url]);
      }
      case 'search': {
        this.filter.SearchText = event.filterData.globalSearch;
        this.filter.paging.pageNumber = 1;
        this.getWorkflowType();
        break;
      }
      case 'sort': {
        this.filter.paging.pageNumber = 1;
        this.filter.sorting = {
          order: event.filterData.sortOrder,
          sortBy: event.filterData.sortHeader
        };

        this.getWorkflowType();
        break;
      }
      case 'delete': {
        const item = this.list.list.find((x) => x.id == event.rowData.id);

        if (item == null) {
          return;
        }
        let del = this.dialog.open(ConfirmationComponent, {
          data: {

            message: 'Are you sure you want to delete this Data Source ?',
            icon: 'delete',
            action: 'Delete',

          },
        });
        del.afterClosed().subscribe((result) => {
          if (result) {
            this.delete(item.id);
          } else {
            //event.rowData.id = !event.rowData.id;
          }
        });
        break;
      }
    }
  }

  public delete(id: number) {
    this.eventWorkflowTypeService.delete(id).subscribe((data) => {
      
      let del = this.dialog.open(SuccessPopupComponent, {
        data: {
          title: data.isError ? 'Error' : 'Success',
          successMessage: data.isError ? data.message : 'Data Source deleted successfully.'
        },
      });

      del.afterClosed().subscribe((result) => {
        this.filter.paging.pageNumber = 1;
        this.getWorkflowType();
      });
    }, (error) => {
      this.toastr.showSuccessMessage('Something went wrong');
    });
  }

  getWorkflowType() {
    this.EventTypeList$ = this.eventWorkflowTypeService.list(this.filter).subscribe((data) => {
      if (this.filter.paging.pageNumber == 1) {
        this.list = data.responseObject;
        this.tableData.rowData = [];
      } else {
        data.responseObject.list.forEach(item => {
          this.list.list.push(item);
        });
      }

      const tableData = [];
      this.list.list.forEach((item) => {
        tableData.push(this.parseTableData(item));
      });

      this.tableData.rowData = tableData;

      if (this.list.list.length > 0) {
        this.tableData.noRecordFound = false;
      }

      this.list.hasNextPage = data.responseObject.list && data.responseObject.list.length > 0;
    });
  }

  private parseTableData(eventTypesList: EventTypeList) {
    return {
      id: eventTypesList.id,
      name: eventTypesList.name,
      description: eventTypesList.description,
      parameters: eventTypesList.parameters
    }
  }

  public ngOnDestroy() {
    this.EventTypeList$.unsubscribe();
    this.scroller$.unsubscribe();
  }

}
