import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddEventTypeComponent } from './add-event-type/add-event-type.component';
import { EventTypeComponent } from './event-type.component';
import { ViewEventTypeComponent } from './view-event-type/view-event-type.component';


const routes: Routes = [
  {
    path : '',
    pathMatch: 'full',
    component: EventTypeComponent
  },
  {
    path : 'addDataSource',
    component: AddEventTypeComponent,
    data: { breadcrumb: 'Add Data Source', title: 'Add Data Source', isSinglePage: true }
  }, 
  {
    path: 'details/:id',
    component: ViewEventTypeComponent,
    data: { breadcrumb: 'View Data Source', title: 'View Data Source', isSinglePage: true }
  },
  {
    path: 'edit/:id',
    component: ViewEventTypeComponent,
    data: { breadcrumb: 'Edit Data Source', title: 'Edit Data Source', isSinglePage: true }
  },
  {
    path: 'view/:id',
    component: ViewEventTypeComponent,
    data: { breadcrumb: 'View Data Source', title: 'View Data Source', isSinglePage: true }
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EventTypeRoutingModule { }
