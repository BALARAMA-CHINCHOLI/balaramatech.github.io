import { Component, OnDestroy, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { CityService } from 'src/app/services/city.service';
import { LocationService } from 'src/app/services/dataServices/location.service';
import { StateService } from 'src/app/services/state.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { SuccessPopupComponent } from 'src/app/shared/components/success-popup/success-popup.component';

@Component({
  selector: 'app-add-location',
  templateUrl: './add-location.component.html',
  styleUrls: ['./add-location.component.scss']
})
export class AddLocationComponent implements OnInit, OnDestroy {
  submitted: boolean = false;

  cityInput = new FormControl();
  stateInput = new FormControl();

  isDisabled: boolean = false;
  isUpdate: boolean = false;

  formValues = {
    name: '',
    id: '',
    timezone: null,
    phone: null,
    address: {
      id: null,
      line: '',
      city: null,
      cityName: null,
      stateName: null,
      state: null,
      zipcode: null,
      isActive: false,
      createdBy: 0,
      createdOn: new Date()
    },
    createdBy: 0,
    createdOn: new Date(),
    webLink: '',
    specialty: '',
    specialtyAudioUrl: '',
    isActive: false,
    code: ''
  };

  cityList = [];
  stateList = [];

  id: any;

  sname: boolean;
  scode: boolean;
  sadd: boolean;
  sspl: boolean;

  constructor(private route: ActivatedRoute, private locationService: LocationService,
    private city: CityService, private state: StateService, private dialog: MatDialog,
    private router: Router, private toastr: ToasterService) { }

  ngOnInit(): void {

    this.city.list().subscribe(res => {
      if (!res.isError) {
        this.cityList = res.responseObject;
      }
    });
    this.state.list().subscribe(res => {
      if (!res.isError) {
        this.stateList = res.responseObject;
      }
    })

    this.route.params.subscribe(param => {
      if (!!param?.id) {
        this.isUpdate = true;
        if (!!!this.locationService.selectedLocation) {
          this.locationService.getLocation(param.id).subscribe((res: any) => {
            if (!res.isError) {
              this.formValues = res.responseObject;
            } else {
              this.toastr.showErrorMessage(res.message);
            }
          })
        } else {
          this.formValues = this.locationService.selectedLocation;
        }
        this.isDisabled = (this.route.snapshot.url.join().split(',')[0] != 'edit');
      }
    });
  };

  space(event) {
    this.formValues.name = this.formValues.name?.trim();
    this.formValues.code = this.formValues.code?.trim();
    this.formValues.address.line = this.formValues.address.line?.trim();
    this.formValues.specialty = this.formValues.specialty?.trim();
    switch (this.id) {
      case '1': {
        if (this.formValues.name.length == null) {
          this.sname = false

        }
        else {
          this.sname = true
        }
      }
        break;
      case '2': {

        if (this.formValues.code.length == null) {
          this.scode = false

        }
        else {
          this.scode = true
        }
      }
        break;
      case '3': {

        if (this.formValues.address.line.length == null) {
          this.sadd = false

        }
        else {
          this.sadd = true
        }
      }
        break;
      case '4': {

        if (this.formValues.specialty.length == null) {
          this.sspl = false

        }
        else {
          this.sspl = true
        }
      }
        break;
    }
  }

  submit(isValid) {
    this.submitted = true;
    if (isValid) {
      this.formValues.address.city = this.cityList.find(city => city.name == this.formValues.address.cityName)?.id;
      this.formValues.address.state = this.stateList.find(state => state.name == this.formValues.address.stateName)?.id;
      delete this.formValues.id;
      delete this.formValues.address.id;
      this.locationService.create(this.formValues).subscribe((res: any) => {
        this.submitted = false;
        if (!res.isError) {
          let successDialog = this.dialog.open(SuccessPopupComponent, { data: { successMessage: 'Location added successfully' } });
          successDialog.afterClosed().subscribe(res => this.router.navigate(['/settings/location']))
        } else {
          this.toastr.showErrorMessage(res.message);
        }
      });

    }
  }

  back() {
    window.history.back();
  }

  ngOnDestroy() {
    this.locationService.selectedLocation = null;
  }

  checkRegex(value, reg) {
    let exp = new RegExp(reg);
    if (!value.key.match(exp)) {
      value.preventDefault();
      return false;
    }
    return true;
  }

  checkZipFormat() {
    /*if(this.formValues.address.zipcode.length == 5)*/ {
      this.formValues.address.zipcode = this.formValues.address.zipcode;
    }
  }

}
