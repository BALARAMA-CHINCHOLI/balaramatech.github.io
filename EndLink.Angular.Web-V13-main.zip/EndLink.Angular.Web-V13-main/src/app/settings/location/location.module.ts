import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { LocationRoutingModule } from './location-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { AddLocationComponent } from './add-location/add-location.component';
import { LocationComponent } from './location.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EditLocationComponent } from './edit-location/edit-location.component';
import {Ng2TelInputModule} from 'ng2-tel-input';


@NgModule({
  declarations: [LocationComponent, AddLocationComponent, EditLocationComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    Ng2TelInputModule,
    SharedModule,
    LocationRoutingModule
  ]
})
export class LocationModule { }
