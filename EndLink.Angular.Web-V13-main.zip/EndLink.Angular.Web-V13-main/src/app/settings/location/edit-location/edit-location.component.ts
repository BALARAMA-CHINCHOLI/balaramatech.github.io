
import { Component, OnInit, OnDestroy } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { isEmpty, map, startWith } from 'rxjs/operators';
import { CityService } from 'src/app/services/city.service';
import { LocationService } from 'src/app/services/dataServices/location.service';
import { StateService } from 'src/app/services/state.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { SuccessPopupComponent } from 'src/app/shared/components/success-popup/success-popup.component';

@Component({
  selector: 'app-edit-location',
  templateUrl: './edit-location.component.html',
  styleUrls: ['./edit-location.component.scss']
})
export class EditLocationComponent implements OnInit, OnDestroy {

  submitted: boolean = false;
  isDisabled: boolean = false;
  isUpdate: boolean = false;

  formValues = {
    name: '',
    id: '',
    timezone: null,
    phone: null,
    address: {
      id: null,
      line: '',
      city: null,
      cityName: null,
      stateName: null,
      state: null,
      zipcode: null,
      isActive: false,
      createdBy: 0,
      createdOn: new Date(),

    },
    createdBy: 0,
    createdOn: new Date(),
    webLink: '',
    specialty: '',
    specialtyAudioUrl: '',
    isActive: false,
    code: ''
  };

  cityList = [];
  stateList = [];
  id: any;

  slist: boolean;
  currentVal1: any;
  currentVal2: any;
  constructor(private route: ActivatedRoute, private locationService: LocationService,
    private city: CityService, private state: StateService, private dialog: MatDialog,
    private router: Router, private toastr: ToasterService) { }

  ngOnInit(): void {

    this.city.list().subscribe(res => {
      if (!res.isError) {
        this.cityList = res.responseObject;
      }
    });
    this.state.list().subscribe(res => {
      if (!res.isError) {
        this.stateList = res.responseObject;
      }
    })

    this.route.params.subscribe(param => {
      if (!!param?.id) {
        this.isUpdate = true;
        this.locationService.getLocation(param.id).subscribe((res: any) => {
          if (!res.isError) {
            this.formValues = res.responseObject;
            this.formValues.timezone = res.responseObject.timezone.toString();
            this.formValues.address.cityName = res.responseObject.address.cityName;
            this.formValues.address.stateName = res.responseObject.address.stateName;
          } else {
            this.toastr.showErrorMessage(res.message);
          }
        })

        this.isDisabled = (this.route.snapshot.url.join().split(',')[0] != 'edit');
      }
    });
  };


  submit(isValid) {
    this.submitted = true;
    this.formValues.name = this.formValues.name.replace(/^\s+|\s+$/g, '');
    this.formValues.code = this.formValues.code.replace(/^\s+|\s+$/g, '');
    this.formValues.address.line = this.formValues.address.line.replace(/^\s+|\s+$/g, '');
    if (isValid) {
      this.formValues.address.city = this.cityList.find(city => city.name == this.formValues.address.cityName)?.id;
      this.formValues.address.state = this.stateList.find(state => state.name == this.formValues.address.stateName)?.id;
      if (this.isUpdate) {
        this.locationService.update(this.formValues).subscribe((res: any) => {
          this.submitted = false;
          if (!res.isError) {
            let successDialog = this.dialog.open(SuccessPopupComponent, { data: { successMessage: 'Location updated successfully' } });
            successDialog.afterClosed().subscribe(res => this.router.navigate(['/settings/location']))
          } else {
            this.toastr.showErrorMessage(res.message);
          }
        });
      }
    }
  }

  back() {
    window.history.back();
  }

  ngOnDestroy() {
    this.locationService.selectedLocation = null;
  }


  checkRegex(value, reg) {
    let exp = new RegExp(reg);
    if (!value.key.match(exp)) {
      value.preventDefault();
      return false;
    }
    return true;
  }

  checkZipFormat() {
    /*if(this.formValues.address.zipcode.length == 5)*/ {
      this.formValues.address.zipcode = this.formValues.address.zipcode;
    }
  }

}