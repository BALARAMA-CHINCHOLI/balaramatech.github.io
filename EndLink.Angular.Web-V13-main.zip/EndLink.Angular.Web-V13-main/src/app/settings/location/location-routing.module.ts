import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddLocationComponent } from './add-location/add-location.component';
import { EditLocationComponent } from './edit-location/edit-location.component';
import { LocationComponent } from './location.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: LocationComponent
  },
  {
    path: 'addLocation',
    component: AddLocationComponent,
    data: { breadcrumb: 'Add Location', title: 'Add Location', isSinglePage: true }
  },
  {
    path: 'details/:id',
    component: EditLocationComponent,
    data: { breadcrumb: 'View Location', title: 'View Location', isSinglePage: true }
  },
  {
    path: 'edit/:id',
    component: EditLocationComponent,
    data: { breadcrumb: 'Edit Location', title: 'Edit Location', isSinglePage: true }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class LocationRoutingModule { }
