import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { LocationService } from 'src/app/services/dataServices/location.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { ConfirmationComponent } from 'src/app/shared/components/confirmation/confirmation.component';
import { SortingType } from 'src/app/shared/enums/sorting-type';
import { messages } from 'src/app/shared/constants';
import { ListModel } from 'src/app/shared/models/list-model';
import { Location } from 'src/app/shared/models/location';
import { ScrollerService } from 'src/app/services/scroller-service.service';
import { SearchFilter } from 'src/app/shared/models/search-filter';

@Component({
  selector: 'app-location',
  templateUrl: './location.component.html',
  styleUrls: ['./location.component.scss'],
})
export class LocationComponent implements OnInit, OnDestroy {
  locationFilter: SearchFilter = {
    paging: {
      pageNumber: 1,
      pageSize: 10,
    },
    sorting: {
      order: SortingType.Desc,
      sortBy: 'createdOn',
    },
  };

  list: ListModel<Location> = {
    list: [],
    hasNextPage: false,
  };

  pageData: any = {
    pageSize: 10,
    currentPage: 1,
    totalItems: 20,
  };
  tableData: any = {
    headerData: [],
    rowData: [],
    noRecordFound: true,
  };

  list$: any;
  scroller$: any;

  constructor(
    private locationService: LocationService,
    private router: Router,
    private dialog: MatDialog,
    private toaster: ToasterService,
    private scroller: ScrollerService
  ) {}

  ngOnInit() {
    this.getLocations();
    this.tableData.headerData = header_data;
    this.tableData.noRecordFound = true;
    this.scroller$ = this.scroller.scroller$.subscribe((res) => {
      if (this.list.hasNextPage) {
        this.locationFilter.paging.pageNumber++;
        this.getLocations();
      }
    });
  }

  parseTableData(data) {
    return new Location(data);
  }

  getLocations() {
    this.list$ = this.locationService
      .list(this.locationFilter)
      .subscribe((data: any) => {
        if (this.locationFilter.paging.pageNumber == 1) {
          this.list = data.responseObject;
          this.tableData.rowData = [];
        } else {
          data.responseObject.list.forEach((item) => {
            this.list.list.push(item);
          });
        }

        this.tableData.rowData = this.list.list;

        if (this.list.list.length > 0) {
          this.tableData.noRecordFound = false;
        }
        this.list.hasNextPage =
          data.responseObject.list && data.responseObject.list.length > 0;
      });
  }

  public changeStatus(location: Location) {
    this.locationService.update(location).subscribe((res: any) => {
      if (res.isError) {
        this.toaster.showErrorMessage(res.message);
        location.isActive = !location.isActive;
      }
    });
  }

  tableActions(event) {
    switch (event.action) {
      case 'view': {
        this.locationService.selectedLocation = event.rowData;
        this.router.navigate(
          ['/settings/location/details/' + event.rowData.id],
          { queryParams: { type: 'view' } }
        );
        break;
      }
      case 'edit': {
        this.locationService.selectedLocation = event.rowData;
        this.router.navigate(['/settings/location/edit/' + event.rowData.id], {
          queryParams: { type: 'edit' },
        });
        break;
      }
      case 'sort': {
        this.locationFilter.paging.pageNumber = 1;
        this.locationFilter.sorting = {
          order: event.filterData.sortOrder,
          sortBy: event.filterData.sortHeader,
        };

        this.getLocations();
        break;
      }
      case 'switch': {
        const location = this.list.list.find((x) => x.id == event.rowData.id);

        if (location == null) {
          return;
        }

        let statusSwitch = this.dialog.open(ConfirmationComponent, {
          data: {
            message: 'Are you sure you want to change this status?',
            icon: 'warning',
            action: 'Update',
          },
          width: '30vw',
        });
        statusSwitch.afterClosed().subscribe((result) => {
          if (result) {
            this.changeStatus(location);
          } else {
            event.rowData.isActive = !event.rowData.isActive;
          }
        });
        break;
      }
      case 'search': {
        this.locationFilter.SearchText = event.filterData.globalSearch;
        this.locationFilter.paging.pageNumber = 1;
        this.getLocations();
        break;
      }
      case 'clear': {
        this.locationFilter.SearchText = '';
        this.locationFilter.paging.pageNumber = 1;
        this.getLocations();
        break;
      }
    }
  }

  public ngOnDestroy() {
    this.list$.unsubscribe();
    this.scroller$.unsubscribe();
  }
}

export const header_data: any[] = [
  {
    title: 'Name',
    type: 'text',
    prop: 'name',
    sort: true,
    isFilter: true,
    isAsc: false,
    isDes: false,
  },
  {
    title: 'Code',
    type: 'text',
    prop: 'code',
    sort: true,
    isFilter: true,
    isAsc: false,
    isDes: false,
  },
  {
    title: 'Phone',
    type: 'text',
    prop: 'phone',
    sort: true,
    isFilter: true,
    isAsc: false,
    isDes: false,
  },
  {
    title: 'Status',
    type: 'slide',
    prop: 'isActive',
    sort: false,
    isFilter: false,
  },
];
