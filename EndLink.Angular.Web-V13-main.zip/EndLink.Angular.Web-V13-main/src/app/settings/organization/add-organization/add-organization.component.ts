import { paths, messages } from './../../../shared/constants';
import { MatDialog } from '@angular/material/dialog';
import { SuccessPopupComponent } from './../../../shared/components/success-popup/success-popup.component';
import { ToasterService } from 'src/app/services/toaster.service';
import { OrganizationService } from './../../../services/organization.service';
import { Component, OnInit } from '@angular/core';
import { Organization } from '../../../shared/models/organization';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-add-organization',
  templateUrl: './add-organization.component.html',
  styleUrls: ['./add-organization.component.scss']
})
export class AddOrganizationComponent implements OnInit {
  formValues: Organization = new Organization();
  isView: boolean = false;
  isUpdate: boolean = false;
  submitted: boolean = false;

  constructor(private route: ActivatedRoute, private router: Router, private organizationService: OrganizationService,
    private toastr: ToasterService, private dialog: MatDialog) { }

  ngOnInit(): void {
    this.route.params.subscribe(param => {
      if (!!param?.id) {
        this.isUpdate = true;
        if (!!!this.organizationService.selectedOrganization) {
          this.organizationService.get(param.id).subscribe((res: any) => {
            if (!res.isError) {
              this.formValues = Object.assign(new Organization(), res.responseObject);
            } else {
              this.toastr.showErrorMessage(res.message);
            }
          })
        } else {
          this.formValues = this.organizationService.selectedOrganization;
        }
      }
    });

    this.isView = this.router.url.indexOf('view') > -1;
  }

  checkRegex(value, reg) {
    let exp = new RegExp(reg);
    if (!value.key.match(exp)) {
      value.preventDefault();
      return false;
    }
    return true;
  }

  submit(isValid) {
    this.submitted = true;
    if (!isValid) {
      return;
    }

    if (this.isUpdate) {
      this.organizationService.update(this.formValues).subscribe((res: any) => {
        this.submitted = false;
        if (!res.isError) {
          let successDialog = this.dialog.open(SuccessPopupComponent, { data: { successMessage: messages.oraganizationUpdateSuccess } });
          successDialog.afterClosed().subscribe(res => this.router.navigate([paths.organizationList]))
        } else {
          this.toastr.showErrorMessage(res.message);
        }
      });
    } else {
      this.organizationService.create(this.formValues).subscribe((res: any) => {
        this.submitted = false;
        if (!res.isError) {
          let successDialog = this.dialog.open(SuccessPopupComponent, { data: { successMessage: messages.oraganizationCreateSuccess } });
          successDialog.afterClosed().subscribe(res => this.router.navigate([paths.organizationList]))
        } else {
          this.toastr.showErrorMessage(res.message);
        }
      });
    }

  }

  back() {
    window.history.back();
  }


  ngOnDestroy() {
    this.organizationService.selectedOrganization = null;
  }

}
