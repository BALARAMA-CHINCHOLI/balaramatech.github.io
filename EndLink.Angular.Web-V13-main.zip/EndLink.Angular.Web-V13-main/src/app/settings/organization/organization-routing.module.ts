import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/shared/helpers/auth.guard';
import { AddOrganizationComponent } from './add-organization/add-organization.component';
import { OrganizationComponent } from './organization.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: OrganizationComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'add',
    component: AddOrganizationComponent,
    data: { breadcrumb: 'Add Organization', title: 'Add Organization', isSinglePage: true },
    canActivate: [AuthGuard]
  },
  {
    path: 'view/:id',
    component: AddOrganizationComponent,
    data: { breadcrumb: 'View Organization', title: 'View Organization', isSinglePage: true },
    canActivate: [AuthGuard]
  },
  {
    path: 'edit/:id',
    component: AddOrganizationComponent,
    data: { breadcrumb: 'Edit Organization', title: 'Edit Organization', isSinglePage: true },
    canActivate: [AuthGuard]
  },
  {
    path: '**',
    redirectTo: ''
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class OrganizationRoutingModule { }
