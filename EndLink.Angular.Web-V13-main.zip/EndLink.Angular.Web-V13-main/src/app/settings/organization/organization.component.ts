import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { OrganizationService } from '../../services/organization.service';
import { ScrollerService } from '../../services/scroller-service.service';
import { ToasterService } from '../../services/toaster.service';
import { ConfirmationComponent } from '../../shared/components/confirmation/confirmation.component';
import { messages, paths } from '../../shared/constants';
import { SortingType } from '../../shared/enums/sorting-type';
import { ListModel } from '../../shared/models/list-model';
import { Organization } from '../../shared/models/organization';
import { Person } from '../../shared/models/person';
import { OrganizationFilter } from '../../shared/models/organization-filter';

@Component({
  selector: 'app-organization',
  templateUrl: './organization.component.html',
  styleUrls: ['./organization.component.scss'],
})
export class OrganizationComponent implements OnInit, OnDestroy {
  filter: OrganizationFilter = {
    paging: {
      pageNumber: 1,
      pageSize: 10,
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'Name',
    },
  };

  list: ListModel<Organization> = {
    list: [],
    hasNextPage: false,
  };

  organizationList$: any;
  scroller$: any;

  titleActions = [{ name: 'Add Organization', url: paths.organizationAdd }];

  constructor(
    private router: Router,
    private scroller: ScrollerService,
    private organizationservice: OrganizationService,
    private toaster: ToasterService,
    private dialog: MatDialog
  ) {}

  private header_data: any[] = [
    {
      title: 'Name',
      type: 'text',
      prop: 'name',
      sortProp: 'name',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Email',
      type: 'text',
      prop: 'email',
      sortProp: 'email',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Provider',
      type: 'text',
      prop: 'provider',
      sortProp: 'provider',
      sort: false,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Status',
      type: 'slide',
      prop: 'isActive',
      sortProp: 'isActive',
      sort: false,
      isFilter: false,
    },
  ];

  tableData: any = {
    headerData: [],
    rowData: [],
    noRecordFound: true,
  };

  ngOnInit() {
    this.tableData.noRecordFound = true;
    this.tableData.headerData = this.header_data;
    this.scroller$ = this.scroller.scroller$.pipe().subscribe((res) => {
      if (this.list.hasNextPage) {
        this.filter.paging.pageNumber++;
        this.getorganization();
      }
    });

    this.getorganization();
  }

  tableActions(event) {
    switch (event.action) {
      case 'view': {
        this.router.navigate([paths.organizationview + event.rowData.id]);
        break;
      }
      case 'edit': {
        this.router.navigate([paths.organizationEdit + event.rowData.id]);
        break;
      }
      case 'navigate': {
        this.router.navigate([event.rowData.url]);
      }
      case 'sort': {
        this.filter.paging.pageNumber = 1;
        this.filter.sorting = {
          order: event.filterData.sortOrder,
          sortBy: event.filterData.sortHeader,
        };

        this.getorganization();
        break;
      }
      case 'switch': {
        const org = this.list.list.find((x) => x.id == event.rowData.id);
        org.isActive = event.rowData.isActive;
        if (org == null) {
          return;
        }

        let statusSwitch = this.dialog.open(ConfirmationComponent, {
          data: {
            message: 'Are you sure you want to change this status?',
            icon: 'warning',
            action: 'Update',
          },
          width: '30vw',
        });
        statusSwitch.afterClosed().subscribe((result) => {
          if (result) {
            this.changeStatus(org);
          } else {
            event.rowData.isActive = !event.rowData.isActive;
          }
        });
        break;
      }
      case 'search': {
        this.filter.name = event.filterData.globalSearch;
        this.filter.paging.pageNumber = 1;
        this.getorganization();
        break;
      }
      case 'clear': {
        this.filter.name = '';
        this.filter.paging.pageNumber = 1;
        this.getorganization();
        break;
      }
    }
  }

  public changeStatus(org: any) {
    this.organizationservice.update(org).subscribe((res: any) => {
      if (res.isError) {
        this.toaster.showErrorMessage(res.message);
        org.isActive = !org.isActive;
      }
    });
  }

  getorganization() {
    this.organizationList$ = this.organizationservice
      .list(this.filter)
      .subscribe((data) => {
        if (this.filter.paging.pageNumber == 1) {
          this.list = data.responseObject;
          this.tableData.rowData = [];
        } else {
          data.responseObject.list.forEach((item) => {
            this.list.list.push(item);
          });
        }

        const tableData = [];
        this.list.list.forEach((item) => {
          tableData.push(this.parseTableData(item));
        });

        this.tableData.rowData = tableData;

        if (this.list.list.length > 0) {
          this.tableData.noRecordFound = false;
        }

        this.list.hasNextPage =
          data.responseObject.list && data.responseObject.list.length > 0;
      });
  }

  //public changeStatus(org: Organization) {

  //  org.isActive = !org.isActive;

  //  this.organizationservice.update(org).subscribe(() => {
  //    this.toaster.showSuccessMessage(messages.statusChangedSuccess);
  //  });
  //}

  private parseTableData(organization: Organization) {
    const channels = [];

    //person.communicationMethods.forEach((item) => {
    //  channels.push({ id: item.id, name: item.communicationMethodName });
    //})

    return {
      id: organization.id,
      name: organization.name,
      mobile: organization.mobile,
      email: organization.email,
      website: organization.website,
      work: organization.work,
      contactPerson: organization.contactPerson,
      isActive: organization.isActive,
      provider: organization.provider,
    };
  }

  public ngOnDestroy() {
    this.organizationList$.unsubscribe();
    this.scroller$.unsubscribe();
  }
}
