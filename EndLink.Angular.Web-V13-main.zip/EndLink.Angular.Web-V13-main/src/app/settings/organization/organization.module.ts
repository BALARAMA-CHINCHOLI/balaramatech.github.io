import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { OrganizationRoutingModule } from './organization-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { OrganizationComponent } from './organization.component';
import { AddOrganizationComponent } from './add-organization/add-organization.component';
import { ViewOrganizationComponent } from './view-organization/view-organization.component';
import {Ng2TelInputModule} from 'ng2-tel-input';


@NgModule({
  declarations: [OrganizationComponent, AddOrganizationComponent, ViewOrganizationComponent],
  imports: [
    CommonModule,
    FormsModule,
    Ng2TelInputModule,
    ReactiveFormsModule,
    SharedModule,
    OrganizationRoutingModule
  ]
})
export class OrganizationModule { }
