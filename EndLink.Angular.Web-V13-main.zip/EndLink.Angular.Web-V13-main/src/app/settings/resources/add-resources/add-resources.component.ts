import { trimTrailingNulls } from '@angular/compiler/src/render3/view/util';
import { Component, OnInit, OnDestroy } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { ResourceService } from 'src/app/services/resource.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { SuccessPopupComponent } from 'src/app/shared/components/success-popup/success-popup.component';
import { Audio } from 'src/app/shared/models/audio';
import { Resource } from 'src/app/shared/models/resource';

@Component({
  selector: 'app-add-resources',
  templateUrl: './add-resources.component.html',
  styleUrls: ['./add-resources.component.scss']
})
export class AddResourcesComponent implements OnInit, OnDestroy {
  submitted: boolean = false;
  
  isUpdate:boolean = false;
  isDisabled:boolean = false;
  formValues: Resource = new Resource();
  data: boolean;
  fname: boolean;
  id: any;
  lname: boolean;
  pname: boolean;
  cred: boolean;
  rid: any;
  code1: boolean;
  Audiofiles :any =[];
  constructor(private route: ActivatedRoute, private resourceService: ResourceService,
    private dialog: MatDialog, private router: Router, private toastr: ToasterService) { 
      
    }

  ngOnInit(): void {
    this.resourceService.getAudio().subscribe((m:any)=>{
      if(m && m.responseObject.list){
        this.Audiofiles = m.responseObject.list;
      }
    });
    this.route.params.subscribe(param => {
      if(!!param?.id) {
        this.isUpdate = true;
        if(!!!this.resourceService.selectedResrouce) {
          this.resourceService.getResrouce(param.id).subscribe((res:any)=> {
            if(!res.isError) {
              this.formValues = res.responseObject;
            } else {
              this.toastr.showErrorMessage(res.message);
            }
          })
        } else {
          this.formValues = this.resourceService.selectedResrouce;
        }
        this.route.queryParamMap.subscribe((param:any) => {
          this.isDisabled = !(param?.params?.type == 'edit');
        });
      }
    });
  }

  selectedValue: string;

  
  space(event){
    this.formValues.firstName=this.formValues.firstName?.trim();
    this.formValues.lastName=this.formValues.lastName?.trim();
    this.formValues.preferredName=this.formValues.preferredName?.trim();
    this.formValues.credentials=this.formValues.credentials?.trim();
    this.formValues.code=this.formValues.code?.trim();
    switch (this.rid) {
      case '1': {
        if (this.formValues.firstName.length==null) {
          this.fname = false

        }
        else {
          this.fname = true
        }
      }
        break;
      case '2': {
        
          if (this.formValues.lastName.length==null) {
            this.lname = false
  
          }
          else {
            this.lname = true
          }
        }
        break;
        case '3': {
        
          if (this.formValues.preferredName .length==null) {
            this.pname = false
  
          }
          else {
            this.pname = true
          }
        }
        break;  
        case '4': {
        
          if (this.formValues.credentials.length==null) {
            this.cred = false
  
          }
          else {
            this.cred = true
          }
        }
        break;  
        case '4': {
        
          if (this.formValues.code.length==null) {
            this.code1 = false
  
          }
          else {
            this.code1 = true
          }
        }
        break;  
      }


  }
  submit(isValid) {
    this.submitted=true;
    // this.formValues.firstName=this.formValues.firstName.replace(/^\s+|\s+$/g, '');
    // this.formValues.lastName=this.formValues.lastName.replace(/^\s+|\s+$/g, '');
    // this.formValues.preferredName=this.formValues.preferredName.replace(/^\s+|\s+$/g, '');
    // this.formValues.credentials=this.formValues.credentials.replace(/^\s+|\s+$/g, '');
    if(isValid) { 
      if(this.isUpdate) {
        this.resourceService.update(this.formValues).subscribe((res:any)=>{
          this.submitted=false;
          if(!res.isError) {
            let successDialog = this.dialog.open(SuccessPopupComponent, {data: {successMessage: 'Resource updated successfully'}});
            successDialog.afterClosed().subscribe(res=> this.router.navigate(['/settings/resource']))
          } else {
            this.toastr.showErrorMessage(res.message);
          }
        });
      } else {
        this.resourceService.create(this.formValues).subscribe((res:any)=>{
          this.submitted=false;
          if(!res.isError) {
            let successDialog = this.dialog.open(SuccessPopupComponent, {data: {successMessage: 'Resource added successfully'}});
            successDialog.afterClosed().subscribe(res => this.router.navigate(['/settings/resource']))
          }else {
            this.toastr.showErrorMessage(res.message);
          }
        });
      }
    }
  }

  back() {
    window.history.back();
  }

  ngOnDestroy() {
    this.resourceService.selectedResrouce = null;
  }

}
function trim(): string {
  throw new Error('Function not implemented.');
}

