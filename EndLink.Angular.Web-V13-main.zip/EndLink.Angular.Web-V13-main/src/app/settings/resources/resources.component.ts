import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ResourceService } from 'src/app/services/resource.service';
import { ScrollerService } from 'src/app/services/scroller-service.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { ConfirmationComponent } from 'src/app/shared/components/confirmation/confirmation.component';
import { messages, paths } from 'src/app/shared/constants';
import { SortingType } from 'src/app/shared/enums/sorting-type';
import { ListModel } from 'src/app/shared/models/list-model';
import { Resource } from 'src/app/shared/models/resource';
import { SearchFilter } from 'src/app/shared/models/search-filter';

@Component({
  selector: 'app-resources',
  templateUrl: './resources.component.html',
  styleUrls: ['./resources.component.scss'],
})
export class ResourcesComponent implements OnInit, OnDestroy {
  filter: SearchFilter = {
    paging: {
      pageNumber: 1,
      pageSize: 10,
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'FirstName',
    },
  };

  list: ListModel<Resource> = {
    list: [],
    hasNextPage: false,
  };

  list$: any;
  scroller$: any;

  constructor(
    private router: Router,
    private scroller: ScrollerService,
    private resourceService: ResourceService,
    private toaster: ToasterService,
    private dialog: MatDialog
  ) {}

  private header_data: any[] = [
    {
      title: 'First Name',
      type: 'text',
      prop: 'firstName',
      sortProp: 'firstName',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Last Name',
      type: 'text',
      prop: 'lastName',
      sortProp: 'lastName',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Preferred Name',
      type: 'text',
      prop: 'preferredName',
      sortProp: 'preferredName',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Code',
      type: 'text',
      prop: 'code',
      sortProp: 'code',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Status',
      type: 'slide',
      prop: 'isActive',
      sortProp: 'isActive',
      sort: false,
      isFilter: false,
    },
  ];

  tableData: any = {
    headerData: [],
    rowData: [],
    noRecordFound: true,
  };

  ngOnInit() {
    this.tableData.noRecordFound = true;
    this.tableData.headerData = this.header_data;
    this.scroller$ = this.scroller.scroller$
      .pipe
      //throttle(ev => this.employeeList$)
      ()
      .subscribe((res) => {
        if (this.list.hasNextPage) {
          this.filter.paging.pageNumber++;
          this.getList();
        }
      });

    this.getList();
  }

  tableActions(event) {
    switch (event.action) {
      case 'view': {
        this.resourceService.selectedResrouce = event.rowData;
        this.router.navigate([paths.resrouceView + event.rowData.id]);
        break;
      }
      case 'edit': {
        this.resourceService.selectedResrouce = event.rowData;
        this.router.navigate([paths.resourceEdit + event.rowData.id], {
          queryParams: { type: 'edit' },
        });
        break;
      }
      case 'sort': {
        this.filter.paging.pageNumber = 1;
        this.filter.sorting = {
          order: event.filterData.sortOrder,
          sortBy: event.filterData.sortHeader,
        };

        this.getList();
        break;
      }
      case 'switch': {
        const item = this.list.list.find((x) => x.id == event.rowData.id);

        if (item == null) {
          return;
        }

        let statusSwitch = this.dialog.open(ConfirmationComponent, {
          data: {
            message: 'Are you sure you want to update this Resources?',
            icon: 'warning',
            action: 'Update',
          },
          width: '30vw',
        });
        statusSwitch.afterClosed().subscribe((result) => {
          if (result) {
            this.changeStatus(item);
          } else {
            event.rowData.isActive = !event.rowData.isActive;
          }
        });
        break;
      }
      case 'search': {
        this.filter.SearchText = event.filterData.globalSearch;
        this.filter.paging.pageNumber = 1;
        this.getList();
        break;
      }
      case 'clear': {
        this.filter.SearchText = '';
        this.filter.paging.pageNumber = 1;
        this.getList();
        break;
      }
    }
  }

  getList() {
    this.list$ = this.resourceService.list(this.filter).subscribe((data) => {
      if (this.filter.paging.pageNumber == 1) {
        this.list = data.responseObject;
        this.tableData.rowData = [];
      } else {
        data.responseObject.list.forEach((item) => {
          this.list.list.push(item);
        });
      }

      this.tableData.rowData = this.list.list;

      if (this.list.list.length > 0) {
        this.tableData.noRecordFound = false;
      }
      this.list.hasNextPage =
        data.responseObject.list && data.responseObject.list.length > 0;
    });
  }

  public changeStatus(item: Resource) {
    this.resourceService.update(item).subscribe((res: any) => {
      if (res.isError) {
        this.toaster.showErrorMessage(res.message);
        item.isActive = !item.isActive;
      }
    });
  }

  public ngOnDestroy() {
    this.list$.unsubscribe();
    this.scroller$.unsubscribe();
  }
}
