import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddResourcesComponent } from './add-resources/add-resources.component';
import { ResourcesComponent } from './resources.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: ResourcesComponent
  },
  {
    path: 'add',
    component: AddResourcesComponent,
    data: { breadcrumb: 'Add Resources', title: 'Add Resource', isSinglePage: true }
  },
  {
    path: 'edit/:id',
    component: AddResourcesComponent,
    data: { breadcrumb: 'Edit Resources', title: 'Edit Resources', isSinglePage: true }
  },
  {
    path: 'view/:id',
    component: AddResourcesComponent,
    data: { breadcrumb: 'View Resources', title: 'View Resources', isSinglePage: true }
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ResourcesRoutingModule { }
