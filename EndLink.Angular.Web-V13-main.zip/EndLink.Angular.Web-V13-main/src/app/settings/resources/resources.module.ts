import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ResourcesRoutingModule } from './resources-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ResourcesComponent } from './resources.component';
import { AddResourcesComponent } from './add-resources/add-resources.component';


@NgModule({
  declarations: [ResourcesComponent, AddResourcesComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    ResourcesRoutingModule
  ]
})
export class ResourcesModule { }
