import { SortingType } from './../../../shared/enums/sorting-type';
import { OrganizationFilter } from './../../../shared/models/organization-filter';
import { OrganizationService } from './../../../services/organization.service';
import { debounceTime } from 'rxjs/operators';
import { FormControl } from '@angular/forms';
import { Organization } from './../../../shared/models/organization';
import { Observable, of } from 'rxjs';
import { paths, messages } from './../../../shared/constants';
import { SuccessPopupComponent } from './../../../shared/components/success-popup/success-popup.component';
import { MatDialog } from '@angular/material/dialog';
import { ToasterService } from './../../../services/toaster.service';
import { ProviderService } from './../../../services/provider.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Provider } from './../../../shared/models/provider';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-provider',
  templateUrl: './add-provider.component.html',
  styleUrls: ['./add-provider.component.scss']
})
export class AddProviderComponent implements OnInit {
  formValues: Provider = new Provider();
  isDisabled: boolean = false;
  isView: boolean = false;
  isUpdate: boolean = false;
  submitted: boolean = false;
  /*organizations: Organization[] = [];*/
  organization: any;
  org: any;
  name: any;
  organizationControl: FormControl = new FormControl('', []);
  autoCompleteLoader: boolean = false;
  filter: OrganizationFilter = {
    paging: {
      pageNumber: 1,
      pageSize: 5
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'Name'
    }
  };
  data: boolean;
  data1: boolean;
  id: any;
  sname: boolean;
  uname: boolean;
  sid: any;
  tname: boolean;

  constructor(private route: ActivatedRoute, private router: Router, private providerService: ProviderService,
    private toastr: ToasterService, private dialog: MatDialog, private organizationService: OrganizationService) { }

  ngOnInit(): void {
    this.organizationControl.setValue('');
    this.route.params.subscribe(param => {
      if (!!param?.id) {
        this.isUpdate = true;
        if (!!!this.providerService.selectedProvider) {
          this.providerService.get(param.id).subscribe((res: any) => {
            if (!res.isError) {
              this.formValues = Object.assign(new Provider(), res.responseObject);
            } else {
              this.toastr.showErrorMessage(res.message);
            }
          })
        }
        else {
          this.formValues = this.providerService.selectedProvider;
        }
        this.isDisabled = (this.route.snapshot.url.join().split(',')[0] != 'edit');
        this.isView = (this.route.snapshot.url.join().split(',')[0] == 'view');
        if (this.isDisabled) {
          this.organizationControl.disable();
        }
        else {
          this.organizationControl.enable();
        }
      }
    });

    this.organizationControl.valueChanges.pipe(debounceTime(500)).subscribe((searchTerm) => {
      this.filter.name = searchTerm;
      this.autoCompleteLoader = true;
    });

    this.getOrganization();
  }

  private getOrganization() {
    this.organization = localStorage.getItem("endlink.currentUser")
    const obj = JSON.parse(this.organization);
    this.org = obj.organization;
    this.organizationService.get(this.org).subscribe((res: any) => {
      this.formValues.organizationId = res.responseObject.id;
      this.formValues.organizationName = res.responseObject.name;
    });
  }

  checkRegex(value, reg) {
    let exp = new RegExp(reg);
    if (!value.key.match(exp)) {
      value.preventDefault();
      return false;
    }
    return true;
  }

  _organizationAutoComplete(organization) {
    if (!!organization) {
      return organization.name;
    }
  }
  space(event) {
    this.formValues.name = this.formValues.name?.trim();
    this.formValues.userName = this.formValues.userName?.trim();
    switch (this.id) {
      case '1': {
        if (this.formValues.name.length == null) {
          this.tname = false

        }
        else {
          this.tname = true
        }
      }
        break;
      case '2': {

        if (this.formValues.userName.length == null) {
          this.uname = false
        }
        else {
          this.uname = true
        }
      }
        break;


    }
  }

  submit(isValid) {
    if (isValid) {
      this.submitted = true;
      const organizationName = typeof this.formValues.organizationName == 'object' ? this.formValues.organizationName['name'] : this.formValues.organizationName;
      let data = Object.assign({ ...this.formValues });
      if (this.isUpdate) {
        this.providerService.update(data).subscribe((res: any) => {
          this.submitted = false;
          if (!res.isError) {
            let successDialog = this.dialog.open(SuccessPopupComponent, { data: { successMessage: messages.entityUpdateSuccess } });
            successDialog.afterClosed().subscribe(res => this.router.navigate([paths.providersList]))
          } else {
            this.toastr.showErrorMessage(res.message);
          }
        });
      } else {
        this.providerService.create(data).subscribe((res: any) => {
          this.submitted = false;
          if (!res.isError) {
            let successDialog = this.dialog.open(SuccessPopupComponent, { data: { successMessage: messages.entityCreateSuccess } });
            successDialog.afterClosed().subscribe(res => this.router.navigate([paths.providersList]))
          } else {
            this.toastr.showErrorMessage(res.message);
          }
        });
      }
    }
  }

  back() {
    window.history.back();
  }

}
