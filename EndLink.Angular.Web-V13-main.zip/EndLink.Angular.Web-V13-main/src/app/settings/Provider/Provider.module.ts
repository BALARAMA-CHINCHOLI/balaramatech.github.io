import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { SharedModule } from './../../shared/shared.module';
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProviderRoutingModule } from './provider-routing.module';
import { ProviderComponent } from './provider.component';
import { AddProviderComponent } from './add-provider/add-provider.component';
import {Ng2TelInputModule} from 'ng2-tel-input';


@NgModule({
  declarations: [ProviderComponent, AddProviderComponent],
  imports: [
    CommonModule,
    FormsModule,
    Ng2TelInputModule,
    ReactiveFormsModule,
    SharedModule,
    ProviderRoutingModule
  ]
})
export class ProviderModule { }
