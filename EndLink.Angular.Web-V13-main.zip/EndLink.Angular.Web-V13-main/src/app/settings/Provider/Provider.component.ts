import { ProviderService } from './../../services/provider.service';
import { ProviderFilter } from './../../shared/models/provider-filter';
import { Provider } from './../../shared/models/provider';
import { ConfirmationComponent } from './../../shared/components/confirmation/confirmation.component';
import { paths, messages } from './../../shared/constants';
import { MatDialog } from '@angular/material/dialog';
import { ToasterService } from '../../services/toaster.service';
import { ScrollerService } from './../../services/scroller-service.service';
import { Router } from '@angular/router';
import { ListModel } from './../../shared/models/list-model';
import { SortingType } from './../../shared/enums/sorting-type';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-provider',
  templateUrl: './provider.component.html',
  styleUrls: ['./provider.component.scss'],
})
export class ProviderComponent implements OnInit {
  filter: ProviderFilter = {
    paging: {
      pageNumber: 1,
      pageSize: 10,
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'Name',
    },
  };

  list: ListModel<Provider> = {
    list: [],
    hasNextPage: false,
  };

  providerList$: any;
  scroller$: any;

  titleActions = [{ name: 'Add Entity', url: paths.providerAdd }];

  constructor(
    private router: Router,
    private scroller: ScrollerService,
    private providerService: ProviderService,
    private toaster: ToasterService,
    private dialog: MatDialog
  ) {}

  private header_data: any[] = [
    {
      title: 'Name',
      type: 'text',
      prop: 'name',
      sortProp: 'name',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Email',
      type: 'text',
      prop: 'email',
      sortProp: 'email',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Status',
      type: 'slide',
      prop: 'isActive',
      sortProp: 'isActive',
      sort: false,
      isFilter: false,
    },
  ];

  tableData: any = {
    headerData: [],
    rowData: [],
    noRecordFound: true,
  };

  ngOnInit() {
    this.tableData.noRecordFound = true;
    this.tableData.headerData = this.header_data;
    this.scroller$ = this.scroller.scroller$.pipe().subscribe((res) => {
      if (this.list.hasNextPage) {
        this.filter.paging.pageNumber++;
        this.getprovider();
      }
    });

    this.getprovider();
  }

  tableActions(event) {
    switch (event.action) {
      case 'view': {
        this.router.navigate([paths.providerview + event.rowData.id]);
        break;
      }
      case 'edit': {
        this.router.navigate([paths.providerEdit + event.rowData.id]);
        break;
      }
      case 'navigate': {
        this.router.navigate([event.rowData.url]);
        break;
      }
      case 'sort': {
        this.filter.paging.pageNumber = 1;
        this.filter.sorting = {
          order: event.filterData.sortOrder,
          sortBy: event.filterData.sortHeader,
        };

        this.getprovider();
        break;
      }
      case 'switch': {
        const provider = this.list.list.find((x) => x.id == event.rowData.id);
        provider.isActive = event.rowData.isActive;
        provider.mobile = provider.mobile === null ? '' : provider.mobile;
        provider.email = provider.email === null ? '' : provider.email;
        provider.userName = provider.userName === null ? '' : provider.userName;
        provider.userEmail =
          provider.userEmail === null ? '' : provider.userEmail;
        if (provider == null) {
          return;
        }

        let statusSwitch = this.dialog.open(ConfirmationComponent, {
          data: {
            message: 'Are you sure you want to change this status?',
            icon: 'warning',
            action: 'Update',
          },
          width: '30vw',
        });
        statusSwitch.afterClosed().subscribe((result) => {
          if (result) {
            this.changeStatus(provider);
          } else {
            event.rowData.isActive = !event.rowData.isActive;
          }
        });
        break;
      }
      case 'search': {
        this.filter.name = event.filterData.globalSearch;
        this.filter.paging.pageNumber = 1;
        this.getprovider();
        break;
      }
      case 'clear': {
        this.filter.name = '';
        this.filter.paging.pageNumber = 1;
        this.getprovider();
        break;
      }
    }
  }
  public changeStatus(provider: any) {
    this.providerService.update(provider).subscribe((res: any) => {
      if (res.isError) {
        this.toaster.showErrorMessage(res.message);
        provider.isActive = !provider.isActive;
      }
    });
  }

  getprovider() {
    this.providerList$ = this.providerService
      .list(this.filter)
      .subscribe((data: any) => {
        if (this.filter.paging.pageNumber == 1) {
          this.list = data.responseObject;
          this.tableData.rowData = [];
        } else {
          data.responseObject.list.forEach((item) => {
            this.list.list.push(item);
          });
        }

        const tableData = [];
        this.list.list.forEach((item) => {
          tableData.push(this.parseTableData(item));
        });

        this.tableData.rowData = tableData;

        if (this.list.list.length > 0) {
          this.tableData.noRecordFound = false;
        }

        this.list.hasNextPage =
          data.responseObject.list && data.responseObject.list.length > 0;
      });
  }

  //public changeStatus(org: Provider) {

  //  org.isActive = !org.isActive;

  //  this.providerService.update(org).subscribe(() => {
  //    this.toaster.showSuccessMessage(messages.statusChangedSuccess);
  //  });
  //}

  private parseTableData(provider: Provider) {
    const channels = [];

    //person.communicationMethods.forEach((item) => {
    //  channels.push({ id: item.id, name: item.communicationMethodName });
    //})

    return {
      id: provider.id,
      name: provider.name,
      mobile: provider.mobile === null ? '' : provider.mobile,
      email: provider.email === null ? '' : provider.email,
      isActive: provider.isActive,
      username: provider.userName === null ? '' : provider.userName,
      useremail: provider.userEmail === null ? '' : provider.userEmail,
      OrganizationId: provider.organizationId,
      IsAdmin: provider.isAdmin,
      OrganizationName: provider.organizationName,
    };
  }

  public ngOnDestroy() {
    this.providerList$.unsubscribe();
    this.scroller$.unsubscribe();
  }
}
