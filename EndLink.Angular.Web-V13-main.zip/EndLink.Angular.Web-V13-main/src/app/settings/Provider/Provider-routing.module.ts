import { ProviderComponent } from './provider.component';
import { AddProviderComponent } from './add-provider/add-provider.component';
import { AuthGuard } from './../../shared/helpers/auth.guard';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

const routes: Routes = [
  {
    path : '',
    pathMatch: 'full',
    component: ProviderComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'add',
    component: AddProviderComponent,
    data: { breadcrumb: 'Add Entity', title: 'Add Entity', isSinglePage: true },
    canActivate: [AuthGuard]
  },
  {
    path: 'view/:id',
    component: AddProviderComponent,
    data: { breadcrumb: 'View Entity', title: 'View Entity', isSinglePage: true },
    canActivate: [AuthGuard]
  },
  {
    path: 'edit/:id',
    component: AddProviderComponent,
    data: { breadcrumb: 'Edit Entity', title: 'Edit Entity', isSinglePage: true },
    canActivate: [AuthGuard]
  },
  {
    path: '**',
    redirectTo: ''
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ProviderRoutingModule { }
