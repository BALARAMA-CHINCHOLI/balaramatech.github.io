import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ApprovalsRoutingModule } from './approvals-routing.module';
import { ApprovalsComponent } from './approvals.component';
import { FormsModule } from '@angular/forms';
import { SharedModule } from 'src/app/shared/shared.module';
import { ViewApprovalComponent } from './view-approval/view-approval.component';
import { PreviewModule } from '../../campaign/add-campaign/preview/preview.module';


@NgModule({
  declarations: [ApprovalsComponent, ViewApprovalComponent],
  imports: [
    CommonModule,
    ApprovalsRoutingModule,
    FormsModule,
    SharedModule,
    PreviewModule,
  ]
})
export class ApprovalsModule { }
