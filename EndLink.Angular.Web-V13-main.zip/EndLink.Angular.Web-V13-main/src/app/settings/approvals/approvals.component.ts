import { DatePipe } from '@angular/common';
import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { ScrollerService } from 'src/app/services/scroller-service.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { ConfirmationComponent } from 'src/app/shared/components/confirmation/confirmation.component';
import { SortingType } from 'src/app/shared/enums/sorting-type';
import { ListModel } from 'src/app/shared/models/list-model';
import { SearchFilter } from 'src/app/shared/models/search-filter';
import * as _moment from 'moment';
import { CampaignStatusType } from 'src/app/shared/enums/campaign-status-type';
import { ApprovalsService } from '../../services/dataServices/approvals.service';
import { Approvals } from 'src/app/shared/models/approvals';
import { paths } from '../../shared/constants';

const moment = _moment;

@Component({
  selector: 'app-approvals',
  templateUrl: './approvals.component.html',
  styleUrls: ['./approvals.component.scss']
})
export class ApprovalsComponent implements OnInit, OnDestroy {
  headerData: any[] = [
    {
      title: 'Type',
      type: 'text',
      prop: 'Type',
      sort: false,
      isFilter: false,
      isAsc: false,
      isDesc: false,
    },
    {
      title: 'Name',
      type: 'text',
      prop: 'Name',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Sent By',
      type: 'text',
      prop: 'SentBy',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Sent Date',
      type: 'text',
      prop: 'SentDate',
      sort: false,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Status',
      type: 'status',
      prop: 'Status',
      sort: false,
      isFilter: true,
    },
  ];

  typesFilter = [];
  statusFilter = [];

  approvalFilter: SearchFilter = {
    SearchText: '',
    paging: {
      pageNumber: 1,
      pageSize: 10,
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'Name',
    },
  };

  list: ListModel<any> = {
    list: [],
    hasNextPage: false,
  };

  tableData: any = {
    headerData: [],
    rowData: [],
    noRecordFound: true,
  };

  scrollerSubscribe: any;
  searchSubject: Subject<string> = new Subject<string>();

  constructor(
    private approvalService: ApprovalsService,
    private router: Router,
    private dialog: MatDialog,
    private toaster: ToasterService,
    private scroller: ScrollerService,
    private datepipe: DatePipe
  ) {}

  ngOnInit(): void {
    this.statusFilter = ['3'];
    this.getApprovals();
    this.tableData.headerData = this.headerData;
    this.tableData.noRecordFound = true;
    this.scrollerSubscribe = this.scroller.scroller$.pipe().subscribe((res) => {
      if (this.list && this.list.hasNextPage) {
        this.approvalFilter.paging.pageNumber++;
        this.getApprovals();
      }
    });
    this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe((search) => {
        this.approvalFilter.paging.pageNumber = 1;
        this.getApprovals();
      });
  }

  getApprovals(): void {
    this.approvalService.list(this.approvalFilter, this.typesFilter, this.statusFilter).subscribe((data: any) => {
      if (this.approvalFilter.paging.pageNumber === 1) {
        this.list.list = data.responseObject;
        this.tableData.rowData = [];
      } else if(data.responseObject){
        data.responseObject.forEach((item) => {
          this.list.list.push(item);
        });
      }

      const tableData = [];
      this.list.list.forEach((item) => {
        tableData.push(this.parseTableData(item));
      });

      this.tableData.rowData = tableData;

      if (this.list && this.list.list && this.list.list.length > 0) {
        this.tableData.noRecordFound = false;
      }
      this.list.hasNextPage =
        data.responseObject && data.responseObject.length > 0;
    });
  }

  private parseTableData(approval: Approvals): any {
    return {...approval,
          SentDate: !!!approval.SentDate ||
                approval.SentDate == null ||
                approval.SentDate === new Date('0001-01-01T00:00:00')
                 ? '-'
                 : moment(approval.SentDate).format('MM/DD/YYYY'),
          hideApproveBtn: !(approval.Status === 'Pending Approval'),
          hideRejectBtn: !(approval.Status === 'Pending Approval')
        };
  }

  search(event): void {
    this.searchSubject.next(event);
  }

  filterByStatus(event): void {
    this.approvalFilter.SearchText = event[0] || '' ;
    this.approvalFilter.paging.pageNumber = 1;
    this.getApprovals();
  }

  tableActions(event): void {
    switch (event.action) {
      case 'view': {
        this.approvalService.selectedApproval = event.rowData;
        switch(event.rowData.Type) {
          case "Workflow":
            this.router.navigate(['/workflow/view/'+event.rowData.EntityId])
            break;
          case 'Campaign':
            this.router.navigate([paths.approvalView + event.rowData.EntityId]);
            break;
          case 'Rule':
            this.router.navigate(['/settings/rules/view/'+ event.rowData.EntityId]);
            break;
        }
        break;
      }
      case 'search': {
        this.approvalFilter.SearchText = event.filterData.globalSearch;
        this.approvalFilter.paging.pageNumber = 1;
        this.getApprovals();
        break;
      }
      case 'clear': {
        this.approvalFilter.SearchText = '';
        this.getApprovals();
        break;
      }
      case 'sort': {
        this.approvalFilter.sorting.sortBy = event.filterData.sortHeader;
        this.approvalFilter.sorting.order = event.filterData.sortOrder;
        this.getApprovals();
        break;
      }
      case 'approve': {
        this.changeStatus(event.rowData, CampaignStatusType.Approved);
        break;
      }
      case 'reject': {
        const abortConfirm = this.dialog.open(ConfirmationComponent, {
          data: {
            message: 'Are you sure you want to reject this Campaign?',
            icon: 'warning',
            action: 'Reject',
          },
        });
        abortConfirm.afterClosed().subscribe((result) => {
          if (result) {
            this.changeStatus(event.rowData, CampaignStatusType.Rejected);
          }
        });
        break;
      }
    }
  }

  changeStatus(item, status): void {
    this.approvalService.updateStatus(item.EntityId, item.Type, status).subscribe(
      (res) => {
        if (!res.isError) {
          this.approvalFilter.paging.pageNumber = 1;
          this.getApprovals();
        } else {
          this.toaster.showErrorMessage(res.message);
        }
      },
      (err) => {
        this.toaster.showErrorMessage(err.message);
      }
    );
  }

  ngOnDestroy(): void {
    this.scrollerSubscribe.unsubscribe();
  }
}
