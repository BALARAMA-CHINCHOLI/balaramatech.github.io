import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { MembersService } from 'src/app/services/members.service';
import { CampaignService } from '../../../services/campaign.service';
import { ApprovalsService } from '../../../services/dataServices/approvals.service';
import { ToasterService } from '../../../services/toaster.service';
import { Campaign } from '../../../shared/models/campaign';
import { ChannelAction, Language } from '../../../shared/models/channel-action';
import { CommunicationChannel } from '../../../shared/models/communication-channel';
import { Person } from '../../../shared/models/person';

@Component({
  selector: 'app-view-approval',
  templateUrl: './view-approval.component.html',
  styleUrls: ['./view-approval.component.scss']
})
export class ViewApprovalComponent implements OnInit {

  constructor(private approvalService: ApprovalsService, private router: Router, private campaignService: CampaignService,
              private toaster: ToasterService, private route: ActivatedRoute, private memberService: MembersService) { }

  ngOnInit(): void {
    if (!!this.approvalService.selectedApproval) {
      this.loadModule(this.approvalService.selectedApproval.EntityId, this.approvalService.selectedApproval.Type);
    } else {
      this.route.params.subscribe(params => {
        if (!!params.id) {
          const type = this.approvalService.selectedApproval ? this.approvalService.selectedApproval.EntityId : 'campaign'
          this.loadModule(params.id, type);
        }
      });
    }
  }

  loadModule(id, type): void {
    switch (type.toLowerCase()) {
      case 'campaign':
        this.campaignService.campaignId.next(id);
        this.campaignService.get(id).subscribe(
          (res: any) => {
            if (!res?.isError) {
              this.campaignService.configureCampaign.next(
                new Campaign(res.responseObject)
              );
              const selectedMembers = res.responseObject.receipients.persons.map(
                (member) => Object.assign(new Person(), member.person)
              );
              this.memberService.selectedMembers.next(selectedMembers);
              this.campaignService.isRecipientsUpdated = true;
              const selectedGroups = res.responseObject.receipients.groups.map(
                (selection) => selection.group
              );
              this.campaignService.campaignRecipientGroups.next(selectedGroups);
              this.campaignService.isRecipientsUpdated = true;
              this.campaignService.campaignRecipientUploads.next(res.responseObject.receipients.files);
              const actionsList = res.responseObject.actions.map((action) => {
                const channel = new ChannelAction();
                channel.CampaignId = action.campaignId;
                channel.CommunicationChannel = action.communicationChannel as CommunicationChannel;
                channel.action = 'add';
                if (!!action?.mediaUrl) {
                  channel.MediaUrl = action.mediaUrl;
                }
                channel.template = action.template;
                channel.language = action.language as Language;
                return channel;
              });
              this.campaignService.campaignActions.next(actionsList);
              this.campaignService.campaignSchedule.next(res.responseObject.plans);
            } else {
              this.toaster.showErrorMessage(res.message);
            }
          },
          (err) => {
            this.toaster.showErrorMessage(err.message);
          }
        );
    }
  }

}
