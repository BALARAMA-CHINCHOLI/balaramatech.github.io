import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ApprovalsComponent } from './approvals.component';
import { ViewApprovalComponent } from './view-approval/view-approval.component';

const routes: Routes = [
  {
    path: '',
    component: ApprovalsComponent
  },
  {
    path: 'view/:id',
    component: ViewApprovalComponent,
    children: [
      {
        path: 'campaign',
        loadChildren: () => import('../../campaign/add-campaign/preview/preview.module').then(m => m.PreviewModule)
      },
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'campaign'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ApprovalsRoutingModule { }
