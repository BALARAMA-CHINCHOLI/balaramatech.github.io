import { Component, OnInit } from '@angular/core';
import { Color } from 'ng2-charts';

import { Chart } from 'src/app/shared/models/chart';
import { CampaignService } from '../services/campaign.service';
import { DashboardService } from '../services/dashboard.service';
import { BusinessUnitService } from '../services/dataServices/business-unit.service';
import { Response } from '../shared/models/response';
import { SearchFilter } from '../shared/models/search-filter';
import { ThemeService } from '../theme/theme.service';

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

  type = {
    latestCampaign: 1,
    latestWorkflow: 2,
    workflowStats: 3,
    workflowStatsChannels: 4,
    channelAllocation: 5,
    consentStats: 6,
    onlyConsentStats:7
  };

  periods = [
    {
      value: 0,
      name: 'Today'
    },
    {
      value: 1,
      name: 'Week'
    },
    {
      value: 2,
      name: 'Month'
    },
    {
      value: 3,
      name: 'Year'
    }
  ];
  selectedPeriod = 1;
  selectedWorkflow = 0;
  selectedDepartment = 0;
  selectedCampaign = 0;
  latestCampaigns = [];
  latestWorkflows = [];
  workflowStats = [];
  channelAllocations = [];
  consentStats = [];
  workflowChannelStats = [];
  businessUnits = [];
  barChart: Chart = new Chart({
    type: 'bar',
    chartPlugins: [],
    chartOptions: {
      responsive: true,
      tooltips: {
        enabled: true,
        intersect: true,
        titleFontSize: 16,
        callbacks: {
          // tslint:disable-next-line: typedef
          title: function (tooltipItem, data) {
            const dataset = data.datasets[tooltipItem[0].datasetIndex];
            return dataset.stack;
          },
        }
      },
      plugins: {
        datalabels: {
          display: true,
          align: 'center',
          anchor: 'center',
        },
      }
    },
    labels: [],
    showLegend: false,
    data: []
  });
  businessUnitfilter = new SearchFilter();

  constructor(private themeService: ThemeService,
    private dashboardService: DashboardService,
    private campaignService: CampaignService,
    private businessUnitService: BusinessUnitService) {
    this.businessUnitfilter.paging = { pageSize: 10000, pageNumber: 1 };
  }

  ngOnInit() {
    this.getLatestCampaigns();
    this.getLatestWorkflows();
    this.getWorkflowStats();
    this.getDepartments();
  }

  // toggle() {
  //   // const active = this.themeService.getActiveTheme() ;
  //   const body = document.body;
  //   if (!body.classList.contains('darkMode')) {
  //     document.body.classList.add("darkMode");
  //   } else {
  //     document.body.classList.remove("darkMode");
  //   }
  // }

  getLatestCampaigns() {
    this.latestCampaigns = [];
    this.dashboardService.get(this.type.latestCampaign).subscribe((data: Response) => {
      if (data.responseObject && data.responseObject != '') {
        this.latestCampaigns = JSON.parse(data.responseObject);
      }

      if (this.latestCampaigns && this.latestCampaigns.length > 0) {
        this.latestCampaigns.forEach((item) => {
          item.Channels = !!item.ChannelType ? item.ChannelType.split(','):"";
        });
        this.selectedCampaign = this.latestCampaigns[0].Id;
        this.getConsentStats();
      }
    });
  }

  getLatestWorkflows() {
    this.latestWorkflows = [];
    this.dashboardService.get(this.type.latestWorkflow).subscribe((data: Response) => {
      if (data.responseObject && data.responseObject != '') {
        this.latestWorkflows = JSON.parse(data.responseObject);
      }

      if (this.latestWorkflows.length > 0) {
        this.selectedWorkflow = this.latestWorkflows[0].Id;
        this.getWorkflowChannelStats();
      }
    });
  }

  getWorkflowStats() {
    this.workflowStats = [];
    this.dashboardService.get(this.type.workflowStats, null, this.selectedPeriod).subscribe((data: Response) => {
      if (data.responseObject && data.responseObject != '') {
        this.workflowStats = JSON.parse(data.responseObject);
      }
    });
  }

  getChannelAllocation() {
    this.channelAllocations = [];
    this.dashboardService.get(this.type.channelAllocation, this.selectedDepartment).subscribe((data: Response) => {
      if (data.responseObject && data.responseObject != '') {
        this.channelAllocations = JSON.parse(data.responseObject);

        this.channelAllocations.forEach((item) => {
          item.percentage = item.Threshold / item.Allocated * 100;
        });
      }
    });
  }

  getConsentStats() {
    this.consentStats = [];
    this.barChart.labels = [];
    this.barChart.data = [];
    this.dashboardService.get(this.type.onlyConsentStats, this.selectedCampaign).subscribe((data: Response) => {
      if (data.responseObject && data.responseObject != '') {
        this.consentStats = JSON.parse(data.responseObject);

        const chartData = {
          data: this.consentStats.map(x => x.TotalCount)
        }

        this.consentStats.forEach((item) => {
          
        });
        this.barChart.data.push(chartData);
        this.barChart.labels = this.consentStats.map(x => x.Status)
      }
    });
  }

  getDepartments() {
    this.businessUnits = [];
    this.businessUnitService.list(this.businessUnitfilter).subscribe((res: any) => {
      this.businessUnits = res.responseObject.list;

      if (this.businessUnits.length > 0) {
        this.selectedDepartment = this.businessUnits[0].id;
        this.getChannelAllocation();
      }
    });
  }

  getWorkflowChannelStats() {
    this.workflowChannelStats = [];
    this.campaignService.campaignId.next(this.selectedWorkflow);
    this.campaignService.viewCampaign('summary').subscribe((res) => {
      if (!res.isError) {
        if (res.responseObject.Channels.length > 0) {
          this.generateChannelsData(res.responseObject.Channels);
        }
      }
    });
  }

  private generateChannelsData(channels: any) {
    const channelsData = [];
    channels.forEach(element => {
      const existingElement = channelsData.find(x => x.channelId == element.ChannelId);
      if (existingElement == null) {
        channelsData.push({
          channelId: element.ChannelId,
          channel: element.Channel,
          attempts: [
            {
              attempt: element.Attempt,
              successCount: element.Status == 'Sent' ? element.Counts : 0,
              errorCount: element.Status == 'Error' ? element.Counts : 0,
            }
          ],
          consents: [
            {
              consent: element.Consent,
              count: element.Counts
            }
          ],
          totalSuccess: element.Status == 'Sent' ? element.Counts : 0,
          totalError: element.Status == 'Error' ? element.Counts : 0
        });
      } else {
        const existingAttempt = existingElement.attempts.find(x => x.attempt == element.Attempt);

        if (existingAttempt == null) {
          existingElement.attempts.push({
            attempt: element.Attempt,
            successCount: element.Status == 'Sent' ? element.Counts : 0,
            errorCount: element.Status == 'Error' ? element.Counts : 0,
          });
        } else {
          if (element.Status == 'Sent') {
            existingAttempt.successCount += element.Counts;
            existingElement.totalSuccess += element.Counts;
          } else {
            existingAttempt.errorCount += element.Counts;
            existingElement.totalError += element.Counts;
          }
        }

        const existingConsent = existingElement.consents.find(x => x.consent == element.Consent);

        if (existingConsent == null) {
          existingElement.consents.push({
            consent: element.Consent,
            count: element.Counts
          });
        } else {
          existingConsent.count += element.Counts;
        }
      }
    });
    this.workflowChannelStats = channelsData;
  }
  getChannelIcon(channelName: string) {
    if(!!channelName){
    switch (channelName.toUpperCase()) {
      case 'SMS':
        return 'icon-sms.png';
        break;
      case 'EMAIL':
        return 'icon-mail.png';
        break;
      case 'VOICE':
        return 'icon-voice.png';
        break;
      case 'MMS':
        return 'icon-mms.png';
        break;
    }
  }
}

}
