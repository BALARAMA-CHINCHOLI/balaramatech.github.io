import { LandingPageService } from './../services/landing-page.service';
import { AuthenticationService } from './../services/authentication.service';
import { Injectable } from '@angular/core';
import { CanLoad, Route, UrlSegment, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree, Router } from '@angular/router';
import { Observable } from 'rxjs';

@Injectable()
export class AuthLoadGuard implements CanLoad {
  constructor(
    private router: Router,
    private authService: AuthenticationService,
    private landing:LandingPageService
) { }
  canLoad(
    route: Route,
    segments: UrlSegment[],
   ): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {

    return this.validate(route);
  }

  private validate(route): boolean {
    const currentUser = this.authService.currentUserValue;
    if (currentUser) {
      if(!!!this.landing.menus.value) {
        this.landing.menulist().subscribe((data: any) => {
          if(data && data.responseObject){
            this.landing.menus.next(data.responseObject);
          }
        });
      }
        // authorised so return true
        return true;
    }

    // not logged in so redirect to login page with the return url
    this.router.navigate(['/auth/login'], { queryParams: { returnUrl: route.url } });
    return false;
  }
}
