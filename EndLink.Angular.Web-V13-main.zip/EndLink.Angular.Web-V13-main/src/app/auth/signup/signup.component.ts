import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Params, Router } from '@angular/router';
import { ToasterService } from 'src/app/services/toaster.service';
import { UserService } from 'src/app/services/user.service';
import { SuccessPopupComponent } from 'src/app/shared/components/success-popup/success-popup.component';
import { messages, paths } from 'src/app/shared/constants';
import { Response } from 'src/app/shared/models/response';
import { UserRegistration } from 'src/app/shared/models/user-registration';

@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.scss']
})
export class SignupComponent implements OnInit {
  model: UserRegistration = new UserRegistration();
  submitted: boolean = false;
  hasAgreed: boolean = false;
  passwordType = 'password';
  confirmPasswdType = 'password';
  isProvider: boolean = false;
  isDisabled: boolean = false;
  signUpData: any;
  linkExpired: boolean = false;
  noSpacesRegex = /^\S*$/;

  constructor(private userService: UserService,
    private toaster: ToasterService,
    private router: Router,
    private activatedRoute: ActivatedRoute,
    private dialog: MatDialog,) { }

  ngOnInit(): void {
    this.activatedRoute.queryParams.subscribe((params: Params) => {
      if (params['flag'] === 'Provider_Add') {
        this.isProvider = true;
      }
      if (params['code'] !== null && params['flag'] !== null) {
        this.getSignUpDetails(params['code'], params['flag'])
      }
    });
  }

  signup(isValid: boolean) {
    this.submitted = true;

    if (!isValid || !this.hasAgreed) {
      return;
    }
    this.userService.register(this.model).subscribe((response: Response) => {
      if (response.isError) {
        this.toaster.showErrorMessage(response.message);
      } else {
        
        // this.toaster.showSuccessMessage(messages.registrationSuccess);
        let successDialog = this.dialog.open(SuccessPopupComponent, {
          data: { successMessage: messages.userInviteSuccess },
        });
        this.router.navigate([paths.auth]);
      }
    });
  }

  getSignUpDetails(code: string, flag: string) {
    this.userService.getSignUpDetail(code, flag).subscribe((response: any) => {
      if (response) {
        this.signUpData = response;
        if (this.signUpData.responseObject === 'Sign up link has been expired') {
          this.linkExpired = true;
          return;
        }
        this.model.signUpCode = code;
        if (flag === 'Provider_Add') {
          this.model.userRoleId = 3;
          this.model.email = response.responseObject.userEmail;
          this.model.organization = response.responseObject.organizationName;
          this.model.provider = response.responseObject.name;
          this.model.providerid = response.responseObject.id;
          this.model.organizationid = response.responseObject.organizationId;
        }
        else if (flag === 'Organization_Add') {
          this.model.userRoleId = 4;
          this.model.organizationid = response.responseObject.id;
          this.model.email = response.responseObject.userEmail;
          this.model.organization = response.responseObject.name;
        }
        else if (flag === 'Invite') {
          this.model.userRoleId = response.responseObject.userRoleId;
          this.model.organizationid = response.responseObject.organization.id;
          this.model.email = response.responseObject.userEmail;
          this.model.organization = response.responseObject.organization.name;
          this.model.providerid = response.responseObject.provider.id;
          this.model.provider = response.responseObject.provider.name;
          this.isProvider = this.model.provider !== '' ? true : false;
        }
        this.isDisabled = true;
      }
    });
  }
}
