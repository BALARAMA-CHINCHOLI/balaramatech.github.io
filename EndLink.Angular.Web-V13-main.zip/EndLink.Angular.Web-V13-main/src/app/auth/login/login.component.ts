import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AuthenticationService } from 'src/app/services/authentication.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { SuccessPopupComponent } from 'src/app/shared/components/success-popup/success-popup.component';
import { keys, paths } from 'src/app/shared/constants';
import { Login } from 'src/app/shared/models/login';
import { Response } from 'src/app/shared/models/response';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {
  model: Login = new Login();
  submitted: boolean = false;
  passwordType: string = 'password';
  currentobj: any;
  role: string;
  constructor(private auth: AuthenticationService,
    private router: Router,
    private toaster: ToasterService,
    private dialog: MatDialog,
  ) { }

  ngOnInit(): void {
    // to check if user is already logged in
    this.getUser();
  }

  login(isValid) {
    this.submitted = true;
    if (!isValid) {
      return;
    }

    this.auth.login(this.model)
      .subscribe((response: Response) => {
        if (!response.isError) {
          this.auth.setLocalStorage(keys.token, response.responseObject);
          this.getUser();
        } else {
          let successDialog = this.dialog.open(SuccessPopupComponent, {
            data: { successMessage: response.message,title:"Error" },
          });
          // this.toaster.showErrorMessage(response.message);
        }
      });
  }

  private getUser() {
    this.auth.getCurrentUser().subscribe((response: Response) => {
      if (!response.isError) {

        this.auth.setUser(response.responseObject);

        if (response.responseObject !== null)
        {
          this.currentobj = localStorage.getItem("endlink.currentUser")
          const obj = JSON.parse(this.currentobj);
          this.role = obj.role
          if (this.role == 'SuperAdmin')
          {
            this.router.navigate([paths.organizationList]);
          }
          else if (this.role == 'Org-Admin') {
            this.router.navigate([paths.providersList]);
          }
          else
          {
            this.router.navigate([paths.dashboard]);
          }
        }

        
      }
    });
  }

}
