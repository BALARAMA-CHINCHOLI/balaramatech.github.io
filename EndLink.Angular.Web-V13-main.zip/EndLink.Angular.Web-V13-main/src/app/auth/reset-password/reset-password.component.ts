import { Component, OnInit } from '@angular/core';
import { ToasterService } from 'src/app/services/toaster.service';
import { messages, paths } from 'src/app/shared/constants';
import { Response } from 'src/app/shared/models/response';
import { ActivatedRoute, Router } from '@angular/router';
import { resetPassword } from '../../shared/models/resetPassword';
import { ResetPasswordService } from '../../services/resetPassword.service';
import { HttpUrlEncodingCodec } from '@angular/common/http';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent implements OnInit {
  model: resetPassword = new resetPassword();
  tkn: any;
  submitted: boolean = false;
  passwordType = 'password';
  confirmPasswdType = 'password';
  constructor(private resetService: ResetPasswordService,
    private router: Router, private route: ActivatedRoute,
    private toaster: ToasterService,
  ) { }

  ngOnInit(): void {
    this.tkn = this.route.snapshot.queryParams.token;
  }

  resetPassword(isValid) {
    this.submitted = true;
    if (!isValid) {
      return;
    }
    this.model.token = decodeURIComponent(this.tkn);
    this.resetService.resetPassword(this.model).subscribe((response: Response) => {
      if (response.isError) {
        this.toaster.showErrorMessage(response.message);
      } else {
        this.toaster.showSuccessMessage(messages.resetPasswordSuccess);
        this.router.navigate([paths.auth]);
      }
    });
  }

}
