import { ForgetPasswordService } from 'src/app/services/forgetPassword.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { messages, paths } from 'src/app/shared/constants';
import { Response } from 'src/app/shared/models/response';
import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { forgetPassword } from '../../shared/models/forgetPassword';

@Component({
  selector: 'app-forget-password',
  templateUrl: './forget-password.component.html',
  styleUrls: ['./forget-password.component.scss']
})
export class ForgetPasswordComponent implements OnInit {
  model: forgetPassword = new forgetPassword();
  submitted: boolean = false;
  //email = "";
  constructor(private forgetService: ForgetPasswordService,
    private router: Router,
    private toaster: ToasterService,
              ) { }

  ngOnInit(): void {
  }

  forgetPassword(isValid) {
    this.submitted = true;
    if (!isValid) {
      return;
    }
    this.forgetService.forgetPassword(this.model).subscribe((response: Response) => {
      if(response.isError) {
      this.toaster.showErrorMessage(response.message);
    } else {
      this.toaster.showSuccessMessage(messages.forgetPasswordSuccess);
      this.router.navigate([paths.auth]);
    }
  });
  }

}
