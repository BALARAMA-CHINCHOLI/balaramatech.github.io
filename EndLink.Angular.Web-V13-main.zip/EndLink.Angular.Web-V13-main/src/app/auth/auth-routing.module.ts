import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthLayoutComponent } from './auth-layout/auth-layout.component';
import { ForgetPasswordComponent } from './forget-password/forget-password.component';
import { LoginComponent } from './login/login.component';
import { ResetPasswordComponent } from './reset-password/reset-password.component';
import { SignupComponent } from './signup/signup.component';

const routes: Routes = [
  {
    path: '',
    component: AuthLayoutComponent,
    children: [
      {
        path: 'signup',
        component: SignupComponent
      },
      {
        path: 'signup?:code&:flag',
        component: SignupComponent
      },
      {
        path: 'forgetPassword',
        component: ForgetPasswordComponent
      },
      {
        path: 'ResetPassword',
        component: ResetPasswordComponent
      },
      {
        path: 'ResetPassword/:token',
        component: ResetPasswordComponent
      },
      {
        path: '',
        pathMatch: 'full',
        component: LoginComponent
      }
    ]
  },
  { path: '**', redirectTo: '', pathMatch: 'full' }

  // {
  //   path:'about/:id',
  //   component: TemplateComponent,
  //   resolve: { data:DashboarResolver},
  // }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class AuthRoutingModule { }
