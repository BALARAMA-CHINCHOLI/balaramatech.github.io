import {
  Directive,
  HostBinding,
  Output,
  EventEmitter,
  HostListener,
} from '@angular/core';

@Directive({ selector: '[fileDrop]' })
export class FileDropDirective {
  @HostBinding('class.fileover') fileover: boolean = false;
  @Output() filedropped = new EventEmitter<any>();

  //Dragover listener
  @HostListener('dragover', ['$event']) onDragOver(evt: any) {
    evt.preventDefault();
    evt.stopPropagation();
    this.fileover = true;
  }

  //Dragleave Listener
  @HostListener('dragleave', ['$event']) onDragLeave(evt: any) {
    evt.preventDefault();
    evt.stopPropagation();
    this.fileover = false;
  }

  //Drop Listener
  @HostListener('drop', ['$event']) ondrop(evt: any) {
    evt.preventDefault();
    evt.stopPropagation();
    this.fileover = false;
    let files = evt.dataTransfer.files;
    if (files.length > 0) {
      this.filedropped.emit(files);
    }
  }
}
