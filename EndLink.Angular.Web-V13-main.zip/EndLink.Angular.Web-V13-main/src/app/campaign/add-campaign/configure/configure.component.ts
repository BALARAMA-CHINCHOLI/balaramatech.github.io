import { Component, OnInit, ViewChild } from '@angular/core';
import { FormControl } from '@angular/forms';
import {
  MomentDateAdapter,
  MAT_MOMENT_DATE_ADAPTER_OPTIONS,
} from '@angular/material-moment-adapter';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import {
  DateAdapter,
  MAT_DATE_FORMATS,
  MAT_DATE_LOCALE,
} from '@angular/material/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import * as mom from 'moment';
import { CampaignService } from 'src/app/services/campaign.service';
import { BusinessUnitService } from 'src/app/services/dataServices/business-unit.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { SuccessPopupComponent } from 'src/app/shared/components/success-popup/success-popup.component';
import { paths } from 'src/app/shared/constants';
import { Campaign } from 'src/app/shared/models/campaign';
import { Response } from 'src/app/shared/models/response';
import { SearchFilter } from 'src/app/shared/models/search-filter';

const moment = mom;

export const MY_FORMATS = {
  parse: {
    dateInput: 'MM/DD/YYYY',
  },
  display: {
    dateInput: 'MM/DD/YYYY',
    monthYearLabel: 'MMM YYYY',
    dateA11yLabel: 'LL',
    monthYearA11yLabel: 'MMMM YYYY',
  },
};

@Component({
  selector: 'app-configure',
  templateUrl: './configure.component.html',
  styleUrls: ['./configure.component.scss'],
  providers: [
    {
      provide: DateAdapter,
      useClass: MomentDateAdapter,
      deps: [MAT_DATE_LOCALE, MAT_MOMENT_DATE_ADAPTER_OPTIONS],
    },

    { provide: MAT_DATE_FORMATS, useValue: MY_FORMATS },
  ],
})
export class ConfigureComponent implements OnInit {

  private dateFormat = 'YYYY-MM-DD';
  private timeFormat = 'HH:mm:ss';

  today = moment(new Date()).startOf('day').format(this.dateFormat);
  maxFromDate = moment().add(1, 'month').format(this.dateFormat);
  maxToDate = moment().add(1, 'month').format(this.dateFormat);
  minToDate = moment().format(this.dateFormat);

  campaign: Campaign = new Campaign();
  departmentsList: any[] = [];
  businessUnitControl = new FormControl();
  filteredDepartmentList: any;
  @ViewChild('picker') toDatePciker;
  data: boolean;

  fromDate: any;
  toDate: any;
  includeWeekends: boolean = false;

  constructor(
    private campaignService: CampaignService,
    private router: Router,
    private route: ActivatedRoute,
    private businessUnitService: BusinessUnitService,
    private toastr: ToasterService,
    private dialog: MatDialog,
  ) { }

  ngOnInit(): void {
    this.getDepartmentList();
    this.route.parent.params.subscribe(data => {
      const id = +data['id'];

      if (id && id > 0) {
        this.getCampaign(id);
      }
    });

    this.businessUnitControl.valueChanges.subscribe((text) => {
      this.filteredDepartmentList = this._filter(text);
    });
  }

  private getDepartmentList() {

    let filters = new SearchFilter();
    filters.paging = { pageSize: 10000, pageNumber: 1 };

    this.businessUnitService.list(filters).subscribe((res: any) => {
      this.departmentsList = res.responseObject.list;
      this.filteredDepartmentList = this.departmentsList;

      if (this.departmentsList.length > 0 && this.campaign.departmentId) {
        this.campaign.departmentName = this.departmentsList.find(x => x.id == this.campaign.departmentId).name;
        this.businessUnitControl.setValue(this.campaign.departmentName);
      }
    });
  }

  private getCampaign(id) {
    this.campaignService.get(id).subscribe((data: Response) => {
      const res = data.responseObject;
      res.scheduleFromDate = moment(res.scheduleFromDate).format(this.dateFormat) + 'T' + moment(res.scheduleFromTime).format(this.timeFormat);
      const startDate = moment(res.scheduleFromDate);

      if (res.statusId == 5 && startDate.isBefore(this.today)) {
        this.router.navigate([
          paths.campaignEdit + id + '/actions',
        ]);
      } else if (startDate.isBefore(this.today)) {
        this.campaign = new Campaign({
          ...res,
          scheduleFromDate: '',
          scheduleToDate: '',
        });
        this.includeWeekends = res.includeWeekends;
        this.maxToDate = moment(new Date()).add(29, 'days').format(this.dateFormat);
      } else {
        this.campaign = new Campaign({...res});
        this.includeWeekends = res.includeWeekends;
        this.maxToDate = moment(this.campaign.scheduleFromDate)
          .add(29, 'days')
          .format(this.dateFormat);

        if (this.departmentsList.length > 0 && this.campaign.departmentId) {
          this.campaign.departmentName = this.departmentsList.find(x => x.id == this.campaign.departmentId).name;
          this.businessUnitControl.setValue(this.campaign.departmentName);
        }
      }
      this.maxFromDate = moment().add(1, 'month').format(this.dateFormat);
      this.minToDate = moment(this.campaign.scheduleFromDate).format(this.dateFormat);
      this.maxToDate = moment(this.campaign.scheduleFromDate).add(1, 'month').format(this.dateFormat);

      this.fromDate = this.campaign.scheduleFromDate;
      this.toDate = this.campaign.scheduleToDate;

      if (this.campaign.departmentName) {
        this.businessUnitControl.setValue(this.campaign.departmentName);
      }
    });
  }

  private _filter(value: string) {
    if (!value || value == '') {
      return this.departmentsList;
    }

    const filterValue = value.toString().toLowerCase();

    return this.departmentsList.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  selectAutoComplete(event: MatAutocompleteSelectedEvent): void {
    const item = this.departmentsList.find(x => x.id == event.option.value);

    if (!item) {
      return;
    }
    this.campaign.departmentId = item.id;
    this.campaign.departmentName = item.name;
    this.businessUnitControl.setValue(item.name);
  }

  //updated
  // blurDataSource(): void {
  //   const item = this.departmentsList.find(x => x.id == this.campaign.departmentId);

  //   if (!item) {
  //     this.campaign.departmentId = 0;
  //     this.campaign.departmentName = '';
  //     return;
  //   }

  //   this.campaign.departmentId = item.id;
  //   this.campaign.departmentName = item.name;
  // }

  fromDateChange(): void {
    this.toDate = null;
    this.maxToDate = moment(this.fromDate)
      .add(29, 'days')
      .format(this.dateFormat);

    this.minToDate = moment(this.fromDate).format(this.dateFormat);

    setTimeout(() => {
      this.toDatePciker.open();
    }, 100);
  }

  space(event) {
    this.campaign.name = this.campaign.name.replace(/^\s+|\s+$/g, '');
    this.campaign.description = this.campaign.description.replace(/^\s+|\s+$/g, '');
    if (this.campaign.name.length == null) {
      this.data = false;
    }
  }

  countDaysOfWeekBetweenDates(sDate, eDate) {
    const startDate: any = new Date(sDate)
    const endDate: any = new Date(eDate);

    if ((startDate.getDay() === 6 || startDate.getDay() === 0) && (endDate.getDay() === 6 || endDate.getDay() === 0)) {
      return true;
    }
    else {
      return false
    }

  };

  submit(form): void {
    const weekDaysCount = this.countDaysOfWeekBetweenDates(this.fromDate, this.toDate);

    if (weekDaysCount && !this.campaign.includeWeekends) {
      // this.toastr.showErrorMessage("Please select include weekend");
      let successDialog = this.dialog.open(SuccessPopupComponent, {
        data: { successMessage: "Please select include weekend", title: "Error" },
      });
    }
    else {

      // this.campaign.name=this.campaign.name.replace(/^\s+|\s+$/g, '');
      // this.campaign.description=this.campaign.description.replace(/^\s+|\s+$/g, '');
      if (!form.valid || (!this.campaign.departmentId || this.campaign.departmentId < 1)) {
        return;
      }
      const isDateChanged = (!moment(this.campaign.scheduleFromDate).isSame(moment(this.fromDate)) 
      || !moment(this.campaign.scheduleToDate).isSame(moment(this.toDate))
      || this.includeWeekends != this.campaign.includeWeekends);
      this.campaign.scheduleFromDate = moment(this.fromDate).format(this.dateFormat);
      this.campaign.scheduleToDate = moment(this.toDate).format(this.dateFormat);
      this.campaign.scheduleFromTime = moment(this.fromDate).format(this.timeFormat);

      if (!!this.campaignService.campaignId.value) {
        //this.campaign.scheduleFromDate = moment(this.fromDate).format('YYYY-MM-DD');
        this.campaign.scheduleToDate = moment(this.toDate).format('YYYY-MM-DD');
        if (isDateChanged) {
          this.campaignService.deletePlans(this.campaignService.campaignId.value).subscribe(res => {
            if (!res.isError) {
              this.updateCampaign();
            }
          })
        } else {
          this.updateCampaign();
        }
      } else {
        this.campaignService.create(this.campaign).subscribe((res) => {
          if (!res.isError) {
            this.campaignService.configureCampaign.next(this.campaign);
            this.router.navigate([
              paths.campaignEdit + res.responseObject + '/recipients',
            ]);
          }
        });
      }
    }
  }

  updateCampaign() {
    this.campaignService.updateCampaign(this.campaign).subscribe(
      (res) => {
        if (!res.isError) {
          this.campaignService.configureCampaign.next(this.campaign);
          this.router.navigate(['../recipients'], {
            relativeTo: this.route,
          });
        } else {
          this.toastr.showErrorMessage(res.message);
        }
      },
      (err) => {
        this.toastr.showErrorMessage(err.message);
      }
    );
  }

  cancel() {
    this.router.navigate([paths.campaignList], { relativeTo: this.route });
  }
  onChange(event) {
    if (event === 0 || event === null || event === '') {
      this.campaign.retryDelayHrs = null
    }
  }

  ngOnDestroy() {
  }
}
