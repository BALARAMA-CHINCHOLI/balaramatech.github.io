import { Component, OnDestroy, OnInit, ViewEncapsulation } from '@angular/core';
import { Router, ActivatedRoute, NavigationEnd } from '@angular/router';
import { CampaignService } from 'src/app/services/campaign.service';
import { MembersService } from 'src/app/services/members.service';
import { ScrollerService } from 'src/app/services/scroller-service.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { Campaign, CampaignAction } from 'src/app/shared/models/campaign';
import { ChannelAction, Language } from 'src/app/shared/models/channel-action';
import { CommunicationChannel } from 'src/app/shared/models/communication-channel';
import { Person } from 'src/app/shared/models/person';
declare var $: any;

@Component({
  selector: 'app-add-campaign',
  templateUrl: './add-campaign.component.html',
  styleUrls: ['./add-campaign.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class AddCampaignComponent implements OnInit, OnDestroy {
  isPreview = false;
  isUpdate = false;
  campaignID$;

  constructor(
    private router: Router,
    private route: ActivatedRoute,
    private campaignService: CampaignService,
    private toastr: ToasterService,
    private scrollerService: ScrollerService,
    private memberService: MembersService
  ) {}

  ngOnInit(): void {
    this.route.params.subscribe((param) => {
      if (!!param?.id) {
        this.isUpdate = true;
        this.campaignService.campaignId.next(param.id);
      }
    });
    this.getCampaignDetails();

    $(document).ready(function () {
      //slidedown starts
      $('.lib-template').on('mouseenter', function () {
        //$(this).next(".overlaybook").css("display", "block").slideDown();
        // $(".overlaybook").slideDown();
        $(this).children('.overlaybook').slideDown();
      });
      $('.lib-template').on('mouseleave', function () {
        //$(this).next(".overlaybook").css("display", "block").slideDown();
        $('.overlaybook').slideUp();
      });
      //slidedown ends

      var current_fs, next_fs, previous_fs; //fieldsets
      var opacity;

      // $('.next').click(function () {
      //   current_fs = $(this).parent();

      //   next_fs = $(this).parent().next();

      //   //Add Class Active
      //   $('#progressbar li')
      //     .eq($('fieldset').index(next_fs))
      //     .$('.stepper-bg')
      //     .addClass('active');

      //   //show the next fieldset
      //   next_fs.show();
      //   //hide the current fieldset with style
      //   current_fs.animate(
      //     { opacity: 0 },
      //     {
      //       step: function (now) {
      //         // for making fielset appear animation
      //         opacity = 1 - now;

      //         current_fs.css({
      //           display: 'none',
      //           position: 'relative',
      //         });
      //         next_fs.css({ opacity: opacity });
      //       },
      //       duration: 600,
      //     }
      //   );
      // });

      // $('.previous').click(function () {
      //   current_fs = $(this).parent();
      //   previous_fs = $(this).parent().prev();

      //   //Remove class active
      //   $('#progressbar li')
      //     .eq($('fieldset').index(current_fs))
      //     .prev()
      //     .$('.stepper-bg')
      //     .removeClass('active');
      //   // .removeClass('active');

      //   //show the previous fieldset
      //   previous_fs.show();

      //   //hide the current fieldset with style
      //   current_fs.animate(
      //     { opacity: 0 },
      //     {
      //       step: function (now) {
      //         // for making fielset appear animation
      //         opacity = 1 - now;

      //         current_fs.css({
      //           display: 'none',
      //           position: 'relative',
      //         });
      //         previous_fs.css({ opacity: opacity });
      //       },
      //       duration: 600,
      //     }
      //   );
      // });

      $('.radio-group .radio').click(function () {
        $(this).parent().find('.radio').removeClass('selected');
        $(this).addClass('selected');
      });

      $('.submit').click(function () {
        return false;
      });
    });
  }

  getCampaignDetails(): void {
    this.campaignID$ = this.campaignService.campaignId.subscribe((id) => {
      if (!!id) {
        this.campaignService.get(id).subscribe(
          (res: any) => {
            if (!res?.isError) {
              this.campaignService.configureCampaign.next(
                new Campaign(res.responseObject)
              );
              const selectedMembers = res.responseObject.receipients.persons.map(
                (member) => Object.assign(new Person(), member.person)
              );
              this.memberService.selectedMembers.next(selectedMembers);
              this.campaignService.isRecipientsUpdated = true;

              const selectedGroups = res.responseObject.receipients.groups.map(
                (selection) => selection.group
              );
              this.campaignService.campaignRecipientGroups.next(selectedGroups);
              this.campaignService.isRecipientsUpdated = true;
              const reiceipientUploads = res.responseObject.receipients.files.map((file) => ({
                ...file,
                FileUrl: file.fileUrl,
              }));
              this.campaignService.campaignRecipientUploads.next(
                reiceipientUploads
              );
              this.campaignService.isRecipientsUpdated = true;
              const actionsList = res.responseObject.actions.map((action) => {
                const channel = new ChannelAction();
                channel.CampaignId = action.campaignId;
                channel.CommunicationChannel = action.communicationChannel as CommunicationChannel;
                channel.action = 'add';
                if (!!action?.mediaUrl) {
                  channel.MediaUrl = action.mediaUrl;
                }
                channel.template = action.template;
                channel.templateHtml = action.templateHtml;
                channel.language = action.language as Language;
                return channel;
              });
              this.campaignService.campaignActions.next(actionsList);
              this.campaignService.campaignSchedule.next(res.responseObject.plans);
            } else {
              this.toastr.showErrorMessage(res.message);
            }
          },
          (err) => {
            this.toastr.showErrorMessage(err.message);
          }
        );
      }
    });
  }

  onRouterActivate(event): void {
    this.scrollerService.scrollTo$.next(0);
    if (event.route.routeConfig.path == '' || event.route.routeConfig.path == 'preview') {
      this.isPreview = true;
    }
  }

  ngOnDestroy(): void {
    this.campaignID$.unsubscribe();
    this.memberService.selectedMembers.next([]);
    this.campaignService.campaignSchedule.next([]);
    this.campaignService.configureCampaign.next(null);
    this.campaignService.campaignRecipientUploads.next([]);
    this.campaignService.campaignRecipientGroups.next([]);
    this.campaignService.isRecipientsUpdated = false;
    this.campaignService.campaignActions.next([]);
    this.campaignService.campaignId.next(0);
  }
}
