import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CampaignService } from 'src/app/services/campaign.service';
import { CategoryService } from 'src/app/services/category.service';
import { CommunicationChannelService } from 'src/app/services/communication-channel.service';
import { TemplateService } from 'src/app/services/template.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { Category } from 'src/app/shared/models/category';
import { ChannelAction } from 'src/app/shared/models/channel-action';
import { CommunicationChannel } from 'src/app/shared/models/communication-channel';
import { TemplateFilter } from 'src/app/shared/models/template-filter';

@Component({
  selector: 'app-actions',
  templateUrl: './actions.component.html',
  styleUrls: ['./actions.component.scss'],
})
export class ActionsComponent implements OnInit {
  actionsList = [];
  selectedChannel = '';
  selectedAction: ChannelAction = new ChannelAction();
  comment = '';
  communications: CommunicationChannel[];

  isEditorOpen: boolean = false;
  campaignID$;

  constructor(
    private campaignService: CampaignService,
    private router: Router,
    private route: ActivatedRoute,
    private commChannelService: CommunicationChannelService,
    private toastr: ToasterService
  ) {}

  ngOnInit(): void {
    this.getCommunicationChannels();
    this.campaignService.campaignActions.subscribe((values) => {
      this.actionsList = Object.assign([], values);
    });
    // this.campaignID$ = this.campaignService.campaignId.subscribe((id) => {
    //   if (!!id && this.campaignService.campaignActions.value.length == 0) {
    //     this.campaignService.get(id).subscribe(
    //       (res: any) => {
    //         if (!res?.isError) {
    //           // this.campaign = new Campaign(res.responseObject);
    //           this.actionsList = res.responseObject.actions.map((action) => {
    //             let channel = new ChannelAction();
    //             channel.CampaignId = action.campaignId;
    //             channel.CommunicationChannel = action.communicationChannel;
    //             (channel.action = 'add'), (channel.template = action.template);
    //             channel.language = action.language;
    //             return channel;
    //           });
    //           this.campaignService.campaignActions.next(this.actionsList);
    //         } else {
    //           this.toastr.showErrorMessage(res.message);
    //         }
    //       },
    //       (err) => {
    //         this.toastr.showErrorMessage(err.message);
    //       }
    //     );
    //   }
    // });
  }

  getCommunicationChannels(): void {
    this.commChannelService.list().subscribe(
      (data) => {
        if (!data.isError && data.responseObject) {
          this.communications = data.responseObject;
        } else {
          this.toastr.showErrorMessage(data.message);
        }
      },
      (err) => {
        this.toastr.showErrorMessage(err.message);
      }
    );
  }

  onEdit(event) {
    this.selectedAction = event;
    this.selectedAction['action'] = 'edit';
    this.selectedChannel = event.CommunicationChannel.id;
  }

  addMessage(message) {
    this.comment = this.comment + ' ' + message;
  }

  actionEvent(event) {
    if (event.action == 'add') {
       let campaignId = this.campaignService.campaignId.getValue();
       event.CampaignId = campaignId;
      this.actionsList.push(event);
      //this.campaignService.campaignActions.next(this.actionsList);
    } else if (event.action == 'edit') {
      this.selectedAction['id'] = event.id;
      this.selectedAction['name'] = event.name;
      //this.campaignService.campaignActions.next(this.actionsList);
    }
    this.selectedAction = null;
    this.selectedChannel = '';
  }

  next() {
    if (this.actionsList.length > 0) {
      this.campaignService.campaignActions.next(this.actionsList);
      this.campaignService.updateActions().subscribe(
        (res) => {
          if (!res.isError) {
            this.toastr.showSuccessMessage('Actions saved successfully');
            this.router.navigate(['../schedule'], { relativeTo: this.route });
          } else {
            this.toastr.showErrorMessage(res.message);
          }
        },
        (err) => {
          this.toastr.showErrorMessage(err.message);
        }
      );
    } else {
      this.toastr.showErrorMessage('Please add any Action');
    }
  }

  previous() {
    this.router.navigate(['../recipients'], { relativeTo: this.route });
  }

  cancel() {
    this.router.navigate(['/campaign'], { relativeTo: this.route });
  }

  getChannelImage(communicationName: string){
    switch(communicationName){
      case 'SMS':
        return 'sms-big.png';
        break;
        case 'Voice':
        return 'voice-big.png';
        break;
        case 'MMS':
        return 'mms-big.png';
        break;
        case 'Email':
        return 'mail-big.png';
        break;
    }
  }

  ngOnDestroy() {
    // this.campaignID$.unsubscribe();
  }
}
