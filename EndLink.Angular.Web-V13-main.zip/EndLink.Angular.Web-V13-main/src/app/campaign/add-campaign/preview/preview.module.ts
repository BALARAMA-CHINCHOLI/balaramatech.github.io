import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { PreviewRoutingModule } from './preview-routing.module';
import { PreviewComponent } from './preview.component';
import { SharedModule } from '../../../shared/shared.module';
import { AddCampaignSharedModule } from '../../../shared/modules/add-campaign-shared/add-campaign-shared.module';


@NgModule({
  declarations: [PreviewComponent],
  imports: [
    CommonModule,
    PreviewRoutingModule,
    AddCampaignSharedModule,
    SharedModule
  ]
})
export class PreviewModule { }
