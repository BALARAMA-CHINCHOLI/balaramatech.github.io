import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router, UrlSegment } from '@angular/router';
import { CampaignService } from 'src/app/services/campaign.service';
import { BusinessUnitService } from 'src/app/services/dataServices/business-unit.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { messages, paths } from 'src/app/shared/constants';
import { CampaignStatusType } from 'src/app/shared/enums/campaign-status-type';
import { Person } from 'src/app/shared/models/person';
import { SearchFilter } from 'src/app/shared/models/search-filter';
import { Campaign } from '../../../shared/models/campaign';

@Component({
  selector: 'app-preview',
  templateUrl: './preview.component.html',
  styleUrls: ['./preview.component.scss'],
})
export class PreviewComponent implements OnInit {
  previewForm = true;
  campaignDetails = new Campaign();
  files = [];
  actions = [];
  isPreview: boolean;
  campaignID$;
  id: number;
  departmentsList: any[] = [];

  constructor(
    private campaignService: CampaignService,
    private router: Router,
    private route: ActivatedRoute,
    private toaster: ToasterService,
    private businessUnitService: BusinessUnitService
  ) { }

  ngOnInit(): void {
    this.isPreview = false;

    this.getCampaignDetails();
    this.campaignService.configureCampaign.subscribe((res) => {
      if (!!res) {
        this.campaignDetails = res;
        this.getDepartmentList();
      }
    });
    this.campaignService.campaignActions.subscribe((res) => {
      if (!!res) {
        this.actions = res;
      }
    });
    this.campaignService.campaignRecipientUploads.subscribe((res) => {
      if (!!res) {
        this.files = res.map((file) => ({
          ...file,
          name: file.fileName || file.name,
        }));
      }
    });

    this.campaignService.campaignId.subscribe(id => {
      this.id = +id;
    });
  }

  getDepartmentList() {
    let filters = new SearchFilter();
    filters.paging = { pageSize: 10000, pageNumber: 1 };

    this.businessUnitService.list(filters).subscribe((res: any) => {
      this.departmentsList = res.responseObject.list;

      if (this.departmentsList.length > 0 && this.campaignDetails.departmentId) {
        this.campaignDetails.departmentName = this.departmentsList.find(x => x.id == this.campaignDetails.departmentId).name;
      }
    });
  }

  getCampaignDetails(): void {
    // this.campaignID$ = this.campaignService.campaignId.subscribe((id) => {
    //   if (!!id) {
    //     this.campaignService.get(id).subscribe(
    //       (res: any) => {
    //         if (!res?.isError) {
    //           this.campaignService.configureCampaign.next(
    //             new Campaign(res.responseObject)
    //           );
    //           const selectedMembers = res.responseObject.receipients.persons.map(
    //             (member) => Object.assign(new Person(), member.person)
    //           );
    //           this.campaignService.campaignRecipients.next(selectedMembers);

    //           const selectedGroups = res.responseObject.receipients.groups.map(
    //             (selection) => selection.group
    //           );
    //           this.campaignService.campaignRecipientGroups.next(selectedGroups);
    //           this.campaignService.campaignRecipientUploads.next(res.responseObject.receipients.files);

    //           // this.totalCount = res.responseObject.memberCount;
    //           // this.initiateChangesDetectors();
    //         } else {
    //           this.toaster.showErrorMessage(res.message);
    //         }
    //       },
    //       (err) => {
    //         this.toaster.showErrorMessage(err.message);
    //       }
    //     );
    //   }
    // });
  }

  submit() {
    if (!!this.campaignDetails) {
      let payload = {
        ...this.campaignDetails,
        IsFinalSubmit: 1,
      };
      this.campaignService.updateCampaign(payload).subscribe((data) => {
        if (data.isError) {
          this.toaster.showErrorMessage(data.message);
        } else {
          this.toaster.showSuccessMessage(messages.campaignUpdateSuccess);
          this.router.navigate([paths.campaignList]);
        }
      });
    }
  }

  downloadCSV(): void {
    this.campaignService.donwload(
      this.campaignService.campaignRecipientUploads.value[0].FileUrl
    );
  }

  removeUpload(index) {
    this.files.splice(index, 1);
    this.campaignService.campaignRecipientUploads.next(this.files);
    this.campaignService.isRecipientsUpdated = true;
  }

  cancel(): void {
    this.router.navigate(['/campaign'], { relativeTo: this.route });
  }

  abort() {
    this.campaignService
      .abort({ Id: 26, StatusId: CampaignStatusType.Aborted })
      .subscribe(
        (res) => {
          if (!res.isError) {
            this.router.navigate(['/campaign'], { relativeTo: this.route });
          } else {
            this.toaster.showErrorMessage(res.message);
          }
        },
        (err) => {
          this.toaster.showErrorMessage(err.message);
        }
      );
  }

  previous() {
    this.router.navigate(['../schedule'], { relativeTo: this.route });
  }

  goto(page) {
    const path = 'campaign/editCampaign/' + this.id + '/' + page;
    this.router.navigate([path]);
  }
}
