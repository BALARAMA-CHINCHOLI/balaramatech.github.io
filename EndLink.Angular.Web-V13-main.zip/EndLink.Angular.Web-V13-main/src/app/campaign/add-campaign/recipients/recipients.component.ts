import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CampaignService } from 'src/app/services/campaign.service';
import { EmployeeService } from 'src/app/services/employee.service';
import { GroupService } from 'src/app/services/group.service';
import { MembersService } from 'src/app/services/members.service';
import { PatientService } from 'src/app/services/patient.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { GenderType } from 'src/app/shared/enums/gender-type';
import { PersonFilter } from 'src/app/shared/models/person-filter';
import { SearchFilter } from 'src/app/shared/models/search-filter';
// import * as CSV from 'csv-parser';
// import * as fs from 'fs';
// const CSV = require('csv-parser');
// const fs = require('fs');
declare var $: any;

@Component({
  selector: 'app-recipients',
  templateUrl: './recipients.component.html',
  styleUrls: ['./recipients.component.scss'],
})
export class RecipientsComponent implements OnInit {
  isFilterOpen = false;
  searchResults = [];
  allSearchResults =[];
  showAll:boolean = false;
  showTxt:string = "Show More";
  groupResults = [];
  memberType = 'patient';
  searchTerm = '';
  isGroup = false;
  memberFilter = new PersonFilter();
  groupFilter = new SearchFilter();
  files = [];
  scroller$: any;
  hasMoreMember = true;
  hasMoreGroup = true;
  deselect = false;
  currentTab = 'members';
  campaignID$;
  campaignID;
  genderList = [
    {
      id: GenderType.Male,
      name: 'Male',
    },
    {
      id: GenderType.Female,
      name: 'Female',
    },
    {
      id: GenderType.Unknown,
      name: 'Unknown',
    },
  ];

  constructor(
    private campaignService: CampaignService,
    private router: Router,
    private route: ActivatedRoute,
    private patientService: PatientService,
    private employeeService: EmployeeService,
    private groupService: GroupService,
    private toastr: ToasterService,
    private memberService: MembersService
  ) { }

  ngOnInit(): void {
    this.groupFilter.paging = {
      pageNumber: 1,
      pageSize: 10,
    };
    this.searchMember();
    this.campaignService.campaignId.subscribe(id => {
      this.campaignID =id;
    })
    this.memberService.selectedMembers.subscribe((values) => {
      this.searchResults.forEach((result) => {
        result.selected = !!values.find((value) => result.id == value.id);
      });
    });
    this.campaignService.campaignRecipientGroups.subscribe((values) => {
      this.groupResults.forEach((result) => {
        result.selected = !!values.find((value) => result.id == value.id);
      });
    });
    this.campaignService.campaignRecipientUploads.subscribe((files) => {
      const selectedFiles = files;
      this.files = selectedFiles.map((file) => ({
        ...file,
        name: file.fileName || file.name,
      }));
      // const reiceipientUploads = selectedFiles.map((file) => ({
      //   ...file,
      //   FileUrl: file.fileUrl,
      // }));
      // this.campaignService.campaignRecipientUploads.next(
      //   reiceipientUploads
      // );
    });

    // this.campaignID$ = this.campaignService.campaignId.subscribe((id) => {
    //   this.campaignService.get(id).subscribe(
    //     (res: any) => {
    //       if (!res?.isError) {
    //         const selectedMembers = res.responseObject.receipients.persons.map(
    //           (member) => Object.assign(new Person(), member.person)
    //         );
    //         this.searchMember();
    //         this.memberService.selectedMembers.next(selectedMembers);
    //         const selectedGroups = res.responseObject.receipients.groups.map(
    //           (selection) => selection.group
    //         );
    //         this.campaignService.campaignRecipientGroups.next(selectedGroups);
    //         const selectedFiles = res.responseObject.receipients.files;
    //         this.files = selectedFiles.map((file) => ({
    //           ...file,
    //           name: file.fileName,
    //         }));
    //         const reiceipientUploads = selectedFiles.map((file) => ({
    //           ...file,
    //           FileUrl: file.fileUrl,
    //         }));
    //         this.campaignService.campaignRecipientUploads.next(
    //           reiceipientUploads
    //         );
    //       } else {
    //         this.toastr.showErrorMessage(res.message);
    //       }
    //     },
    //     (err) => {
    //       this.toastr.showErrorMessage(err.message);
    //     }
    //   );
    // });
  }

  openTab(tab): void {
    this.searchTerm = '';
    this.currentTab = tab;
    switch (tab) {
      case 'members':
        this.memberFilter.paging.pageNumber = 1;
        this.searchMember();
        break;
      case 'groups':
        this.groupFilter.paging.pageNumber = 1;
        this.searchGroup();
        break;
      case 'upload':
        break;
    }
  }

  toggleFilter(): void {
    this.isFilterOpen = !this.isFilterOpen;
  }

  updateAllGroups(isSelected): void {
    if (isSelected) {
      const toBeSelected = this.groupResults
        .filter((result) => !result.selected)
        .map((item) => ({ ...item, selected: true }));
      if (toBeSelected.length > 0) {
        this.campaignService.campaignRecipientGroups.next([
          ...this.campaignService.campaignRecipientGroups.value,
          ...toBeSelected,
        ]);
        this.campaignService.isRecipientsUpdated = true;
      }
    } else {
      const toBeUnSelected = this.groupResults
        .filter((result) => result.selected)
        .map((item) => ({ ...item, selected: false }));
      if (toBeUnSelected.length > 0) {
        const exceptUnSelected =
          this.campaignService.campaignRecipientGroups.value.filter(
            (selectedMember) =>
              !!!toBeUnSelected.find(
                (member) =>
                  member.category == selectedMember.category &&
                  member.id == selectedMember.id
              )
          );
        if (
          exceptUnSelected.length !==
          this.campaignService.campaignRecipientGroups.value.length
        ) {
          this.campaignService.campaignRecipientGroups.next(exceptUnSelected);
          this.campaignService.isRecipientsUpdated = true;
        }
      }
    }
  }

  updateAllSelected(isSelected) {
    this.deselect = true;
    if (isSelected) {
      let toBeSelected = this.allSearchResults
        .filter((result) => !result.selected)
        .map((item) => ({ ...item, selected: true }));
      if (toBeSelected.length > 0) {
        this.memberService.selectedMembers.next([
          ...this.memberService.selectedMembers.value,
          ...toBeSelected,
        ]);
        this.campaignService.isRecipientsUpdated = true;
      }
      this.searchResults.forEach((v,i)=>{
        this.searchResults[i].selected=true;
      });
      this.allSearchResults.forEach((v,i)=>{
        this.allSearchResults[i].selected=true;
      });
    } else {
      this.deselect = true;
      let toBeUnSelected = this.allSearchResults
        .filter((result) => result.selected)
        .map((item) => ({ ...item, selected: false }));
      if (toBeUnSelected.length > 0) {
        let exceptUnSelected =
          this.memberService.selectedMembers.value.filter(
            (selectedMember) =>
              !!!toBeUnSelected.find((member) => member.id == selectedMember.id)
          );
        if (
          exceptUnSelected.length !==
          this.memberService.selectedMembers.value.length
        ) {
          this.memberService.selectedMembers.next(exceptUnSelected);
          this.campaignService.isRecipientsUpdated = true;
        }
      }
      this.searchResults.forEach((v,i)=>{
        this.searchResults[i].selected=false;
      });
      this.allSearchResults.forEach((v,i)=>{
        this.allSearchResults[i].selected=false;
      });
    }
  }

  updateSelectedMember(checked, member = null, index = 0, recipientType) {
    this.deselect = true;
    let values =
      recipientType == 'member'
        ? this.memberService.selectedMembers.value
        : this.campaignService.campaignRecipientGroups.value;
    let source =
      recipientType == 'member'
        ? this.memberService.selectedMembers
        : this.campaignService.campaignRecipientGroups;
    if (checked) {
      source.next([...values, member]);
    } else {
      member.selected = false;
      this.deselect = true;
      let memberIndex = source.value.findIndex(
        (person) => person.id == member.id
      );
      source.next([
        ...values.slice(0, memberIndex),
        ...values.slice(memberIndex + 1),
      ]);
    }
  }

  next(isValid) {
    if (this.isValidFile) {

      if (
        this.memberService.selectedMembers.value.length > 0 ||
        this.campaignService.campaignRecipientGroups.value.length > 0 ||
        this.campaignService.campaignRecipientUploads.value.length > 0
      ) {
        if(this.campaignService.isRecipientsUpdated){
          this.campaignService.deletePlans(this.campaignID).subscribe(res=> {
            if(!res.isError){
              this.updateMembers();

            }
          })
        }
        else{
          this.updateMembers();
        }
        
      } else {
        this.toastr.showErrorMessage('Select Recipients to proceed');
        
      }
    }
  }
  updateMembers() {
    this.campaignService.updateRecipients().subscribe(
      (res) => {
        if (!res.isError) {
          this.campaignService.campaignRecipientUploads.next(
            this.campaignService.campaignRecipientUploads.value.map(file => ({ ...file, isUploaded: false })));
          this.campaignService.isRecipientsUpdated = true;
          this.router.navigate(['../actions'], { relativeTo: this.route });
          this.toastr.showSuccessMessage('Recipients saved successfully');
        } else {
          this.toastr.showSuccessMessage(res.message);
        }
      },
      (err) => {
        this.toastr.showErrorMessage(err.message);
      }
    );
  }

  previous() {
    this.router.navigate(['../'], { relativeTo: this.route });
  }

  cancel() {
    this.router.navigate(['/campaign'], { relativeTo: this.route });
  }

  clearFilter() {
    this.memberFilter = new PersonFilter();
    this.searchMember();
  }

  searchMember() {
    if (!!this.memberType) {
      this.showAll = true;
      this.groupResults = [];
      this.memberFilter.term = this.searchTerm;
      switch (this.memberType) {
        case 'patient':
          this.patientService.list(this.memberFilter).subscribe(
            (res) => {
              // this.hasMoreMember =
              //   res?.responseObject?.list.length >=
              //   this.memberFilter.paging.pageSize;
              this.allSearchResults = res.responseObject.list.map((member) => {
                let isMemberSelected =
                  this.memberService.selectedMembers.value.find(
                    (recipient) => recipient.id == member.id
                  );
                return { ...member, selected: !!isMemberSelected };
              });

              this.searchResults = this.allSearchResults.slice(0,10);
              if(this.allSearchResults.length>10)
                 this.showAll = true;
              else
                 this.showAll = false;
            },
            (err) => {
              this.toastr.showErrorMessage(err.message);
            }
          );
          break;
        case 'employee':
          this.employeeService.list(this.memberFilter).subscribe(
            (res) => {
              // this.hasMoreMember =
              //   res?.responseObject?.list.length >=
              //   this.memberFilter.paging.pageSize;
              this.allSearchResults = res.responseObject.list.map((member) => {
                let isMemberSelected =
                  this.memberService.selectedMembers.value.find(
                    (recipient) =>
                      recipient.id == member.id &&
                      recipient.category == member.category
                  );
                return { ...member, selected: !!isMemberSelected };
              });
              this.searchResults = this.allSearchResults.slice(0,10);
              if(this.allSearchResults.length>10)
                 this.showAll = true;
              else
                 this.showAll = false;
            },
            (err) => {
              this.toastr.showErrorMessage(err.message);
            }
          );
          break;
      }

    } else {
      this.toastr.showErrorMessage('Error, Please select member type');
    }
  }
  showAllMember(){
    if(this.allSearchResults){
      if (this.showTxt == "Show More") {
        this.searchResults = this.allSearchResults;
        this.showTxt = "Show Less"
      } else {
        this.searchResults = this.allSearchResults.splice(0, 10);
        this.showTxt = "Show More"
      }
    }


  }
  searchGroup() {
    this.searchResults = [];
    this.groupFilter.SearchText = this.searchTerm;
    this.groupService.list(this.groupFilter).subscribe(
      (res) => {
        // this.hasMoreGroup =
        //   res?.responseObject?.list.length >= this.groupFilter.paging.pageSize;
        this.groupResults = res.responseObject.list.map((group) => {
          const isGroupSelected =
            this.campaignService.campaignRecipientGroups.value.find(
              (recipient) => recipient.id == group.id
            );
          return { ...group, selected: !!isGroupSelected };
        });
      },
      (err) => {
        this.toastr.showErrorMessage(err.message);
      }
    );
  }

  onFileDropped(event) {
    this.files = this.files.concat(Object.values(event));
    var ext = this.files[0].name.substring(this.files[0].name.lastIndexOf('.') + 1);
    if (ext.toLowerCase() == 'csv' || this.files[0].name == null) {
      this.isValidFile = true;
      this.uploadFile({ files: event });
    }
    else {
      this.isValidFile = false;
    }
  }

  isValidFile: boolean = true;

  fileBrowseHandler(files) {
    this.files = this.files.concat([...files.target.files]);
    var ext = this.files[0].name.substring(this.files[0].name.lastIndexOf('.') + 1);
    if (ext.toLowerCase() == 'csv' || this.files[0].name == null) {
      this.isValidFile = true;
      this.uploadFile(files.target);
    }
    else {
      this.isValidFile = false;
    }


  }

  getHeaderArray(csvRecordsArr: any): any[] {
    const headers = (csvRecordsArr[0]).split(',');
    const headerArray = [];
    for (const header of headers) {
      headerArray.push(header);
    }
    return headerArray;
  }

  uploadFile(file) {
    if (!!file) {
      const reader = new FileReader();
      reader.readAsText(file.files[0]);
      var fileType = file;
      var fileExt = fileType.accept.substring(fileType.accept.lastIndexOf('.') + 1);
      var ext = file.value.substring(file.value.lastIndexOf('.') + 1);
      if (ext.toLowerCase() == 'csv') {
        this.isValidFile = true;
        reader.onload = () => {
          const csvData = reader.result;
          const csvRecordsArray = (csvData as string).split('\n').length;
          this.campaignService.fileUpload(file.files[0], 'campaign').subscribe(
            (res) => {
              file.url = res.responseObject;
              this.campaignService.campaignRecipientUploads.next([
                { name: file.files[0].name, FileUrl: res.responseObject, totalCount: (csvRecordsArray - 2), isUploaded: true },
              ]);
              this.campaignService.isRecipientsUpdated = true;
            },
            (err) => {
              this.toastr.showErrorMessage(err.message);
            }
          );
        };
      }
      else {
        this.isValidFile = false;
      }
    }
  }

  //file upload js starts
  readURL(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e) {
        $('.file-upload-image').attr('src', e.target.result);

        $('.image-title').html(input.files[0].name);
      };

      reader.readAsDataURL(input.files[0]);
    } else {
    }
  }

  removeUpload(index) {
    this.files.splice(index, 1);
    this.campaignService.campaignRecipientUploads.next([]);
    this.campaignService.isRecipientsUpdated = true;
  }

  downloadSample() {
    this.campaignService.donwloadSample().subscribe((res) => {
      window.open(res.responseObject, '_blank').focus();
    });
  }

  downloadCSV() {
    this.campaignService.donwload(
      this.campaignService.campaignRecipientUploads.value[0].FileUrl
    );
  }

  ngOnDestroy() {
    // this.campaignID$.unsubscribe();
  }
}
