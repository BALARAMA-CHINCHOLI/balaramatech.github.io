import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { CampaignComponent } from './campaign.component';
import { SharedModule } from '../shared/shared.module';
import { CampaignRoutingModule } from './campaign-routing.module';
import { AddCampaignComponent } from './add-campaign/add-campaign.component';
import { AddAdvancedCampaignComponent } from './add-advanced-campaign/add-advanced-campaign.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ViewCampaignComponent } from './view-campaign/view-campaign.component';
import { ConfigureComponent } from './add-campaign/configure/configure.component';
import { RecipientsComponent } from './add-campaign/recipients/recipients.component';
import { ActionsComponent } from './add-campaign/actions/actions.component';
import { AddCampaignGuard } from '../shared/helpers/campaign.guard';
import { CampaignSummaryComponent } from './view-campaign/campaign-summary/campaign-summary.component';
import { CampaignDashboardComponent } from './view-campaign/campaign-dashboard/campaign-dashboard.component';
import { CampaignDetailsComponent } from './view-campaign/campaign-details/campaign-details.component';
import { AddCampaignSharedModule } from '../shared/modules/add-campaign-shared/add-campaign-shared.module';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { AcionDialogComponent } from './view-campaign/campaign-details/acion-dialog/acion-dialog.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    CampaignRoutingModule,
    AddCampaignSharedModule,
    SharedModule,
    
    OwlDateTimeModule, 
    OwlNativeDateTimeModule,
  ],
  declarations: [
    CampaignComponent,
    AddCampaignComponent,
    AddAdvancedCampaignComponent,
    ViewCampaignComponent,
    ConfigureComponent,
    RecipientsComponent,
    ActionsComponent,
    CampaignSummaryComponent,
    CampaignDashboardComponent,
    CampaignDetailsComponent,
    AcionDialogComponent,
  ],
  providers: [AddCampaignGuard],
})
export class CampaignModule {}
