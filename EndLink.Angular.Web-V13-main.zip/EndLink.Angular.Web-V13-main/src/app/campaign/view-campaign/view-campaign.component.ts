import { Component, OnInit, ViewEncapsulation } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { CampaignService } from 'src/app/services/campaign.service';
import { ScrollerService } from 'src/app/services/scroller-service.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { paths } from 'src/app/shared/constants';

@Component({
  selector: 'app-view-campaign',
  templateUrl: './view-campaign.component.html',
  styleUrls: ['./view-campaign.component.scss'],
  encapsulation: ViewEncapsulation.None,
})
export class ViewCampaignComponent implements OnInit {
  currentTab: string = 'summary';

  constructor(
    private scroller: ScrollerService,
    private dialog: MatDialog,
    private campaignService: CampaignService,
    private toaster: ToasterService,
    private route: ActivatedRoute,
    private router: Router
  ) { }

  ngOnInit(): void {
    this.route.params.subscribe((param) => {
      if (!!param?.id) {
        this.campaignService.campaignId.next(param.id);
        // this.getCampaignDetails('summary');
      }
    });
  }

  getCampaignDetails(type) {
    this.campaignService.viewCampaign(type).subscribe((res) => {
    });
  }

  goBack() {
    this.router.navigate([paths.campaignList]);
  }
}
