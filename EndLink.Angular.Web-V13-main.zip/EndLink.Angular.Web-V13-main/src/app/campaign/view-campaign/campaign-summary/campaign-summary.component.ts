import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CampaignService } from 'src/app/services/campaign.service';
import { ToasterService } from 'src/app/services/toaster.service';

@Component({
  selector: 'app-campaign-summary',
  templateUrl: './campaign-summary.component.html',
  styleUrls: ['./campaign-summary.component.scss']
})
export class CampaignSummaryComponent implements OnInit {

  selectedChannel: any = null;
  channels = [];

  groups;
  individuals;
  totalMembers;
  templates = [];
  summaryMore: boolean;
  showSummary; boolean;
  consentCounts: any;

  constructor(private route: ActivatedRoute, private campaignService: CampaignService, private toastr: ToasterService) { }

  ngOnInit(): void {
    this.route.params.subscribe((param) => {
      if (!!param?.id) {
        this.campaignService.campaignId.next(param.id);
        this.getCampaignDetails('summary');
        this.getCampaignConsentDetails();
      }
    });
    this.summaryMore = true;
    this.showSummary = false;
  }
  summary() {
    this.summaryMore = !this.summaryMore;
    this.showSummary = !this.showSummary;
  }

  getCampaignDetails(type): void {
    this.campaignService.viewCampaign(type).subscribe((res) => {
      if (!res.isError) {
        if (res.responseObject.Channels.length > 0) {
          this.generateChannelsData(res.responseObject.Channels);
          this.changeChannel(this.channels[0].channel);
        }
        this.totalMembers = res.responseObject.Plans;
        this.groups = res.responseObject.Groups;
        this.individuals = res.responseObject.Indivisuals;
        this.templates = res.responseObject.Templates;
      } else {
        this.toastr.showErrorMessage(res.message);
      }
    }, err => {
      this.toastr.showErrorMessage(err.message);
    });
  }

  
  getCampaignConsentDetails(): void {
    this.campaignService.viewCampaign('dashboard').subscribe((res) => {
      this.consentCounts = res.responseObject.Consent;
    });
  }

  private generateChannelsData(channels: any) {
    const channelsData = [];
    channels.forEach(element => {
      const existingElement = channelsData.find(x => x.channelId == element.ChannelId);
      if (existingElement == null) {
        channelsData.push({
          channelId: element.ChannelId,
          channel: element.Channel,
          attempts: [
            {
              attempt: element.Attempt,
              successCount: element.Status == 'Sent' ? element.Counts : 0,
              errorCount: element.Status == 'Error' ? element.Counts : 0,
            }
          ],
          consents: [
            {
              consent: element.Consent,
              count: element.Counts
            }
          ],
          totalSuccess: element.Status == 'Sent' ? element.Counts : 0,
          totalError: element.Status == 'Error' ? element.Counts : 0
        });
      } else {
        const existingAttempt = existingElement.attempts.find(x => x.attempt == element.Attempt);

        if (existingAttempt == null) {
          existingElement.attempts.push({
            attempt: element.Attempt,
            successCount: element.Status == 'Sent' ? element.Counts : 0,
            errorCount: element.Status == 'Error' ? element.Counts : 0,
          });
        } else {
          if (element.Status == 'Sent') {
            existingAttempt.successCount += element.Counts;
            existingElement.totalSuccess += element.Counts;
          } else {
            existingAttempt.errorCount += element.Counts;
            existingElement.totalError += element.Counts;
          }
        }

        const existingConsent = existingElement.consents.find(x => x.consent == element.Consent);

        if (existingConsent == null) {
          existingElement.consents.push({
            consent: element.Consent,
            count: element.Counts
          });
        } else {
          existingConsent.count += element.Counts;
        }
      }
    });
    this.channels = channelsData;
  }

  changeChannel(channel): void {
    this.selectedChannel = this.channels.find(x => x.channel == channel);
  }
}
