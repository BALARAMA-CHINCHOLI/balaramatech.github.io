import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AcionDialogComponent } from './acion-dialog.component';

describe('AcionDialogComponent', () => {
  let component: AcionDialogComponent;
  let fixture: ComponentFixture<AcionDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AcionDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AcionDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
