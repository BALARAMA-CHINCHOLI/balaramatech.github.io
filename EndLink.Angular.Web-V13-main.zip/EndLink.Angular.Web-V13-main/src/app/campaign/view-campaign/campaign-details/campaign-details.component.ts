import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { Subject } from 'rxjs';
import { debounceTime, distinctUntilChanged } from 'rxjs/operators';
import { CampaignService } from 'src/app/services/campaign.service';
import { ScrollerService } from 'src/app/services/scroller-service.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { SortingType } from 'src/app/shared/enums/sorting-type';
import { ListModel } from 'src/app/shared/models/list-model';
import { SearchFilter } from 'src/app/shared/models/search-filter';
import { AcionDialogComponent } from './acion-dialog/acion-dialog.component';

@Component({
  selector: 'app-campaign-details',
  templateUrl: './campaign-details.component.html',
  styleUrls: ['./campaign-details.component.scss']
})
export class CampaignDetailsComponent implements OnInit {
  actions = [];
  list: ListModel<any> = {
    list: [],
    hasNextPage: false,
  };
  campaignDescription = '';
  searchText = '';
  actionsFilter: SearchFilter = {
    paging: {
      pageNumber: 1,
      pageSize: 10,
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'MemberName',
    },
  };
  scroller$;
  searchSubject: Subject<string> = new Subject<string>();

  filterData: any = {
    globalSearch: '',
    sortHeader: '',
    sorOrder: '',
    filter: [],
  };
  pageActions: any;

  constructor(private campaignService: CampaignService, private scroller: ScrollerService, private toastr: ToasterService, private dialog: MatDialog, private router: Router, private route: ActivatedRoute,) { }

  ngOnInit(): void {
    this.getActions();
    this.scroller$ = this.scroller.scroller$.subscribe((res) => {
      if (this.list.hasNextPage) {
        this.actionsFilter.paging.pageNumber++;
        this.getActions();
      }
    });
    this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe((model) => {
        this.actionsFilter.paging.pageNumber = 1;
        this.getActions();
      });
  }

  getActions(): void {
    this.actionsFilter.SearchText = this.searchText;
    this.campaignService.viewCampaign('details', this.actionsFilter).subscribe(res => {
      if (!res.isError) {
        this.campaignDescription = res.responseObject.Description;
        this.actions = res.responseObject.Results;
        if (this.actionsFilter.paging.pageNumber === 1) {
          this.list.list = res.responseObject.Results;
          this.actions = [];
        } else {
          res.responseObject.Results.forEach((item) => {
            this.list.list.push(item);
          });
        }
        this.actions = this.list.list;
        this.list.hasNextPage =
          res.responseObject.list && res.responseObject.list.length > 0;
      } else {
        this.toastr.showErrorMessage(res.message);
      }
    }, err => {
      this.toastr.showErrorMessage(err.message);
    });

  }

  exportDetails(): void {
    this.campaignService.viewCampaign('export', this.actionsFilter).subscribe(res => {
      if (!res.isError) {
        this.toastr.showSuccessMessage("Exported successfully");
      } else {
        this.toastr.showErrorMessage(res.message);
      }
    }, err => {
      this.toastr.showErrorMessage(err.message);
    });
  }

  openDialog() {
    this.dialog.open(AcionDialogComponent);
  }
  search(event): void {
    this.searchSubject.next(event);
  }

}
