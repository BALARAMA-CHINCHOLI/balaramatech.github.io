import { Component, OnInit } from '@angular/core';
import { ChartType } from 'chart.js';
import { Color } from 'ng2-charts';
import { CampaignService } from 'src/app/services/campaign.service';
import { Chart, DoughnutChart } from 'src/app/shared/models/chart';

const centerTooltipPlugin = {
  id: 'centerTooltip',
  afterDraw(chart): void {
    const ctx = chart.ctx;
    let txt1 = '';
    let txt2 = '';

    try{
      const check = chart.active ? chart.tooltip._active[0]._datasetIndex : 'None';
      if (check !== 'None'){
      txt1 = chart.tooltip._data.labels[chart.tooltip._active[0]._index];
      txt2 = chart.tooltip._data.datasets[0].data[chart.tooltip._active[0]._index];
    }else{
      const data: any = Object.values(chart.tooltip._data.datasets[0]._meta)[0];
      txt1 = chart.titleBlock.options.text;
      txt2 = data.total;
    }
    }
    catch (err){
      const data: any = Object.values(chart.tooltip._data.datasets[0]._meta)[0];
      txt1 = chart.titleBlock.options.text;
      txt2 = data.total;
    }
    // Get options from the center object in options
    // const sidePadding = 60;
    // const sidePaddingCalculated = (sidePadding / 100) * (chart.innerRadius * 2);

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
    const centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);

    // Pick a new font size so it will not be larger than the height of label.
    const fontSizeToUse = 50;
    ctx.font = fontSizeToUse + 'px Arial';
    ctx.fillStyle = 'black';

    // Draw text in center
    ctx.fillText(txt2, centerX, centerY - (fontSizeToUse / 4));
    const fontSizeToUse1 = 25;
    ctx.font = fontSizeToUse1 + 'px Arial';
    ctx.fillText(txt1, centerX, centerY + (fontSizeToUse / 2));
  }
};

const progressTooltipPlugin = {
  id: 'centerTooltip',
  afterDraw(chart): void {
    const ctx = chart.ctx;
    let txt2 = '';
    const data: any = chart.tooltip._data.datasets[0].data;
    try{
      txt2 = Math.round(data[0] / data[1] * 100) + '%';
    }
    catch (err){
      // txt1 = chart.titleBlock.options.text;
      txt2 = Math.round(data[0] / data[1] * 100) + '%';
    }
    // Get options from the center object in options
    // const sidePadding = 60;
    // const sidePaddingCalculated = (sidePadding / 100) * (chart.innerRadius * 2);

    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    const centerX = ((chart.chartArea.left + chart.chartArea.right) / 2);
    const centerY = ((chart.chartArea.top + chart.chartArea.bottom) / 2);

    // Pick a new font size so it will not be larger than the height of label.
    const fontSizeToUse = 20;
    ctx.font = fontSizeToUse + 'px Arial';
    ctx.fillStyle = 'black';

    // Draw text in center
    ctx.fillText(txt2, centerX, centerY );

  }
};

const tooltipCallbacks = {
  title: function(tooltipItem, data): string {
    return data.labels[tooltipItem[0].index];
  },
  label: function(tooltipItem, data): string {
      const dataset = data.datasets[tooltipItem.datasetIndex];
      const total = dataset.data.reduce(((acc,cur)=> acc + cur), 0);
      return Math.round(dataset.data[tooltipItem.index] / total * 100) + '%';
  },
};

const progressTtooltipCallbacks = {
  label: function(tooltipItem, data): string {
      const dataset = data.datasets[tooltipItem.datasetIndex];
      return ' ' + data.labels[0] + ' ' + dataset.data[0];
  },
};

const doughnutLabels = ['Sent', 'Error', 'Pending'];

const statusBarColors = [{
  backgroundColor: 'rgba(0, 124, 204,1)',
  borderColor: 'rgba(0, 124, 204,1)',
  pointBackgroundColor: 'rgba(0, 124, 204,1)',
  pointBorderColor: 'var(--white)',
  pointHoverBackgroundColor: 'var(--white)',
  pointHoverBorderColor: 'rgba(0, 124, 204,1)'
},
{
  backgroundColor: 'rgba(253,211,34,1)',
  borderColor: 'rgba(253,211,34,1)',
  pointBackgroundColor: 'rgba(253,211,34,1)',
  pointBorderColor: 'var(--white)',
  pointHoverBackgroundColor: 'var(--white)',
  pointHoverBorderColor: 'rgba(253,211,34,1)'
},
{
  backgroundColor: 'rgba(242,96,96,1)',
  borderColor: 'rgba(242,96,96,1)',
  pointBackgroundColor: 'rgba(242,96,96,1)',
  pointBorderColor: 'var(--white)',
  pointHoverBackgroundColor: 'var(--white)',
  pointHoverBorderColor: 'rgba(242,96,96,1)'
}
];


@Component({
  selector: 'app-campaign-dashboard',
  templateUrl: './campaign-dashboard.component.html',
  styleUrls: ['./campaign-dashboard.component.scss'],
})
export class CampaignDashboardComponent implements OnInit {
  channels;
  images = [];
  totalSent = 0;
  totalError = 0;
  totalPending = 0;
  availableChannels = [];
  barChart: Chart = new Chart({
    type: 'bar',
    chartPlugins: [],
    chartOptions: {
      responsive: true,
      tooltips: {
        enabled: true,
        intersect: true,
        titleFontSize: 16,
        callbacks: {
          // tslint:disable-next-line: typedef
          title: function(tooltipItem, data) {
            const dataset = data.datasets[tooltipItem[0].datasetIndex];
            return dataset.stack;
          },
        }
      },
      plugins: {
        datalabels: {
           display: true,
           align: 'center',
           anchor: 'center',
        },
     }
    },
    labels: [],
    showLegend: false,
    data: []
  });

  barColors: Color[] = [...statusBarColors];
  doughnutColors: Color[] = [{
    backgroundColor: ['rgba(0, 124, 204,1)', 'rgba(242,96,96,1)', 'rgba(253,211,34,1)']
   }];
  sentProgressColors: Color[] = [{
    backgroundColor: ['rgba(0, 124, 204,1)', 'rgba(0, 124, 204,0.2)']
  }];
  pendingProgressColors: Color[] = [{
    backgroundColor: ['rgba(253,211,34,1)', 'rgba(253,211,34,0.2)']
  }];
  errorProgressColors: Color[] = [{
    backgroundColor: ['rgba(242,96,96,1)', 'rgba(242,96,96,0.2)']
  }];

  smsChart: DoughnutChart;
  voiceChart: DoughnutChart;
  mmsChart: DoughnutChart;
  mailChart: DoughnutChart;

  progressCharts = [];

  consent;

  constructor(private campaignService: CampaignService) {}

  ngOnInit(): void {
    this.getCampaignDetails();
  }

  getCampaignDetails(): void {
    this.campaignService.viewCampaign('dashboard').subscribe((res) => {
      this.barChart.labels = [];
      this.channels = res.responseObject.Channels;
      this.consent = res.responseObject.Consent;
      this.barChart.data = [];
      this.availableChannels = Object.keys(res.responseObject.Channels).map(channel => {
        this.barChart.data.push({
          data: [],
          label: 'Sent',
          stack: channel,
        },
        {
          data: [],
          label: 'Pending',
          stack: channel,
        },
        {
          data: [],
          label: 'Error',
          stack: channel,
        });
        return channel;
      });
      Object.values(this.channels).forEach((current: any) => {
        this.totalSent = current.TotalSent + this.totalSent;
        this.totalError = current.TotalError + this.totalError;
        this.totalPending = current.TotalPending + this.totalPending;
      });
      Object.values(this.channels).forEach((channel) => {
        this.barChart.labels = this.barChart.labels.concat(this.getDates(channel));
      });
      this.barChart.labels.forEach((day) => {
        this.availableChannels.forEach(channel => this.populateBarChartData(channel, day));
      });
      if (this.availableChannels.length === 1) {
        this.initiateStatusCharts(res.responseObject.Channels);
      } else if (this.availableChannels.length > 1) {
        this.initiateProgressCharts(res.responseObject.Channels);
      }
    });
  }

  getDates(channel): any {
    return channel.DateWise.filter(
      (schedule) => !this.barChart.labels.includes(schedule.Date)
    ).map((schedule) => schedule.Date);
  }

  initiateProgressCharts(data): void {
    const chartData = {chartPlugins: progressTooltipPlugin, callbacks: progressTtooltipCallbacks};
    Object.entries(data).forEach((channel: any) => {
      this.progressCharts.push(
        {
          channel: channel[0],
          totalCount: channel[1].Total,
          charts: [
            new DoughnutChart({...chartData, labels : ['Sent','']}),
            new DoughnutChart({...chartData, labels : ['Pending', '']}),
            new DoughnutChart({...chartData, labels : ['Error', '']})
          ]
        }
        );
      this.populateProgressChart(this.progressCharts[this.progressCharts.length - 1 ].charts, channel[1]);
    });
  }

  populateProgressChart(charts, data): void {
    charts[0].data.push([ data?.TotalSent, data?.Total]);
    charts[0].chartOptions.title.text = 'Sent';
    charts[1].data.push([ data?.TotalPending, data?.Total]);
    charts[1].chartOptions.title.text = 'Pending';
    charts[2].data.push([ data?.TotalError, data?.Total]);
    charts[2].chartOptions.title.text = 'Error';
  }

  initiateStatusCharts(data): void {
    const chartData = {labels: doughnutLabels , chartPlugins: centerTooltipPlugin, callbacks: tooltipCallbacks};
    this.availableChannels.forEach(channel => {
      switch (channel) {
        case 'SMS' :
          this.smsChart = new DoughnutChart(chartData);
          this.smsChart.chartOptions.title.text = 'SMS';
          this.populateDoughnutChart(this.smsChart, data?.SMS);
          break;
        case 'MMS' :
          this.mmsChart = new DoughnutChart(chartData);
          this.mmsChart.chartOptions.title.text = 'MMS';
          this.populateDoughnutChart(this.mmsChart, data?.MMS);
          break;
        case 'Voice':
          this.voiceChart = new DoughnutChart(chartData);
          this.voiceChart.chartOptions.title.text = 'Vocie';
          this.populateDoughnutChart(this.voiceChart, data?.Voice);
          break;
        case 'Email':
          this.mailChart = new DoughnutChart(chartData);
          this.mailChart.chartOptions.title.text = 'Email';
          this.populateDoughnutChart(this.mailChart, data?.Email);
          break;
      }
    });
    // Object.entries(data).forEach(channel => {
    //   this.populateDoughnutChart(channel[0], channel[1]);
    // });
  }

  populateDoughnutChart(chart, data): void {
    chart.data.push([ data?.TotalSent, data?.TotalError, data?.TotalPending]);
  }

  populateBarChartData(channel, day): any {
    const selectedChannel = this.channels[channel]?.DateWise?.find((schedule) => schedule.Date === day);
    const sentStatus =  this.barChart.data.find(section => section.label === 'Sent' && section.stack === channel);
    if (!!sentStatus) {
      sentStatus.data.push(selectedChannel.SentCount);
    }
    const pendingStatus =  this.barChart.data.find(section => section.label === 'Pending' && section.stack === channel);
    if (!!pendingStatus) {
      pendingStatus.data.push(selectedChannel.PendingCount);
    }
    const errorStatus =  this.barChart.data.find(section => section.label === 'Error' && section.stack === channel);
    if (!!errorStatus) {
      errorStatus.data.push(selectedChannel.ErrorCount);
    }
  }
}
