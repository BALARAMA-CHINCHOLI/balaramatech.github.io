import { Component, OnDestroy, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { SearchFilter } from '../shared/models/search-filter';
import { SortingType } from '../shared/enums/sorting-type';
import { ListModel } from '../shared/models/list-model';
import { Campaign } from '../shared/models/campaign';
import { CampaignService } from '../services/campaign.service';
import { MatDialog } from '@angular/material/dialog';
import { ToasterService } from '../services/toaster.service';
import { ScrollerService } from '../services/scroller-service.service';
import { CampaignStatusType } from '../shared/enums/campaign-status-type';
import { DatePipe } from '@angular/common';
import * as _moment from 'moment';
import { ConfirmationComponent } from '../shared/components/confirmation/confirmation.component';
import { fromEvent, of, Subject } from 'rxjs';
import { debounce, debounceTime, distinctUntilChanged } from 'rxjs/operators';

const moment = _moment;

@Component({
  selector: 'app-campaign',
  templateUrl: './campaign.component.html',
  styleUrls: ['./campaign.component.scss'],
})
export class CampaignComponent implements OnInit, OnDestroy {
  headerData: any[] = [
    {
      title: 'Name',
      type: 'text',
      prop: 'name',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },

    {
      title: 'Description',
      type: 'text',
      prop: 'description',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Members',
      type: 'text',
      prop: 'members',
      sort: false,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Scheduled From',
      type: 'text',
      prop: 'scheduleFromDate',
      sort: false,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Scheduled To',
      type: 'text',
      prop: 'scheduleToDate',
      sort: false,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Status',
      type: 'status',
      prop: 'status',
      sort: false,
      isFilter: true,
    },
  ];

  campaignFilter: SearchFilter = {
    SearchText: '',
    paging: {
      pageNumber: 1,
      pageSize: 10,
    },
    sorting: {
      order: SortingType.Desc,
      sortBy: 'ModifiedDate',
    },
  };

  list: ListModel<Campaign> = {
    list: [],
    hasNextPage: false,
  };

  tableData: any = {
    headerData: [],
    rowData: [],
    noRecordFound: true,
  };

  scrollerSubscribe: any;
  searchSubject: Subject<string> = new Subject<string>();

  constructor(
    private campaignService: CampaignService,
    private router: Router,
    private dialog: MatDialog,
    private toaster: ToasterService,
    private scroller: ScrollerService,
    private datepipe: DatePipe
  ) { }

  ngOnInit(): void {
    this.getCampaign();
    this.tableData.headerData = this.headerData;
    this.tableData.noRecordFound = true;
    this.scrollerSubscribe = this.scroller.scroller$.pipe().subscribe((res) => {
      if (this.list && this.list.hasNextPage) {
        this.campaignFilter.paging.pageNumber++;
        this.getCampaign();
      }
    });
    this.searchSubject
      .pipe(debounceTime(300), distinctUntilChanged())
      .subscribe((model) => {
        this.campaignFilter.paging.pageNumber = 1;
        this.getCampaign();
      });
  }

  getCampaign(): void {
    this.campaignService.list(this.campaignFilter).subscribe((data: any) => {
      if (this.campaignFilter.paging.pageNumber === 1) {
        this.list = data.responseObject;
        this.tableData.rowData = [];
      } else {
        data.responseObject.list.forEach((item) => {
          this.list.list.push(item);
        });
      }

      const tableData = [];
      this.list.list.forEach((item) => {
        tableData.push(this.parseTableData(item));
      });

      this.tableData.rowData = tableData;

      if (this.list.list.length > 0) {
        this.tableData.noRecordFound = false;
      }
      this.list.hasNextPage =
        data.responseObject.list && data.responseObject.list.length > 0;
    });
  }

  private parseTableData(campaign: Campaign): any {
    return {
      id: campaign.id,
      name: campaign.name,
      description: campaign.description,
      members: campaign.memberCount,
      scheduleFromDate:
        !!!campaign.scheduleFromDate ||
          campaign.scheduleFromDate == null ||
          campaign.scheduleFromDate === new Date('0001-01-01T00:00:00')
          ? '-'
          : moment(campaign.scheduleFromDate).format('MM/DD/YYYY'),
      scheduleToDate:
        !!!campaign.scheduleToDate ||
          campaign.scheduleToDate == null ||
          campaign.scheduleToDate === new Date('0001-01-01T00:00:00')
          ? '-'
          : moment(campaign.scheduleToDate).format('MM/DD/YYYY'),
      modifiedDate:
        !!!campaign.modifiedDate ||
          campaign.modifiedDate == null ||
          campaign.modifiedDate === new Date('0001-01-01T00:00:00')
          ? '-'
          : moment(campaign.modifiedDate).format('MM/DD/YYYY'),
      hideDeleteBtn: campaign.statusId == 2 || campaign.statusId == 8,
      hideAbortBtn: !(
        moment(campaign.scheduleFromDate).isBefore(moment(new Date())) &&
        campaign.statusId == 2
      ),
      hideEditBtn: campaign.statusId == 8,
      status: String(CampaignStatusType[campaign.statusId]).replace('_', ' '),
    };
  }

  search(event): void {
    this.searchSubject.next(event);
  }

  filterByStatus(event): void {
    this.campaignFilter.filter = {
      FilterBy: 'Status',
      Value: event || '',
    };
    this.campaignFilter.paging.pageNumber = 1;
    this.getCampaign();
  }

  tableActions(event): void {
    switch (event.action) {
      case 'view': {
        this.router.navigate(['/campaign/viewCampaign/' + event.rowData.id]);
        break;
      }
      case 'edit': {
        this.campaignService.campaignId.next(event.rowData.id);
        event.rowData.statusId =
          CampaignStatusType[event.rowData.status.replace(' ', '_')];
        this.campaignService.configureCampaign.next(
          new Campaign(event.rowData)
        );
        this.router.navigate(['/campaign/editCampaign/' + event.rowData.id]);
        break;
      }
      case 'copy': {
        this.campaignService.copyCamapaign(event.rowData.id).subscribe(res => {
          if (!res.isError) {
            this.router.navigate(['/campaign/copyCampaign/' + res.responseObject.id]);
          } else {
            this.toaster.showErrorMessage(res.message);
          }
        }, err => {
          this.toaster.showErrorMessage(err.message);
        });
      }
      case 'search': {
        this.campaignFilter.SearchText = event.filterData.globalSearch;
        this.campaignFilter.paging.pageNumber = 1;
        this.getCampaign();
        break;
      }
      case 'clear': {
        this.campaignFilter.SearchText = '';
        this.getCampaign();
        break;
      }
      case 'sort': {
        this.campaignFilter.sorting.sortBy = event.filterData.sortHeader;
        this.campaignFilter.sorting.order = event.filterData.sortOrder;
        this.getCampaign();
        break;
      }
      case 'abort': {
        let abortConfirm = this.dialog.open(ConfirmationComponent, {
          data: {
            message: 'Are you sure you want to abort this Campaign?',
            icon: 'warning',
            action: 'Abort',
          },
        });
        abortConfirm.afterClosed().subscribe((result) => {
          if (result) {
            this.campaignService
              .abort({ Id: event.rowData.id, StatusId: CampaignStatusType.Aborted })
              .subscribe(
                (res) => {
                  if (!res.isError) {
                    this.campaignFilter.paging.pageNumber = 1;
                    this.getCampaign();
                  } else {
                    this.toaster.showErrorMessage(res.message);
                  }
                },
                (err) => {
                  this.toaster.showErrorMessage(err.message);
                }
              );
          }
        });
        break;
      }
      case 'delete': {
        let deleteConfirm = this.dialog.open(ConfirmationComponent, {
          data: {
            message: 'Are you sure you want to delete this Campaign?',
            icon: 'delete',
            action: 'Delete',
          },
        });
        deleteConfirm.afterClosed().subscribe((result) => {
          if (result) {
            this.campaignService.delete(event.rowData.id).subscribe((res) => {
              if (!res.isError) {
                this.toaster.showSuccessMessage('Campaign deleted successfully');
                this.campaignFilter.paging.pageNumber = 1;
                this.getCampaign();
              }
            });
          }
        });
      }
    }
  }

  addCampaign() {
    this.campaignService.campaignId.next(0);
    this.router.navigateByUrl('/campaign/addCampaign');
  }

  ngOnDestroy() {
    this.scrollerSubscribe.unsubscribe();
  }
}
