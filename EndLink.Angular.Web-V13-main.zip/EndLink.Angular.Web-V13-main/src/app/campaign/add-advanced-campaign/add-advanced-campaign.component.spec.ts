import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddAdvancedCampaignComponent } from './add-advanced-campaign.component';

describe('AddAdvancedCampaignComponent', () => {
  let component: AddAdvancedCampaignComponent;
  let fixture: ComponentFixture<AddAdvancedCampaignComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddAdvancedCampaignComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddAdvancedCampaignComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
