import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatTableDataSource } from '@angular/material/table';
import { map, startWith } from 'rxjs/operators';

@Component({
  selector: 'app-add-advanced-campaign',
  templateUrl: './add-advanced-campaign.component.html',
  styleUrls: ['./add-advanced-campaign.component.scss']
})
export class AddAdvancedCampaignComponent implements OnInit {
  selectedMembers = {
    dataSource: new MatTableDataSource(),
    headerData: [
      {def: 'id', prop: 'id', title: 'Selection', type:'text'},
      {def: 'type', prop: 'mtype', title: 'Member Type', type:'text'},
      {def: 'filters', prop: 'filters', title: 'Filters', type:'text'},
      {def: 'members', prop: 'members', title: 'Members', type:'text'},
      {def: 'action', prop: 'action', title: 'Action', type:'action'},
    ]
  };
  actualGroups = ["Admin", "Blue", "Green", "Yellow", "Purple", "Orange"];
  groups = [];
  groupInput = new FormControl()
  filteredGroups;
  constructor() { }

  ngOnInit(): void {
    this.filteredGroups = this.groupInput.valueChanges.pipe(
      startWith(''),
        map(com => com ? this.filterfn('actualGroups', 'groups',com.toLowerCase()) : this.actualGroups.filter(communication => !this.groups.includes(communication)))
    );
  }

  addMembers(event) {
    this.selectedMembers.dataSource = new MatTableDataSource([...this.selectedMembers.dataSource.data, event]);
  }

  deleteMembers() {
    this.selectedMembers.dataSource = new MatTableDataSource();
  }

  removeChip(comMethod, fromSource, input) {
    const index = this[fromSource].indexOf(comMethod);
    if (index >= 0) {
      this[fromSource].splice(index, 1);
      this[input].setValue('');
    }
  }

  selectAutoComplete(event: MatAutocompleteSelectedEvent, source, input, target): void {
    this[source].push(event.option.viewValue);
    event.option.deselect();
    target.value = '';
    this[input].setValue('',{emitEvent: true});
    target.blur();
  }

  filterfn(from, selectedValues, input) {
    return this[from].filter(value => (value.toLowerCase().indexOf(input) === 0 && !this[selectedValues].includes(value)));
  }

}
