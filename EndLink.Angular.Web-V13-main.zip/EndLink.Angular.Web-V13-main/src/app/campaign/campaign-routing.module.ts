import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddCampaignGuard } from '../shared/helpers/campaign.guard';
import { AddAdvancedCampaignComponent } from './add-advanced-campaign/add-advanced-campaign.component';
import { ActionsComponent } from './add-campaign/actions/actions.component';
import { AddCampaignComponent } from './add-campaign/add-campaign.component';
import { ConfigureComponent } from './add-campaign/configure/configure.component';
import { RecipientsComponent } from './add-campaign/recipients/recipients.component';
import { ScheduleComponent } from '../shared/modules/add-campaign-shared/schedule/schedule.component';
import { CampaignComponent } from './campaign.component';
import { ViewCampaignComponent } from './view-campaign/view-campaign.component';

const routes: Routes = [
  {
    path: '',
    pathMatch: 'full',
    component: CampaignComponent,
    data: {
      breadcrumb: '',
    },
  },
  {
    path: 'addCampaign',
    component: AddCampaignComponent,
    data: {
      breadcrumb: 'Add Campaign',
      url: '/campaign/addCampaign',
      title: 'Add Campaign',
    },
    children: [
      {
        path: 'configure',
        component: ConfigureComponent,
      },
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'configure',
      },
    ],
  },
  {
    path: 'addCampaign/:id',
    component: AddCampaignComponent,
    data: {
      breadcrumb: 'Add Campaign',
      url: '/campaign/addCampaign',
      title: 'Add Campaign',
    },
    
    children: [
      {
        path: 'configure',
        component: ConfigureComponent,
        canActivate: [AddCampaignGuard],
      },
      {
        path: 'recipients',
        component: RecipientsComponent,

        canActivate: [AddCampaignGuard],
      },
      {
        path: 'actions',
        component: ActionsComponent,

        canActivate: [AddCampaignGuard],
      },
      {
        path: 'schedule',
        component: ScheduleComponent,
        canActivate: [AddCampaignGuard],
      },
      {
        path: 'preview',
        loadChildren: () => import('./add-campaign/preview/preview.module').then(m => m.PreviewModule),
      },
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'configure',
      },
    ],
  },
  {
    path: 'editCampaign/:id',
    component: AddCampaignComponent,
    data: {
      breadcrumb: 'Edit Campaign',
      url: '/campaign/editCampaign',
      title: 'Edit Campaign',
    },
    
    children: [
      {
        path: 'configure',
        component: ConfigureComponent,
        canActivate: [AddCampaignGuard],
      },
      {
        path: 'recipients',
        component: RecipientsComponent,

        canActivate: [AddCampaignGuard],
      },
      {
        path: 'actions',
        component: ActionsComponent,

        canActivate: [AddCampaignGuard],
      },
      {
        path: 'schedule',
        component: ScheduleComponent,
        canActivate: [AddCampaignGuard],
      },
      {
        path: 'preview',
        loadChildren: () => import('./add-campaign/preview/preview.module').then(m => m.PreviewModule),
      },
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'configure',
      },
    ],
  },
  {
    path: 'copyCampaign/:id',
    component: AddCampaignComponent,
    data: {
      breadcrumb: 'Copy Campaign',
      url: '/campaign/copyCampaign',
      title: 'Copy Campaign',
    },
    
    children: [
      {
        path: 'configure',
        component: ConfigureComponent,
        canActivate: [AddCampaignGuard],
      },
      {
        path: 'recipients',
        component: RecipientsComponent,

        canActivate: [AddCampaignGuard],
      },
      {
        path: 'actions',
        component: ActionsComponent,

        canActivate: [AddCampaignGuard],
      },
      {
        path: 'schedule',
        component: ScheduleComponent,
        canActivate: [AddCampaignGuard],
      },
      {
        path: 'preview',
        loadChildren: () => import('./add-campaign/preview/preview.module').then(m => m.PreviewModule),
      },
      {
        path: '',
        pathMatch: 'full',
        redirectTo: 'configure',
      },
    ],
  },
  {
    path: 'addAdvancedCampaign',
    component: AddAdvancedCampaignComponent,
  },
  
  {
    path: 'viewCampaign/:id',
    component: ViewCampaignComponent,
    data: {
      breadcrumb: 'View Campaign',
      url: '/campaign/viewCampaign',
      title: 'View Campaign',
    },
  },
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class CampaignRoutingModule {}
