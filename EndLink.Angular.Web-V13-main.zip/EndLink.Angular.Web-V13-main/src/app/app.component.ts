import { Component, OnInit } from '@angular/core';
import {  NavigationEnd, Router } from '@angular/router';
import { filter, map, pairwise, throttle } from 'rxjs/operators';
import { AuthenticationService } from './services/authentication.service';
import { BreadcrumbService } from './services/breadcrumb.service';
import { Response } from './shared/models/response';
import { paths } from '../../src/app/shared/constants';
import { ScrollerService } from './services/scroller-service.service';
import { fromEvent, interval } from 'rxjs';
import { LoaderService } from './services/loader.service';
import { NotificationService } from './services/notification.service';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  title = 'endlink';
  scrollPercent = 70;

  getYPosition(e: any): number {
    return e.target.scrollingElement.scrollTop;
  }

  constructor(private auth: AuthenticationService, private router: Router, private breadcrumb: BreadcrumbService,
    private scroller: ScrollerService, private loader: LoaderService,
    private notificationService: NotificationService) {
      fromEvent(window, 'scroll').pipe(
        map((e: any): any => ({
          sH: e.target.scrollingElement.scrollHeight,
          sT: e.target.scrollingElement.scrollTop,
          cH: e.target.scrollingElement.clientHeight
        })),
        pairwise(),
        filter(positions => this.isUserScrollingDown(positions) && this.isScrollExpectedPercent(positions[1])),
        throttle(ev => interval(500)),
      ).subscribe(res=>  {
        if(!this.loader.showLoader) {
          this.scroller.scroller$.next(res)
        }
        }
      );
     }
  ngOnInit() {
    this.router.events
      .pipe(
        filter((event) => event instanceof NavigationEnd)
      )
      .subscribe((event) => {
        if (!this.router.routerState.snapshot.url.split('?')[0].includes(paths.signUp) &&
          !this.router.routerState.snapshot.url.split('?')[0].includes(paths.forgotPassword) &&
          !this.router.routerState.snapshot.url.split('?')[0].includes(paths.resetPassword) && 
          !this.router.routerState.snapshot.url.split('?')[0].includes(paths.consent)) {
            const user = this.auth.currentUserValue;
            if(!!!user) {
              this.getUser();
            } else {
              this.notificationService.load();
            }
        }
        const root = this.router.routerState.snapshot.root;
        const breadcrumbs: any[] = [];
        this.breadcrumb.addBreadcrumb(root, breadcrumbs);
        this.breadcrumb._breadcrumbs$.next(breadcrumbs);

      });
  }

  private isUserScrollingDown = (positions) => {
    return positions[0].sT < positions[1].sT;
  }

  private isScrollExpectedPercent = (position) => {
   return ((position.sT + position.cH) / position.sH) > (this.scrollPercent / 100);
  }

  private getUser() {
    this.auth.getCurrentUser().subscribe((response: Response) => {
      if (!response.isError) {

        this.auth.setUser(response.responseObject);
      }
    });
  }
}
