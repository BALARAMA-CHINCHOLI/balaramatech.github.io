import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { ProfilesComponent } from './profiles.component';
import { ProfilesRoutingModule } from './profiles-routing.module';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';
import {Ng2TelInputModule} from 'ng2-tel-input';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    Ng2TelInputModule,
    ProfilesRoutingModule
  ],
  declarations: [ProfilesComponent]
})
export class ProfilesModule { }
