import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { AuthenticationService } from '../services/authentication.service';
import { ToasterService } from '../services/toaster.service';
import { UserProfileService } from '../services/user-profile.service';
import { paths } from '../shared/constants';
import { Response } from '../shared/models/response';
import { UserDetail } from '../shared/models/user-details';

@Component({
  selector: 'app-profiles',
  templateUrl: './profiles.component.html',
  styleUrls: ['./profiles.component.scss']
})
export class ProfilesComponent implements OnInit {

  model: UserDetail;
  submitted: boolean = false;
  role: string;
  currentobj: any;

  constructor(private userProfileService: UserProfileService,
    private toaster: ToasterService,
    private auth: AuthenticationService,
    private router: Router) {

  }

  ngOnInit() {
    this.getDetail();
  }

  private getDetail() {
    this.userProfileService.get().subscribe((data: Response) => {
      this.model = data.responseObject;
    });
  }

  save(isValid) {
    this.submitted = true;
    if (!isValid) {
      return;
    }

    if (this.model.gender < 1) {
      return;
    }

    this.userProfileService.update(this.model).subscribe((data) => {
      if (data.isError) {
        this.toaster.showErrorMessage(data.message);
      } else {
        this.toaster.showSuccessMessage('Profile updated successfully');
        this.redirect();
      }
    });

  }

  cancel(){
    this.redirect();
  }

  redirect() {
    this.auth.getCurrentUser().subscribe((response: Response) => {
      if (!response.isError) {

        this.auth.setUser(response.responseObject);

        if (response.responseObject !== null)
        {
          this.currentobj = localStorage.getItem("endlink.currentUser")
          const obj = JSON.parse(this.currentobj);
          this.role = obj.role
          if (this.role == 'SuperAdmin')
          {
            this.router.navigate([paths.organizationList]);
          }
          else if (this.role == 'Org-Admin') {
            this.router.navigate([paths.providersList]);
          }
          else
          {
            this.router.navigate([paths.dashboard]);
          }
        }

        
      }
    });
  }
}
