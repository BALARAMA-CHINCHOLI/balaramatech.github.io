import { Injectable } from "@angular/core";
import { apiUrls } from "../shared/constants";
import { ApiService } from "./api.service";

@Injectable({
  providedIn: "root"
})
export class OperatorService {

  constructor(private apiService: ApiService) {
  }

  list(dataTypeId: number) {
    return this.apiService.call('GET', apiUrls.operators + '?dataTypeId=' + dataTypeId);
  }
}
