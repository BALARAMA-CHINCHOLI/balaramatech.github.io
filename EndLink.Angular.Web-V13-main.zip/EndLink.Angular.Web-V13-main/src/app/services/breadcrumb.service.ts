import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, NavigationEnd, Router } from '@angular/router';
import { BehaviorSubject } from 'rxjs';
import { filter } from 'rxjs/operators';

@Injectable({
  providedIn: 'root',
})
export class BreadcrumbService {
  public readonly _breadcrumbs$ = new BehaviorSubject<any[]>([]);
  currentData = new BehaviorSubject('');

  readonly breadcrumbs$ = this._breadcrumbs$.asObservable();

  constructor() {}

  private updateData(data): void {
    this.currentData.next(data);
  }

  public addBreadcrumb(route: ActivatedRouteSnapshot, breadcrumbs: any[]): void {
    if(route) {
      if (!!route?.data && Object.keys(route?.data).length  > 0) {
        this.updateData(route.data);
      }
      if (route.data.breadcrumb) {
        const breadcrumb = {
          label: this.getLabel(route.data),
          url: route.data?.url,
          title: route.data.title,
        };
        const isBCAvail = breadcrumbs.find((bc) => bc?.label == breadcrumb.label);
        if (!!!isBCAvail) {
          breadcrumbs.push(breadcrumb);
        }
      }
      this.addBreadcrumb(route.firstChild, breadcrumbs);
    }
  }

  private getLabel(data: any) {
    return typeof data.breadcrumb === 'function'
      ? data.breadcrumb(data)
      : data.breadcrumb;
  }
}
