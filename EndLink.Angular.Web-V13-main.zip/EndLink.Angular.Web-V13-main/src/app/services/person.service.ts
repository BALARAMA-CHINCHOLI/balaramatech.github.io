import { ApiService } from './api.service';
import { Injectable } from '@angular/core';
import { apiUrls } from '../shared/constants';
import { PersonFilter } from '../shared/models/person-filter';

@Injectable({
  providedIn: 'root'
})
export class PersonService {

  constructor(private apiService: ApiService) {
  }

  list(filter: PersonFilter): any {
    return this.apiService.call('GET', apiUrls.persons, null, filter);
  }

  get(id: number) {
    return this.apiService.call('GET', apiUrls.persons + '?id=' + id);
  }
}
