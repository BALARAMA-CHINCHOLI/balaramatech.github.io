import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class PageService {
  isMobile = new BehaviorSubject(false);
  constructor() { 
    if( (/Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) ||
       window.innerWidth < 760) {
      this.isMobile.next(true);
    } else {
      this.isMobile.next(false);
    }
  }
}
