import { Injectable } from "@angular/core";
import { apiUrls } from "../shared/constants";
import { Rule } from "../shared/models/rule";
import { RuleFilter } from "../shared/models/rule-filter";
import { ApiService } from "./api.service";

@Injectable({
  providedIn: "root"
})
export class RuleService {

  constructor(private apiService: ApiService) {
  }

  get(id: number) {
    return this.apiService.call('GET', apiUrls.rules + '?id=' + id);
  }

  list(filter: RuleFilter) {
    return this.apiService.call('GET', apiUrls.rules, null, filter);
  }

  delete(id: number) {
    return this.apiService.call('DELETE', apiUrls.rules + '?id=' + id);
  }

  create(rule: Rule) {
    return this.apiService.call('POST', apiUrls.rules, rule);
  }

  update(rule: Rule) {
    return this.apiService.call('PUT', apiUrls.rules, rule);
  }
}
