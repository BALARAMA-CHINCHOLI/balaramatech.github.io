import { Injectable } from "@angular/core";
import { BehaviorSubject, combineLatest, concat, forkJoin, Observable, of } from "rxjs";
import { debounceTime, finalize, last } from "rxjs/operators";

@Injectable({
  providedIn: "root"
})
export class LoaderService {
  showLoader = false;
  loadingObseravables = new BehaviorSubject<any>([of(false)]);
  loaderSubject$ = [];

  constructor() {
    // combine all the sequential async calls to track for loader
    this.loadingObseravables.subscribe(observableList => {
      // Wait for all async calls to complete to hide the loader
      const subscriber$ =  combineLatest(observableList).subscribe((response: any) => {
        this.hide();
      });
    });
  }

  // By default consider one observable for simple cases
  show(loadingObservables = [of(true)]): void {
    this.showLoader = true;
    this.loadingObseravables.next(loadingObservables);
  }

  hide(): void {
    this.showLoader = false;
    this.loaderSubject$ = [];
  }
}
