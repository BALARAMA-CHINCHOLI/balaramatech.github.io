import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { apiUrls } from "../shared/constants";
import { Response } from "../shared/models/response";
import { User } from "../shared/models/user";
import { UserRegistration } from "../shared/models/user-registration";

@Injectable({
  providedIn: "root"
})
export class UserService {

  constructor(private http: HttpClient) {
  }

  register(user: UserRegistration) {
    return this.http.post<Response>(apiUrls.users, user);
  }
  getSignUpDetail(code: string, flag: string) {
    return this.http.get<Response>(apiUrls.users + '?code=' + code + '&flag=' + flag);
  }

  inviteUsers(inviteUser: any) {
    return this.http.post<Response>(apiUrls.inviteUsers, inviteUser);
  }  

  list(filter: any) {
    let httpParams = new HttpParams();
    if (filter.id) {
      httpParams = httpParams.set('id', filter.id.toString());
    }
    if (filter.name) {
      httpParams = httpParams.set('SearchText', filter.name.toString());
    }
    if (filter.email) {
      httpParams = httpParams.set('email', filter.email.toString());
    }
    if (filter.paging) {
     httpParams = httpParams.set('paging.pageNumber', filter.paging.pageNumber.toString());
     httpParams = httpParams.set('paging.pageSize', filter.paging.pageSize.toString());
    }
    if (filter.sorting) {
     httpParams = httpParams.set('sorting.SortBy', filter.sorting.sortBy.toString());
     httpParams = httpParams.set('sorting.order', filter.sorting.order.toString());
    }

    const httpOptions = {
      params: httpParams
    };

    return this.http.get<Response>(apiUrls.inviteUsers, httpOptions);
  }
  update(user: User) {
    return this.http.put<Response>(apiUrls.inviteUsers, user);
  }
}
