import { ApiService } from './api.service';
import { Injectable } from '@angular/core';
import { apiUrls } from 'src/app/shared/constants';
import { TemplateFilter } from '../shared/models/template-filter';

@Injectable({
  providedIn: 'root'
})
export class TemplateService {

  constructor(private apiService: ApiService) { }

  list(filter: TemplateFilter): any {
    return this.apiService.call('GET', apiUrls.templates, null, filter);
  }
}
