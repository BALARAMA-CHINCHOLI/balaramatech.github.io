import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { apiUrls } from "../shared/constants";
import { Response } from "../shared/models/response";

@Injectable({
  providedIn: "root"
})
export class CityService {

  constructor(private http: HttpClient) {
  }

  list() {
    return this.http.get<Response>(apiUrls.cities);
  }
}
