import { Injectable } from "@angular/core";
import { MatSnackBar } from "@angular/material/snack-bar";

@Injectable({
  providedIn: "root"
})
export class ToasterService {
  constructor(private _snackBar: MatSnackBar) { }

  showSuccessMessage(text: string) {
    this._snackBar.open(text, "OK", {
      duration: 2000,
    });
  }

  showErrorMessage(text: string) {
    this._snackBar.open(text, "OK", {
      duration: 2000,
    });
  }
}
