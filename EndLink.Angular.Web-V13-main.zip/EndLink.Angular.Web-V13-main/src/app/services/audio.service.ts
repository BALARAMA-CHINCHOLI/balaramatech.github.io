import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { apiUrls } from '../shared/constants';
import { Audio } from '../shared/models/audio';
import { Response } from '../shared/models/response';
import { SearchFilter } from '../shared/models/search-filter';
import { ApiService } from './api.service';

@Injectable({
  providedIn: 'root'
})
export class AudioService {

  constructor(private http: HttpClient, private apiService: ApiService) { }

  upload(file: File): any {
    const formData = new FormData();
    formData.append("file", file);

    let head = new HttpHeaders();
    const httpOptions = {
      headers: head,
    };

    return this.http.post(apiUrls.audioUpload, formData, httpOptions);
  }

  list(filter: SearchFilter): any {
    return this.apiService.call('GET', apiUrls.audio, null, filter);
  }

  update(item: Audio) {
    return this.http.put<Response>(apiUrls.audio, item);
  }

  delete(id: number) {
    return this.http.delete<Response>(apiUrls.audio + '/?id=' + id);
  }
}
