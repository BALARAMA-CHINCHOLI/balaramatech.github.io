import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { apiUrls } from "../shared/constants";
import { Person } from "../shared/models/person";
import { PersonFilter } from "../shared/models/person-filter";
import { Response } from "../shared/models/response";

@Injectable({
  providedIn: "root"
})
export class PatientService {

  constructor(private http: HttpClient) {
  }

  list(filter: PersonFilter) {
    let httpParams = new HttpParams();
    if (filter.id) {
      httpParams = httpParams.set('id', filter.id.toString());
    }
    if (filter.searchText) {
      httpParams = httpParams.set('searchText', filter.searchText.toString());
    }
    if (filter.term) {
      httpParams = httpParams.set('term', filter.term.toString());
    }
    if (filter.name) {
      httpParams = httpParams.set('name', filter.name.toString());
    }
    if (filter.cellPhone) {
      httpParams = httpParams.set('cellPhone', filter.cellPhone.toString());
    }
    if (filter.city) {
      httpParams = httpParams.set('city',  filter.city.toString());
    }
    if(filter.state) {
      httpParams = httpParams.set('state', filter.state.toString());
    }
    if (filter.email) {
      httpParams = httpParams.set('email', filter.email.toString());
    }
    if (filter.gender) {
      httpParams = httpParams.set('gender', filter.gender.toString());
    }
    if (filter.maximumAge) {
      httpParams = httpParams.set('maximumAge', filter.maximumAge.toString());
    }
    if (filter.minimumAge) {
      httpParams = httpParams.set('minimumAge', filter.minimumAge.toString());
    }
    if (filter.paging) {
      httpParams = httpParams.set('paging.pageNumber', filter.paging.pageNumber.toString());
      httpParams = httpParams.set('paging.pageSize', filter.paging.pageSize.toString());
    }
    if (filter.sorting) {
      httpParams = httpParams.set('sorting.SortBy', filter.sorting.sortBy.toString());
      httpParams = httpParams.set('sorting.order', filter.sorting.order.toString());
    }

    const httpOptions = {
      params: httpParams
    };

    return this.http.get<Response>(apiUrls.patients, httpOptions);
  }

  update(patient: Person) {
    return this.http.put<Response>(apiUrls.patients, patient);
  }

  updateStatus(patient: Person) {
    return this.http.put<Response>(apiUrls.persons, {id: patient.id, isActive: patient.isActive});
  }
  
  create(patient: Person) {
    return this.http.post<Response>(apiUrls.patients, patient);
  }

  get(id: number) {
    return this.http.get<Response>(apiUrls.patients + '?id=' + id);
  }
}
