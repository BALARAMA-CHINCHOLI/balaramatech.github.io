
import { Inject, Injectable, PLATFORM_ID } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { BehaviorSubject, Observable } from 'rxjs';
import { isPlatformBrowser } from '@angular/common';
import { User } from '../shared/models/user';
import { apiUrls, keys, paths } from '../shared/constants';
import { Login } from '../shared/models/login';
import { Response } from '../shared/models/response';
import { Router } from '@angular/router';

@Injectable({ providedIn: 'root' })
export class AuthenticationService {
    private currentUserSubject: BehaviorSubject<User>;
    public currentUser: Observable<User>;

    constructor(private http: HttpClient,
        private router: Router,
        @Inject(PLATFORM_ID) private platformId: any) {
        if (isPlatformBrowser(this.platformId)) {
          this.currentUserSubject = new BehaviorSubject<User>(JSON.parse(this.getLocalStorage(keys.currentUser)));
          this.currentUser = this.currentUserSubject.asObservable();
        }
    }

    public get currentUserValue(): User {
        if (isPlatformBrowser(this.platformId)) {
            return this.currentUserSubject.value;
        }
    }

    login(model: Login) {
        return this.http.post<Response>(apiUrls.login, model);
    }

    setLocalStorage(key: string, value: string) {
        localStorage.setItem(key, value);
    }

    getLocalStorage(key: string): string {
        return localStorage.getItem(key);
    }

    setUser(user: User) {
        if (user == null) {
            this.logout();
        }
        else
        {
            this.setLocalStorage(keys.currentUser, JSON.stringify(user));
            this.currentUserSubject.next(user);
            var currentobj = localStorage.getItem("endlink.currentUser")
            const obj = JSON.parse(currentobj); 
            if (obj.themeId == 2)
            {
              document.body.classList.add("darkMode");
            }
            else
            {
              document.body.classList.remove("darkMode");
            }
        }
    }

    getCurrentUser() {
        return this.http.get<Response>(apiUrls.users);
    }

    logout() {
        // remove user from local storage to log user out
        if (isPlatformBrowser(this.platformId)) {
            localStorage.removeItem(keys.token);
            localStorage.removeItem(keys.currentUser);
            this.currentUserSubject.next(null);
            this.router.navigateByUrl(paths.auth);
        }
    }
}
