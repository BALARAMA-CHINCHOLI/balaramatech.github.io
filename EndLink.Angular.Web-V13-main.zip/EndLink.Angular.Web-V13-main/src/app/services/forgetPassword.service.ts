import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { apiUrls } from "../shared/constants";
import { forgetPassword } from '../shared/models/forgetPassword';
import { Response } from "../shared/models/response";

@Injectable({
  providedIn: "root"
})
export class ForgetPasswordService {

  constructor(private http: HttpClient) {
  }

  forgetPassword(UserName: forgetPassword) {
    return this.http.post<Response>(apiUrls.forgetPassword,  UserName);
  }
}
