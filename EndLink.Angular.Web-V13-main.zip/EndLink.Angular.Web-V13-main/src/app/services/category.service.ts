import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';
import { apiUrls } from '../shared/constants';
import { Category } from '../shared/models/category';

@Injectable()
export class CategoryService {
  categories = new BehaviorSubject<Category[]>([]);
  constructor(private http: HttpClient) {
    this.getCategories();
   }

  getCategories() {
    this.http.get<Response>(apiUrls.categories).subscribe((res:any) => {
      if(!res.isError) {
        this.categories.next(res.responseObject);
      }
    });
  }

}
