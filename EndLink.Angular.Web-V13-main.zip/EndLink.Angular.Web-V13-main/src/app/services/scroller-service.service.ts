import { Injectable } from '@angular/core';
import { BehaviorSubject, Observable, Subject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class ScrollerService {

  scroller$ = new BehaviorSubject(null);
  scrollTo$ = new Subject<any>();
  constructor() { }


}
