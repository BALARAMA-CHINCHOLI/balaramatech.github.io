import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import * as moment from "moment";
import { apiUrls } from "../shared/constants";
import { Response } from "../shared/models/response";
import { SearchFilter } from "../shared/models/search-filter";
import { Workflow, WorkflowAction } from "../shared/models/workflow";
import { ApiService } from "./api.service";

@Injectable({
  providedIn: "root"
})
export class WorkflowService {

  constructor(private apiService: ApiService,
    private http: HttpClient) {
  }

  get(id: number) {
    return this.apiService.call('GET', apiUrls.workflow + '?id=' + id);
  }

  list(filter: SearchFilter) {
    return this.apiService.call('GET', apiUrls.workflow, null, filter);
  }
  
  viewpatient(filter: SearchFilter) {
    return this.apiService.call('GET', apiUrls.ViewPatient, null, filter);
  }


  delete(id: number) {
    return this.apiService.call('DELETE', apiUrls.workflow + '?id=' + id);
  }

  create(workflow: Workflow) {
    return this.apiService.call('POST', apiUrls.workflow, workflow);
  }

  update(workflow: Workflow) {
    return this.apiService.call('PUT', apiUrls.workflow, workflow);
  }

  getStats(filter: SearchFilter) {
    return this.apiService.call('GET', apiUrls.workflowStats, null, filter);
  }

  getActions(workflowId: number) {
    return this.apiService.call('GET', apiUrls.workflowActions + '?workflowId=' + workflowId);
  }

  saveActions(actions: WorkflowAction[]) {
    return this.apiService.call('POST', apiUrls.workflowActions, actions);
  }

  deleteActions(id) {
    return this.apiService.call('DELETE', apiUrls.workflowActions+'?id='+id);
  }

  copy(workflowId: number) {
    return this.apiService.call('POST', apiUrls.workflowCopy + '?workflowId=' + workflowId);
  }

  getWorkflowMergeFields(eventTypeId: number) {
    return this.apiService.call('GET', apiUrls.workflowMergeFields + '?id=' + eventTypeId);
  }

  getWorkflowReports(filter: SearchFilter) {
    let httpParams = new HttpParams();
    if (filter.SearchText) {
      httpParams = httpParams.set('SearchText', filter.SearchText.toString());
    }
    if (filter.paging) {
      httpParams = httpParams.set('paging.pageNumber', filter.paging.pageNumber.toString());
      httpParams = httpParams.set('paging.pageSize', filter.paging.pageSize.toString());
    }
    if (filter.sorting) {
      httpParams = httpParams.set('sorting.order', filter.sorting.order.toString());
      httpParams = httpParams.set('sorting.sortBy', filter.sorting.sortBy.toString());
    }
    if (filter.date) {
      if (filter.date.startDate) {
        httpParams = httpParams.set('date.startDate', moment(filter.date.startDate).format('YYYY-MM-DD'));
      }
      if (filter.date.endDate) {
        httpParams = httpParams.set('date.endDate', moment(filter.date.endDate).format('YYYY-MM-DD'));
      }
    }
    if (filter.filter) {
      httpParams = httpParams.set('filter.Value', filter.filter.Value.toString());
      httpParams = httpParams.set('filter.FilterBy', filter.filter.FilterBy.toString());
    }

    const httpOptions = {
      params: httpParams
    };

    return this.http.get<Response>(apiUrls.workflowReports, httpOptions);
    //return this.apiService.call('GET', apiUrls.workflowReports, null, filter);
  }
}
