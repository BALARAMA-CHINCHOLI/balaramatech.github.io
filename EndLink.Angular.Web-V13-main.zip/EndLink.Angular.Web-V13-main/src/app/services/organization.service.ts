import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { apiUrls } from "../shared/constants";
import { OrganizationFilter } from "../shared/models/organization-filter";
import { Response } from "../shared/models/response";
import { Organization } from '../shared/models/organization';

@Injectable({
  providedIn: "root"
})
export class OrganizationService {
  selectedOrganization : Organization;
  constructor(private http: HttpClient) {
  }

  list(filter: OrganizationFilter, hideLoader = false) {
    let httpParams = new HttpParams();
    if (filter.id) {
      httpParams = httpParams.set('id', filter.id.toString());
    }
    if (filter.name) {
      httpParams = httpParams.set('SearchText', filter.name.toString());
    }
    if (filter.email) {
      httpParams = httpParams.set('email', filter.email.toString());
    }
    if (filter.paging) {
     httpParams = httpParams.set('paging.pageNumber', filter.paging.pageNumber.toString());
     httpParams = httpParams.set('paging.pageSize', filter.paging.pageSize.toString());
    }
    if (filter.sorting) {
     httpParams = httpParams.set('sorting.SortBy', filter.sorting.sortBy.toString());
     httpParams = httpParams.set('sorting.order', filter.sorting.order.toString());
    }

    if(hideLoader) {
      httpParams = httpParams.set('hideGlobalLoader', 'true');
    }
    const httpOptions = {
      params: httpParams
    };

    return this.http.get<Response>(apiUrls.organization, httpOptions);
  }

  update(org: Organization) {
    return this.http.put<Response>(apiUrls.organization, org);
  }

  create(org: Organization) {
    return this.http.post<Response>(apiUrls.organization, org);
  }

  get(id: number) {
    return this.http.get<Response>(apiUrls.organization + '?id=' + id);
  }
}
