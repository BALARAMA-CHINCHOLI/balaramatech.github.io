import { ApiService } from './api.service';
import { Injectable } from '@angular/core';
import { apiUrls, paths } from 'src/app/shared/constants';
import { SearchFilter } from '../shared/models/search-filter';
import { BehaviorSubject, Observable, of } from 'rxjs';
import { HttpClient, HttpParams } from '@angular/common/http';
import { MembersService } from './members.service';

@Injectable({
  providedIn: 'root',
})
export class CampaignService {
  configureCampaign = new BehaviorSubject(null);
  campaignActions = new BehaviorSubject([]);
  campaignSchedule = new BehaviorSubject([]);
  campaignRecipientGroups = new BehaviorSubject([]);
  campaignRecipientUploads = new BehaviorSubject([]);
  isRecipientsUpdated = false;

  campaignId = new BehaviorSubject(0);

  constructor(private apiService: ApiService, private http: HttpClient, private memberService: MembersService) {}

  list(filter: SearchFilter): any {
    return this.apiService.call('GET', apiUrls.campaign, null, filter);
  }

  get(id: number) {
    return this.apiService.call('GET', apiUrls.campaign + '?Id=' + id);
  }

  updateAction(action): any {
    return this.apiService.call('PUT', apiUrls.campaign, {});
  }

  create(campaign: any): any {
    return this.apiService.call('POST', apiUrls.campaign, campaign);
  }

  updateCampaign(campaign: any) {
    return this.apiService.call('PUT', apiUrls.campaign, campaign);
  }

  delete(id: number) {
    return this.apiService.call('DELETE', apiUrls.campaign + '?Id=' + id);
  }

  abort(data: any) {
    return this.apiService.call('PUT', apiUrls.campaignStatus, data);
  }

  sendTest(message: string, mobile: string): Observable<any> {
    const data = {
      ToNumber: mobile,
      Content: message
    };
    return this.apiService.call('POST', apiUrls.sendSMS, data);
  }

  /*Method to Send MMS*/
  sendTestMMS(message: string, mobile: string, media = ''): Observable<any> {
    const data = {
      ToNumber: mobile,
      Content: message,
      MediaUrl: media
    };
    return this.apiService.call('POST', apiUrls.sendMMS, data);
  }

  viewCampaign(type, filter: SearchFilter = null): Observable<any> {
    if (!!filter) {
      let httpParams = new HttpParams();
      httpParams = httpParams.set('Id', this.campaignId.value.toString());
      httpParams = httpParams.set('type', type);
      httpParams = httpParams.set('SearchText', filter.SearchText || 'a');
      if (filter.paging) {
        httpParams = httpParams.set('paging.pageNumber', filter.paging.pageNumber.toString());
        httpParams = httpParams.set('paging.pageSize', filter.paging.pageSize.toString());
      }
      if (filter.sorting) {
        httpParams = httpParams.set('sorting.sortBy', filter.sorting.sortBy.toString());
        httpParams = httpParams.set('sorting.order', filter.sorting.order.toString());
      }

      const httpOptions = {
        params: httpParams
      };
      return this.http.get<Response>(apiUrls.viewCampaign, httpOptions);
    } else {
      return this.apiService.call(
        'GET',
        apiUrls.viewCampaign + '?Id=' + this.campaignId.value + '&type=' + type
      );
    }
  }

  copyCamapaign(id: number): Observable<any> {
    return this.apiService.call('POST', apiUrls.copyCampaign + '?id=' + id);
  }

  updateRecipients(): Observable<any> {
    const recipients = {
      CampaignId: this.campaignId.value,
      Persons: this.memberService.selectedMembers.value,
      Groups: this.campaignRecipientGroups.value,
      Files: this.campaignRecipientUploads.value.filter(file => file.isUploaded).map(file =>
            ({FileUrl: file.FileUrl, TotalCount: file.totalCount})
      ),
    };
    return this.apiService.call('POST', apiUrls.campaignRecipients, recipients);
  }

  updateActions() {
    return this.apiService.call(
      'POST',
      apiUrls.campaignActions,
      this.campaignActions.value
    );
  }

  updateSchedules(plans) {
    return this.apiService.call('POST', apiUrls.campaignPlans, plans);
  }

  fileUpload(file, source) {
    let formData: FormData = new FormData();
    formData.append('file', file, file.name);
    let headers = new Headers();
    headers.append('Content-Type', 'text/csv');
    return this.apiService.call(
      'POST',
      apiUrls.fileUpload + '?type=' + source,
      formData,
      headers
    );
  }

  donwloadSample() {
    return this.apiService.call('GET', apiUrls.uploadMembersTemplate);
  }

  donwload(file) {
    this.apiService.call('GET', apiUrls.downloadFileToken).subscribe((res) => {
      let url = file + res.responseObject;
      window.open(url, '_blank').focus();
    });
  }

  hasRecipients = () =>
    this.memberService.selectedMembers.value.length > 0 ||
    this.campaignRecipientGroups.value.length > 0 ||
    this.campaignRecipientUploads.value.length > 0;


  deletePlans(id) {
    return this.apiService.call('DELETE', apiUrls.campaignPlans + '?Id=' + id); 
  }
}
