import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { apiUrls } from "../shared/constants";
import { Response } from "../shared/models/response";

@Injectable({
  providedIn: "root"
})
export class DashboardService {

  constructor(private http: HttpClient) {
  }

  get(typeId: number, entityId?: number, periodId?: number) {
    let url = apiUrls.dashboard + '?typeId=' + typeId;

    if (entityId) {
      url = url + '&entityId=' + entityId;
    }
    if (periodId) {
      url = url + '&periodId=' + periodId;
    }

    return this.http.get<Response>(url);
  }
}
