import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class ApiService {

    constructor(private http: HttpClient) {

    }

    call(method, url: string, body?: any, prms?: any, headers?: Headers): any {
        const options: any = {
            body,
            params: this.objectConversion(prms),
            headers: headers
        };

        return this.http.request(method, url, options);
    }

    private objectConversion(obj): object {
        const flattenedObject = {};
        this.traverseAndFlatten(obj, flattenedObject);
        return flattenedObject;
    }

    private traverseAndFlatten(currentNode, target, flattenedKey?: any): void {
        for (const key in currentNode) {
            if (currentNode.hasOwnProperty(key)) {
                let newKey;
                if (flattenedKey === undefined) {
                    newKey = key;
                } else {
                    newKey = flattenedKey + '.' + key;
                }

                const value = currentNode[key];
                if (typeof value === 'object') {
                    this.traverseAndFlatten(value, target, newKey);
                } else {
                    target[newKey] = value;
                }
            }
        }
    }
}
