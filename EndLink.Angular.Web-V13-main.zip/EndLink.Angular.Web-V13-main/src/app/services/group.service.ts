import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable } from "rxjs";
import { apiUrls } from "../shared/constants";
import { Group } from "../shared/models/group";
import { Response } from "../shared/models/response";
import { SearchFilter } from "../shared/models/search-filter";

@Injectable({
  providedIn: "root"
})
export class GroupService {
  selectedGroup: Group;
  bulkGroupsList = new BehaviorSubject([]);
  bulkGroups = new BehaviorSubject([]);
  constructor(private http: HttpClient) {
  }

  list(filter: SearchFilter) {
    let httpParams = new HttpParams();
    if (filter.SearchText) {
      httpParams = httpParams.set('SearchText', filter.SearchText.toString());
    }
    if (filter.getAll) {
      httpParams = httpParams.set('getAll', filter.getAll.toString());
    }
    if (filter.paging) {
      httpParams = httpParams.set('paging.pageNumber', filter.paging.pageNumber.toString());
      httpParams = httpParams.set('paging.pageSize', filter.paging.pageSize.toString());
    }
    if (filter.sorting) {
      httpParams = httpParams.set('sorting.SortBy', filter.sorting.sortBy.toString());
      httpParams = httpParams.set('sorting.order', filter.sorting.order.toString());
    }
    if (filter.IsActive) {
      httpParams = httpParams.set('IsActive', filter.IsActive.toString());
    }

    const httpOptions = {
      params: httpParams
    };

    return this.http.get<Response>(apiUrls.groups, httpOptions);
  }
  getGroup(id: number) {
    return this.http.get<Response>(apiUrls.groups + '?id=' + id);
  }

  create(data) {
    return this.http.post<Response>(apiUrls.groups, data);
  }

  update(item) {
    return this.http.put<Response>(apiUrls.groups, item);
  }
  updateStatus(item) {
    return this.http.put<Response>(apiUrls.groupStatus, item);
  }

  delete(id: number) {
    return this.http.delete<Response>(apiUrls.groups + '?id=' + id);
  }
  deleteFile(id: number) {
    return this.http.delete<Response>(apiUrls.groups + '?id=' + id);
  }
  download(id: number) {
    return this.http.get<Response>(apiUrls.groupsDownload + '?id=' + id);
  }

  donwloadSample() {
    return this.http.get<Response>(apiUrls.uploadBulkTemplate);
  }

  fileUpload(file, source) {
    let formData: FormData = new FormData();
    formData.append('file', file, file.name);
    let headers = new Headers();
    headers.append('Content-Type', 'text/csv');
    return this.http.post<Response>(apiUrls.fileUpload + '?type=' + source, formData);
  }

  donwload(file) {
    this.http.get<Response>(apiUrls.downloadFileToken).subscribe((res) => {
      let url = file + res.responseObject;
      window.open(url, '_blank').focus();
    });
  }

  updateGroups(): Observable<any> {
    const groups = {
      Persons: this.bulkGroupsList.value,
      Files: this.bulkGroups.value.filter(file => file.isUploaded).map(file =>
        ({ FileUrl: file.FileUrl, TotalCount: file.totalCount })
      ),
    };
    return this.http.post<Response>(apiUrls.groups, groups);
  }
  hasRecipients = () =>
    this.bulkGroupsList.value.length > 0 ||
    this.bulkGroups.value.length > 0;
}
