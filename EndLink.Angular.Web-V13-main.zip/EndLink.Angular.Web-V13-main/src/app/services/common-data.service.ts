import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { apiUrls } from "../shared/constants";
import { ApiService } from "./api.service";

@Injectable({
  providedIn: "root"
})
export class CommonDataService {

  constructor(private apiService: ApiService,
    private http: HttpClient) {
  }

  get(entity: string) {
    return this.apiService.call('GET', apiUrls.commonData + '?entity=' + entity);
  }
}
