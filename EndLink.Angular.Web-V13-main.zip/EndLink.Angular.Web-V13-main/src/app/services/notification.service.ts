import { Injectable } from "@angular/core";
import { BehaviorSubject, Observable, Subject } from "rxjs";
import { apiUrls } from "../shared/constants";
import { Notification } from "../shared/models/notification";
import { Response } from "../shared/models/response";
import { ApiService } from "./api.service";

@Injectable({
  providedIn: "root"
})
export class NotificationService {

  public list$: BehaviorSubject<Notification[]> = new BehaviorSubject<Notification[]>([]);

  constructor(private apiService: ApiService) {
  }

  load() {
    this.apiService.call('GET', apiUrls.notifications).subscribe((data: Response) => {
      this.list$.next(data.responseObject);
    });
  }

  markAsRead() {
    return this.apiService.call('POST', apiUrls.notifications);
  }

  count() {
    return this.apiService.call('GET', apiUrls.notificationsCount);
  }
}
