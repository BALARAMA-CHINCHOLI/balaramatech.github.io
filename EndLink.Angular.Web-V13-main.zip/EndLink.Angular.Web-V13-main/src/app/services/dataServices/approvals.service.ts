import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { apiUrls } from 'src/app/shared/constants';
import { SearchFilter } from 'src/app/shared/models/search-filter';
import { ApiService } from '../api.service';

@Injectable({
  providedIn: 'root'
})
export class ApprovalsService {
  selectedApproval: any;

  constructor(private apiService: ApiService) {
  }

  list(filter: SearchFilter, types, status): Observable<any> {
    const filters = {
      Types: types || ['Campaign', 'Workflow', 'Rule'],
      Status: status || [],
      SearchFilter: {
          SearchText: filter.SearchText || '',
          Paging: {
              PageNumber: filter.paging.pageNumber,
              PageSize: filter.paging.pageSize
          },
          Sorting: {
              Order: filter.sorting.order,
              SortBy: filter.sorting.sortBy
          }
      }
    };

    return this.apiService.call('POST', apiUrls.approvalsList, filters);
  }

  updateStatus(id, type, status): Observable<any> {
    const payload = {
      Id: id,
      Type: type,
      StatusId: status
    };
    return this.apiService.call('PUT', apiUrls.approvalsList, payload);
  }

}
