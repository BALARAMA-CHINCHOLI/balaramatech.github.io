import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { apiUrls } from 'src/app/shared/constants';
import { Appointment } from 'src/app/shared/models/appointment';
import { SearchFilter } from 'src/app/shared/models/search-filter';

@Injectable({
  providedIn: 'root'
})
export class AppointmentService {
  selectedAppointment:Appointment;
  constructor(private http: HttpClient) {
  }

  list(filter: SearchFilter) {
    let httpParams = new HttpParams();
    if (filter.SearchText) {
      httpParams = httpParams.set('SearchText', filter.SearchText.toString());
    }
    if (filter.paging) {
      httpParams = httpParams.set('paging.pageNumber', filter.paging.pageNumber.toString());
      httpParams = httpParams.set('paging.pageSize', filter.paging.pageSize.toString());
    }
    if (filter.sorting) {
      httpParams = httpParams.set('sorting.sortBy', filter.sorting.sortBy.toString());
      httpParams = httpParams.set('sorting.order', filter.sorting.order.toString());
    }

    const httpOptions = {
      params: httpParams
    };

    return this.http.get<Response>(apiUrls.appointments, httpOptions);
  }

  getAppiontment(id) {
    let httpParams = new HttpParams();
    httpParams = httpParams.set('Id', id.toString());
    const httpOptions = {
      params: httpParams
    };

    return this.http.get<Response>(apiUrls.appointments, httpOptions);
  }

  update(appointment: Appointment) {
    return this.http.put<Response>(apiUrls.appointments, appointment);
  }

  create(appointment: Appointment) {
    return this.http.post<Response>(apiUrls.appointments, appointment);
  }
}
