import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { apiUrls } from 'src/app/shared/constants';

@Injectable({
  providedIn: 'root'
})
export class RelationshipTypeService {
  constructor(private http: HttpClient) {
  }

  list() {
    return this.http.get<Response>(apiUrls.relationshipTypes);
  }
}
