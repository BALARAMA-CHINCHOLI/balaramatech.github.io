import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { apiUrls } from 'src/app/shared/constants';
import { Template } from 'src/app/shared/models/template';
import { TemplateFilter } from 'src/app/shared/models/template-filter';
import { TemplateTest } from 'src/app/shared/models/template-test';
import { Thumb } from 'src/app/shared/models/thumb';

@Injectable({
  providedIn: 'root'
})
export class TemplateService {

  constructor(private http: HttpClient) { }

  selectedTemplate: Template;

  list(filter: TemplateFilter) {
    let httpParams = new HttpParams();
    if (filter.SearchText) {
      httpParams = httpParams.set('SearchText', filter.SearchText.toString());
    }
    if (filter.IsActive) {
      httpParams = httpParams.set('IsActive', filter.IsActive.toString());
    }
    if (filter.categoryId) {
      httpParams = httpParams.set('categoryId', filter.categoryId.toString());
    }
    if (filter.paging) {
      httpParams = httpParams.set('paging.pageNumber', filter.paging.pageNumber.toString());
      httpParams = httpParams.set('paging.pageSize', filter.paging.pageSize.toString());
    }
    if (filter.sorting) {
      httpParams = httpParams.set('sorting.sortBy', filter.sorting.sortBy.toString());
      httpParams = httpParams.set('sorting.order', filter.sorting.order.toString());
    }

    const httpOptions = {
      params: httpParams
    };

    return this.http.get<Response>(apiUrls.htmlTemplates, httpOptions);
  }

  getTemplate(id) {
    return this.http.get<Response>(apiUrls.htmlTemplates + '?id=' + id);
  }

  update(template: Template) {
    return this.http.put<Response>(apiUrls.htmlTemplates, template);
  }

  create(template: Template) {
    return this.http.post<Response>(apiUrls.htmlTemplates, template);
  }

  test(model: TemplateTest) {
    return this.http.post<Response>(apiUrls.htmlTemplateTest, model);
  }

  getKeyWords() {
    return this.http.get(apiUrls.keywords);
  }
  download(url) {
    return this.http.get(apiUrls.downloadFile + '?url=' + url,{responseType: 'blob'});
  }
  upload(model: Thumb) {
    return this.http.post<Response>(apiUrls.fileUploadBase64, model);
  }
}
