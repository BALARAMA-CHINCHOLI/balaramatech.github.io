import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { apiUrls } from 'src/app/shared/constants';
import { Person } from 'src/app/shared/models/person';
import { PersonFilter } from 'src/app/shared/models/person-filter';
import { Response } from 'src/app/shared/models/response';

@Injectable({
  providedIn: 'root'
})
export class CaregiversService {

  constructor(private http: HttpClient) { }

  list(filter: PersonFilter) {
    let httpParams = new HttpParams();
    if (filter.id) {
      httpParams = httpParams.set('id', filter.id.toString());
    }
    if (filter.term) {
      httpParams = httpParams.set('term', filter.term.toString());
    }
    if (filter.name) {
      httpParams = httpParams.set('name', filter.name.toString());
    }
    if (filter.cellPhone) {
      httpParams = httpParams.set('cellPhone', filter.cellPhone.toString());
    }
    if (filter.city) {
      httpParams = httpParams.set('city', filter.city.toString());
    }
    if (filter.email) {
      httpParams = httpParams.set('email', filter.email.toString());
    }
    if (filter.gender) {
      httpParams = httpParams.set('gender', filter.gender.toString());
    }
    if (filter.maximumAge) {
      httpParams = httpParams.set('maximumAge', filter.maximumAge.toString());
    }
    if (filter.minimumAge) {
      httpParams = httpParams.set('minimumAge', filter.minimumAge.toString());
    }
    if (filter.paging) {
      httpParams = httpParams.set('paging.pageNumber', filter.paging.pageNumber.toString());
      httpParams = httpParams.set('paging.pageSize', filter.paging.pageSize.toString());
    }
    if (filter.sorting) {
      httpParams = httpParams.set('sorting.SortBy', filter.sorting.sortBy.toString());
      httpParams = httpParams.set('sorting.order', filter.sorting.order.toString());
    }

    const httpOptions = {
      params: httpParams
    };

    return this.http.get<Response>(apiUrls.careGivers, httpOptions);
  }

  update(careGiver: Person) {
    return this.http.put<Response>(apiUrls.careGivers, careGiver);
  }

  create(careGiver: Person) {
    return this.http.post<Response>(apiUrls.careGivers, careGiver);
  }

  get(caregiverId: number) {
    return this.http.get<Response>(apiUrls.careGivers + '?id=' + caregiverId);
  }
}
