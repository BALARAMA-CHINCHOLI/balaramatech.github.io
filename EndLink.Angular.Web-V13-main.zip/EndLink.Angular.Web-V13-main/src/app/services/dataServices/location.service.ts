import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { apiUrls } from 'src/app/shared/constants';
import { Location } from 'src/app/shared/models/location';
import { SearchFilter } from 'src/app/shared/models/search-filter';

@Injectable({
  providedIn: 'root'
})
export class LocationService {

  selectedLocation: Location;

  constructor(private http: HttpClient) {
  }

  list(filter: SearchFilter) {
    let httpParams = new HttpParams();
    if (filter.SearchText) {
      httpParams = httpParams.set('SearchText', filter.SearchText.toString());
    }
    if (filter.paging) {
      httpParams = httpParams.set('paging.pageNumber', filter.paging.pageNumber.toString());
      httpParams = httpParams.set('paging.pageSize', filter.paging.pageSize.toString());
    }
    if (filter.sorting) {
      httpParams = httpParams.set('sorting.sortBy', filter.sorting.sortBy.toString());
      httpParams = httpParams.set('sorting.order', filter.sorting.order.toString());
    }

    const httpOptions = {
      params: httpParams
    };

    return this.http.get<Response>(apiUrls.locations, httpOptions);
  }

  getLocation(id) {
    let httpParams = new HttpParams().set('ID', id.toString());
    const httpOptions = {
      params: httpParams
    };
    return this.http.get<Response>(apiUrls.locations, httpOptions); 
  }

  update(location: Location) {
    return this.http.put<Response>(apiUrls.locations, location);
  }

  create(location: Location) {
    return this.http.post<Response>(apiUrls.locations, location);
  }

  getTimezones() {
    return this.http.get<Response>(apiUrls.timezones);
  }
}
