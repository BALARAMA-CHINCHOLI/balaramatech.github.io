import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { apiUrls } from "../shared/constants";
import { loginTheme } from "../shared/models/login-theme";
import { Response } from "../shared/models/response";

@Injectable({
  providedIn: "root"
})
export class LoginthemeService {
  constructor(private http: HttpClient) {
  }

  update(themeId: loginTheme) {
    return this.http.put<Response>(apiUrls.themes, themeId);
  }


}
