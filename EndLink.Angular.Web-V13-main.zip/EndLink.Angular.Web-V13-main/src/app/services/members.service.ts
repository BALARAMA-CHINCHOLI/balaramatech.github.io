import { ApiService } from './api.service';
import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class MembersService {

  selectedMembers = new BehaviorSubject([]);

  constructor(private apiService: ApiService) { }

}
