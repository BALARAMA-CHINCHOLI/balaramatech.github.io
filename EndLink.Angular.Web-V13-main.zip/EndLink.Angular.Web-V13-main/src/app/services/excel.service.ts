import * as FileSaver from 'file-saver';
import { Injectable } from '@angular/core';

const EXCEL_TYPE = "application/vnd.ms-excel;charset=utf-8";
const EXCEL_EXTENSION = ".xls";
declare var $: any;


@Injectable({
  providedIn: "root"
})
export class ExcelService {
  constructor() { }

  public exportAsExcelFile(id: any, excelFileName: string): void {

    let tab_text = '<html xmlns:x="urn:schemas-microsoft-com:office:excel">';
    tab_text = tab_text + '<head><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet>';
    tab_text = tab_text + '<x:Name>'+excelFileName+'</x:Name>';
    tab_text = tab_text + '<x:WorksheetOptions><x:Panes></x:Panes></x:WorksheetOptions></x:ExcelWorksheet>';
    tab_text = tab_text + '</x:ExcelWorksheets></x:ExcelWorkbook></xml></head><body>';
    tab_text = tab_text + "<table border='1px'>";
    var tbl = document.getElementById(id);
    let exportTable : any = $(tbl.outerHTML).clone();
    exportTable.find('input').each(function (index: any, elem: any) { $(elem).remove(); });
    tab_text = tab_text + exportTable.html();
    tab_text = tab_text + '</table></body></html>';
    this.saveAsExcelFile(tab_text, excelFileName);
  }

  private saveAsExcelFile(buffer: string, fileName: string): void {
    let data = new Blob([buffer], {
      type: EXCEL_TYPE
    });
    FileSaver.saveAs(data, fileName  + EXCEL_EXTENSION);
  }
}
