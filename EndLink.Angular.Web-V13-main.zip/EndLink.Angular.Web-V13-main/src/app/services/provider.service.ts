import { apiUrls } from './../shared/constants';
import { ProviderFilter } from './../shared/models/provider-filter';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Provider } from '../shared/models/provider';

@Injectable({
  providedIn: 'root'
})
export class ProviderService {

  selectedProvider: Provider;

  constructor(private http: HttpClient) {
  }

  list(filter: ProviderFilter) {
    let httpParams = new HttpParams();
    if (filter.id) {
      httpParams = httpParams.set('id', filter.id.toString());
    }
    if (filter.name) {
      httpParams = httpParams.set('SearchText', filter.name.toString());
    }
    if (filter.email) {
      httpParams = httpParams.set('email', filter.email.toString());
    }
    if (filter.paging) {
     httpParams = httpParams.set('paging.pageNumber', filter.paging.pageNumber.toString());
     httpParams = httpParams.set('paging.pageSize', filter.paging.pageSize.toString());
    }
    if (filter.sorting) {
     httpParams = httpParams.set('sorting.SortBy', filter.sorting.sortBy.toString());
     httpParams = httpParams.set('sorting.order', filter.sorting.order.toString());
    }

    const httpOptions = {
      params: httpParams
    };

    return this.http.get<Response>(apiUrls.provider, httpOptions);
  }

  update(provider: Provider) {
    return this.http.put<Response>(apiUrls.provider, provider);
  }

  create(provider: Provider) {
    return this.http.post<Response>(apiUrls.provider, provider);
  }

  get(id: number) {
    return this.http.get<Response>(apiUrls.provider + '?id=' + id);
  }
}
