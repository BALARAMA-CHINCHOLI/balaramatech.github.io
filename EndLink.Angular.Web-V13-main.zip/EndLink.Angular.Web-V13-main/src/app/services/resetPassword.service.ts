import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { apiUrls } from "../shared/constants";
import { resetPassword } from '../shared/models/resetPassword';
import { Response } from "../shared/models/response";

@Injectable({
  providedIn: "root"
})
export class ResetPasswordService {

  constructor(private http: HttpClient) {
  }

  resetPassword(password: resetPassword) {
    return this.http.post<Response>(apiUrls.resetPassword, password);
  }
}
