import { AuthenticationService } from './authentication.service';
import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, Resolve } from '@angular/router';
import { Observable, of } from 'rxjs';

import { map } from 'rxjs/operators';



@Injectable()
export class DashboarResolver implements Resolve<Observable<any>> {
  constructor(private authenticationService:AuthenticationService) {}
  // resolve(route: ActivatedRouteSnapshot): Observable<any> {
  //   const indId=+route.paramMap.get('id');
  //   if(indId==0)
  //   {
  //     return of({IsNew:true})
  //   }

  //   return this.userService.getDetils(indId).pipe(
  //     map(x=>{
  //     if(!x.IsSuccess)
  //     {
  //       return {IsError:true};
  //     }

  //     return x.Page;
  //   }));
  // }
  resolve(route: ActivatedRouteSnapshot): Observable<any> {
    return of(1)
  }
}