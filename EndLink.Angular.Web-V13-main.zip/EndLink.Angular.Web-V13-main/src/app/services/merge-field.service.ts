import { ApiService } from './api.service';
import { Injectable } from '@angular/core';
import { apiUrls } from 'src/app/shared/constants';
import { SearchFilter } from '../shared/models/search-filter';

@Injectable({
  providedIn: 'root'
})
export class MergeFieldService {

  constructor(private apiService: ApiService) { }

  list(filter: SearchFilter): any {
    return this.apiService.call('GET', apiUrls.mergeFields, null, filter);
  }
}
