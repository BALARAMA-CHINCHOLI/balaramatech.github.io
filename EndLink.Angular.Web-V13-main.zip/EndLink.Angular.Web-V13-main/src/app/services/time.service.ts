import { ApiService } from './api.service';
import { Injectable } from '@angular/core';
import { apiUrls } from 'src/app/shared/constants';

@Injectable({
  providedIn: 'root'
})
export class TimeService {

  constructor(private apiService: ApiService) { }

  list(): any {
    return this.apiService.call('GET', apiUrls.times);
  }
  listUnits(): any {
    return this.apiService.call('GET', apiUrls.units);
  }
}
