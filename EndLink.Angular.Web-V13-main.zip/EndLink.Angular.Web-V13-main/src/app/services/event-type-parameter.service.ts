import { Injectable } from "@angular/core";
import { apiUrls } from "../shared/constants";
import { Rule } from "../shared/models/rule";
import { RuleFilter } from "../shared/models/rule-filter";
import { ApiService } from "./api.service";

@Injectable({
  providedIn: "root"
})
export class EventTypeParameterService {

  constructor(private apiService: ApiService) {
  }

  list(eventTypeId: number) {
    return this.apiService.call('GET', apiUrls.eventTypeParameters + '?eventTypeId=' + eventTypeId);
  }
  downloadSample() {
    return this.apiService.call('GET', apiUrls.jsonTemplate);
  }
  
  checkDelete(paramId: number) {
    return this.apiService.call('PUT', apiUrls.eventTypeParameters + '?paramId=' + paramId);
  }

}
