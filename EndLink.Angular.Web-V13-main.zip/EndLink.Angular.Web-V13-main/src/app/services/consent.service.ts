import { Injectable } from '@angular/core';
import { BehaviorSubject, of } from 'rxjs';
import { map } from 'rxjs/operators';
import { apiUrls } from '../shared/constants';
import { ApiService } from './api.service';
import { AuthenticationService } from './authentication.service';

@Injectable()
export class ConsentService {
  private userDetails = new BehaviorSubject(null);
  public userDetails$ = this.userDetails.asObservable();
  constructor(private apiService: ApiService, private authService: AuthenticationService) {
   }

   getUserDetails(uuid: string) {
    this.apiService.call('GET', `${apiUrls.consentForm}?uuid=${uuid}`)
      .subscribe(user => {
        if(!!user?.responseObject) {
          this.userDetails.next(user?.responseObject)
        } else {
          this.authService.logout();
        }
      });
   }

   submitConsent(user) {
     return this.apiService.call('PUT', apiUrls.consentForm, user);
   }
}
