import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { apiUrls } from "../shared/constants";
import { Audio } from "../shared/models/audio";
import { Resource } from "../shared/models/resource";
import { Response } from "../shared/models/response";
import { SearchFilter } from "../shared/models/search-filter";

@Injectable({
  providedIn: "root"
})
export class ResourceService {
  selectedResrouce: Resource;

  constructor(private http: HttpClient) {
  }

  list(filter: SearchFilter) {
    let httpParams = new HttpParams();
    if (filter.SearchText) {
      httpParams = httpParams.set('SearchText', filter.SearchText.toString());
    }
    if (filter.paging) {
      httpParams = httpParams.set('paging.pageNumber', filter.paging.pageNumber.toString());
      httpParams = httpParams.set('paging.pageSize', filter.paging.pageSize.toString());
    }
    if (filter.sorting) {
      httpParams = httpParams.set('sorting.SortBy', filter.sorting.sortBy.toString());
      httpParams = httpParams.set('sorting.order', filter.sorting.order.toString());
    }

    const httpOptions = {
      params: httpParams
    };

    return this.http.get<Response>(apiUrls.resources, httpOptions);
  }

  getResrouce(id) {
    const httpOptions = {
      params: new HttpParams().set('ID', id.toString())
    };
    return this.http.get<Response>(apiUrls.resources, httpOptions);
  }

  create(item: Resource) {
    return this.http.post<Response>(apiUrls.resources, item);
  }

  update(item: Resource) {
    return this.http.put<Response>(apiUrls.resources, item);
  }
  getAudio() {
    const httpOption = {
      params: new HttpParams().set('getAll', "true")
    };
    return this.http.get<Audio>(apiUrls.audio,httpOption);
  }
}
