import { HttpClient, HttpParams } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { apiUrls } from "../shared/constants";
import { Response } from "../shared/models/response";
import { EventWorkflowType, WorkflowTypeFilter } from "../shared/models/event-workflowType";
import { SearchFilter } from "../shared/models/search-filter";

@Injectable({
  providedIn: "root"
})
export class EventWorkflowTypeService {
  selectedEventType : EventWorkflowType;
  constructor(private http: HttpClient) {
  }

  list(filter: SearchFilter, hideLoader = false) {
    let httpParams = new HttpParams();
    if (filter.SearchText) {
      httpParams = httpParams.set('SearchText', filter.SearchText.toString());
    }
    if (filter.getAll) {
      httpParams = httpParams.set('getAll', filter.getAll.toString());
    }
    if (filter.paging) {
     httpParams = httpParams.set('paging.pageNumber', filter.paging.pageNumber.toString());
     httpParams = httpParams.set('paging.pageSize', filter.paging.pageSize.toString());
    }
    if (filter.sorting) {
     httpParams = httpParams.set('sorting.SortBy', filter.sorting.sortBy.toString());
     httpParams = httpParams.set('sorting.order', filter.sorting.order.toString());
    }

    if(hideLoader) {
      httpParams = httpParams.set('hideGlobalLoader', 'true');
    }
    const httpOptions = {
      params: httpParams
    };

    return this.http.get<Response>(apiUrls.eventWorkflowType, httpOptions);
  }

  create(eventWorkflowType: EventWorkflowType) {
    return this.http.post<Response>(apiUrls.eventWorkflowType, eventWorkflowType);
  }
  get(id: number) {
    return this.http.get<Response>(apiUrls.eventWorkflowType + '?id=' + id);
  }
  update(eventWorkflowType: EventWorkflowType) {
    return this.http.put<Response>(apiUrls.eventWorkflowType, JSON.stringify(eventWorkflowType[0]));
  }
  delete(id: number) {
    return this.http.delete<Response>(apiUrls.eventWorkflowType + '?id=' + id);
  }

}
