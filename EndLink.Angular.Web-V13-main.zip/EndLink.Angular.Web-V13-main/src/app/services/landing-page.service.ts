import { BehaviorSubject } from 'rxjs';
import { ApiService } from './api.service';
import { Injectable } from '@angular/core';
import { apiUrls } from 'src/app/shared/constants';

@Injectable({
  providedIn: 'root'
})
export class LandingPageService {
  menus = new BehaviorSubject<any>(null);
  constructor(private apiService: ApiService) { }

  list(): any {
    return this.apiService.call('GET', apiUrls.landingPages);
  }
  menulist(): any {
    return this.apiService.call('GET', apiUrls.menus);
  }

  listDomain(): any {
    return this.apiService.call('GET', apiUrls.ladingPageDomain)
  }

}
