import { HttpClient } from "@angular/common/http";
import { Injectable } from "@angular/core";
import { apiUrls } from "../shared/constants";
import { Response } from "../shared/models/response";
import { UserDetail } from "../shared/models/user-details";

@Injectable({
  providedIn: "root"
})
export class UserProfileService {

  constructor(private http: HttpClient) {
  }

  get() {
    return this.http.get<Response>(apiUrls.userProfile);
  }

  update(user: UserDetail) {
    return this.http.put<Response>(apiUrls.userProfile, user);
  }
}
