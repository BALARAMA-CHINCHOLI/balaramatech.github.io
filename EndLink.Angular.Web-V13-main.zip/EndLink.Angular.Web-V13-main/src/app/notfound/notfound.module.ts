import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { SharedModule } from '../shared/shared.module';
import { UnauthorisedRoutingModule } from './notfound-routing.module';
import { NotfoundComponent } from './notfound/notfound.component';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    SharedModule,
    UnauthorisedRoutingModule
  ],
  declarations: [NotfoundComponent]
})
export class NotfoundModule { }
