import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { BreadcrumbService } from 'src/app/services/breadcrumb.service';

@Component({
  selector: 'app-notfound',
  templateUrl: './notfound.component.html',
  styleUrls: ['./notfound.component.scss']
})
export class NotfoundComponent implements OnInit {

  constructor(private router: Router,
    private breadcrumbService: BreadcrumbService) {

  }

  ngOnInit() {
    this.breadcrumbService.currentData.next('');
  }

  goToDashboard() {
    this.router.navigateByUrl('/dashboard');
  }
}
