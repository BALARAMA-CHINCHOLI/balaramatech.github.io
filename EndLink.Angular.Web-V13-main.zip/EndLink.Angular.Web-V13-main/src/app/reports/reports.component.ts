import { ChangeDetectorRef, Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import * as moment from 'moment';
import { CommonDataService } from '../services/common-data.service';
import { ScrollerService } from '../services/scroller-service.service';
import { WorkflowService } from '../services/workflow.service';
import { SortingType } from '../shared/enums/sorting-type';
import { ListModel } from '../shared/models/list-model';
import { Response } from '../shared/models/response';
import { SearchFilter } from '../shared/models/search-filter';
import { ReportViewComponent } from './report-view/report-view.component';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit, OnDestroy {
  showFilters: boolean = false;
  filter: SearchFilter = {
    SearchText: '',
    paging: {
      pageNumber: 1,
      pageSize: 10
    },
    sorting: {
      order: SortingType.Desc,
      sortBy: 'ScheduledDate'
    },
    date: {
      startDate: null,
      endDate: null
    },
    filter: {
      Value: '',
      FilterBy: 'status'
    }
  };

  today: Date = new Date();

  statusList = [];

  private header_data: any[] = [
    { title: "Channel", type: "text", prop: 'channel', sort: true, sortProp: 'action', isFilter: true, isAsc: false, isDes: false },
    { title: "Member ID", type: "text", prop: 'patientId', sort: true, sortProp: 'patientId', isFilter: true, isAsc: false, isDes: false },
    { title: "First Name", type: "text", prop: 'firstName', sort: true, sortProp: 'firstname', isFilter: true, isAsc: false, isDes: false },
    { title: "Last Name", type: "text", prop: 'lastName', sort: true, sortProp: 'lastname', isFilter: true, isAsc: false, isDes: false },
    { title: "Event Date", type: "text", prop: 'eventDate', sort: true, sortProp: 'scheduledDate', isFilter: true, isAsc: false, isDes: false },
    { title: "Event Time", type: "text", prop: 'eventTime', sort: false, isFilter: true, isAsc: false, isDes: false },
    { title: "Status", type: "status", prop: 'status', sort: false, sortProp: 'status', isFilter: true, isAsc: false, isDes: false },
    { title: "Id", type: "id", prop: 'id', sort: false, sortProp: 'status', isFilter: true, isAsc: false, isDes: false, hidden: true },
  ];

  tableData: any = {
    headerData: [],
    rowData: [],
    noRecordFound: true
  };
  scroller$: any;

  list: ListModel<any> = {
    list: [],
    hasNextPage: false
  };

  constructor(private workflowService: WorkflowService,
    private scroller: ScrollerService,
    private cdr: ChangeDetectorRef,
    private dialog: MatDialog,
    private commonDataService: CommonDataService) {

  }

  ngOnInit() {
    this.tableData.headerData = this.header_data;
    this.tableData.noRecordFound = false;

    this.loadReports();
    this.getStatus();
    this.scroller$ = this.scroller.scroller$.pipe().subscribe((res) => {
      if (this.list.hasNextPage) {
        this.filter.paging.pageNumber++;
        this.loadReports();
      }
    });
  }

  getStatus(){
    this.commonDataService.get('workflow').subscribe((data: any) => {
      const resp = JSON.parse(data.responseObject);
      if(resp && resp.length > 0 && resp[0].S){
        this.statusList = resp[0].S;
      }
    });
  }

  showfilter() {
    this.showFilters = !this.showFilters;
    setTimeout(() => {
      this.cdr.detectChanges();
    });
  }

  fromDateChange(){
    this.filter.date.endDate = null;
  }

  search() {
    this.filter.paging.pageNumber = 1;
    this.list = {
      list: [],
      hasNextPage: false
    };
    this.loadReports();
  }

  clear() {
    this.filter = {
      SearchText: '',
      paging: {
        pageNumber: 1,
        pageSize: 10
      },
      sorting: {
        order: SortingType.Desc,
        sortBy: 'scheduleDate'
      },
      date: {
        startDate: null,
        endDate: null
      },
      filter: {
        Value: '',
        FilterBy: 'status'
      }
    };
    this.list = {
      list: [],
      hasNextPage: false
    };

  }


  tableActions(event): void {
    switch (event.action) {
      case 'view': {
        const data = this.list.list.find(x => x.Id == event.rowData.id);
        if (data) {
          this.dialog.open(ReportViewComponent, { data: data, width: '85vw', height: '80vh' });
        }
        break;
      }
      case 'search': {
        this.filter.SearchText = event.filterData.globalSearch;
        this.filter.paging.pageNumber = 1;
        this.loadReports();
        break;
      }
      case 'clear': {
        this.filter.SearchText = '';
        this.loadReports();
        break;
      }
      case 'sort': {
        this.filter.sorting.sortBy = event.filterData.sortHeader;
        this.filter.sorting.order = event.filterData.sortOrder;
        this.loadReports();
        break;
      }
    }
  }


  private loadReports() {
    this.workflowService.getWorkflowReports(this.filter).subscribe((data: Response) => {
      const records = data.responseObject && data.responseObject != '' ? JSON.parse(data.responseObject) : [];

      if (this.filter.paging.pageNumber == 1) {
        this.list.list = records;
        this.tableData.rowData = [];
      } else {
        records.forEach((item) => {
          this.list.list.push(item);
        });
      }

      const tableData = [];
      this.list.list.forEach((item) => {
        tableData.push({
          channel: item.Channel,
          memberId: item.personId,
          firstName: item.firstName,
          lastName: item.lastName,
          eventDate: moment(item.scheduledDate).format('MM/DD/YYYY'),
          eventTime: moment(item.scheduledDate).format('HH:mm:ss'),
          resource: item.response,
          status: item.status,
          location: '',
          id: item.Id,
          patientId: item.patientId
        });
      });

      this.tableData.rowData = tableData;
      this.tableData.noRecordFound = this.list.list.length < 1;
      this.list.hasNextPage = records && records.length > 0;
    });
  }

  public ngOnDestroy(): void {
    this.scroller$.unsubscribe();
  }
}
