import { LandingPageService } from './../../services/landing-page.service';
import { Injectable } from '@angular/core';
import {
  ActivatedRouteSnapshot,
  CanActivate,
  CanActivateChild,
  Router,
  RouterStateSnapshot,
} from '@angular/router';
import { CampaignService } from 'src/app/services/campaign.service';
import * as mom from 'moment';
import { paths } from '../constants';

const moment = mom;

@Injectable()
export class AddCampaignGuard implements CanActivate, CanActivateChild {
  constructor(
    private router: Router,
    private campaignService: CampaignService
  ) {}

  canActivate(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.validate(state);
  }

  canActivateChild(route: ActivatedRouteSnapshot, state: RouterStateSnapshot) {
    return this.validate(state);
  }

  private validate(state: RouterStateSnapshot): boolean {
    if (
      state.url.includes('configure') ||
      state.url.includes('recipients') ||
      state.url.includes('schedule')
    ) {
      if (
        this.campaignService.configureCampaign.value?.statusId == 5 &&
        !!this.campaignService.configureCampaign.value?.scheduleFromDate
      ) {
        let startDate = moment(
          this.campaignService.configureCampaign.value?.scheduleFromDate
        );
        let today = moment(new Date());
        if (startDate.isBefore(today, 'day')) {
          this.router.navigate([
            paths.campaignEdit +
              this.campaignService.campaignId.value +
              '/actions',
          ]);
          return false;
        }
      }
      return true;
    } else if (state.url.includes('preview')) {
      let isConfigured = !!this.campaignService.configureCampaign.value;
      let isActionsAdded =
        this.campaignService.campaignActions.value.length > 0;
      let isScheduled = this.campaignService.campaignSchedule.value.length > 0;
      return (
        isConfigured &&
        this.campaignService.hasRecipients &&
        isActionsAdded &&
        isScheduled
      );
    }
    return true;
  }
}
