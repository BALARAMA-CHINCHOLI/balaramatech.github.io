import { Component, Input, OnInit } from '@angular/core';
import { ChartOptions, ChartType, ChartDataSets } from 'chart.js';
import { Color, Label } from 'ng2-charts';
import { Chart } from '../../models/chart';

@Component({
  selector: 'app-charts',
  templateUrl: './charts.component.html',
  styleUrls: ['./charts.component.scss'],
})
export class ChartsComponent implements OnInit {

  @Input() data = [];
  @Input() chartColors: Color[] = [];
  @Input() chart: Chart = {
    chartOptions: {
      responsive: true,
    },
    labels: [
      '18-Aug-2021',
      '2007',
      '2006',
      '2007',
      '2012',
    ],
    type: 'bar',
    showLegend: true,
    chartPlugins: [],
    data: [
      {
        data: [
          65, 59, 45, 64, 80, 81, 56, 55, 40, 65, 59, 80, 81, 56, 55, 40, 65,
          59, 80, 81, 56, 55, 40, 65, 59, 80, 81, 56, 55, 40,
        ],
        label: 'Series A',
        stack: 'a',
      },
      {
        data: [
          65, 59, 67, 67, 80, 81, 56, 55, 40, 65, 59, 80, 81, 56, 55, 40, 65,
          59, 80, 81, 56, 55, 40, 65, 59, 80, 81, 56, 55, 40,
        ],
        label: 'Series B',
        stack: 'a',
      },
      {
        data: [
          65, 59, 67, 98, 80, 81, 56, 55, 40, 65, 59, 80, 81, 56, 55, 40, 65,
          59, 80, 81, 56, 55, 40, 65, 59, 80, 81, 56, 55, 40,
        ],
        label: 'Series C',
        stack: 'a',
      },
    ],
  };

  constructor() {}

  ngOnInit(): void {}
}
