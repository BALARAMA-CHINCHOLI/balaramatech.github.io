import { Component, OnInit, Output, EventEmitter } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { AddEmailDialogComponent } from '../add-email-dialog/add-email-dialog.component';
import { AddSMSDialogComponent } from '../add-smsdialog/add-smsdialog.component';
import { AddVoiceDialogComponent } from '../add-voice-dialog/add-voice-dialog.component';
import { CommunicationChannelService } from 'src/app/services/communication-channel.service';
import { CommunicationChannel } from 'src/app/shared/models/communication-channel';
import { CommunicationChannelType } from '../../enums/communication-channel-type';

@Component({
  selector: 'app-configure-action',
  templateUrl: './configure-action.component.html',
  styleUrls: ['./configure-action.component.scss']
})
export class ConfigureActionComponent implements OnInit {
  actionsData = {
    dataSource: new MatTableDataSource(),
    headerData: [
      {def: 'name', prop: 'name', title: 'Name', type: 'text'},
      {def: 'language', prop: 'language', title: 'Language', type: 'text'},
      {def: 'message', prop: 'msg', title: 'Message', type: 'text'},
      {def: 'action', prop: 'action', title: 'Action', type: 'action'}
    ]
  };

  @Output() data = new EventEmitter();

  communications: CommunicationChannel[] = [];

  constructor(private dialog: MatDialog, private commChannelService: CommunicationChannelService) { }

  ngOnInit(): void {
    this.getCommunicationChannels();
  }

  private getCommunicationChannels(): void {
    this.commChannelService.list().subscribe((data) => {
      if (data.responseObject) {
        this.communications = data.responseObject;
      }
    });
  }

  openDailog(item: any): void {
    if (item.id === CommunicationChannelType.SMS) {
      this.openSms();
    }
    else if (item.id === CommunicationChannelType.Email) {
      this.openEmail();
    }
    else if (item.id === CommunicationChannelType.Voice) {
      this.openVoice();
    }
  }

  private openSms(): void {
    const smsDialog = this.dialog.open(AddSMSDialogComponent, {width: '80vw', height: '90vh'});

    smsDialog.afterClosed().subscribe(result => {
      if (result) {
        const obj = {
          commid: result.id,
          name: result.name,
          languageid: result.languageId,
          language: result.languageName,
          msg: result.messageContent,
          action: [result.action]
        };
        this.actionsData.dataSource = new MatTableDataSource([...this.actionsData.dataSource.data, obj]);
        this.triggerOutput(this.actionsData.dataSource.data);
      }
    });
  }

  private openVoice(): void {
    const voiceDialog = this.dialog.open(AddVoiceDialogComponent,{width: '80vw', height: '90vh'});

    voiceDialog.afterClosed().subscribe(result => {
      if (result) {
        const obj = {
          commid: result.id,
          name: result.name,
          languageid: result.languageId,
          language: result.languageName,
          msg: result.messageContent,
          action: [result.action]
        };
        this.actionsData.dataSource = new MatTableDataSource([...this.actionsData.dataSource.data, obj]);
        this.triggerOutput(this.actionsData.dataSource.data);
      }
    });
  }

  private openEmail(): void {
    let emailDialog = this.dialog.open(AddEmailDialogComponent,{width: '80vw', height: '90vh'});
    emailDialog.afterClosed().subscribe(result => {
      let action = [
        {
          commid: {type: 'text', value : '2'},
          name: {type: 'text', value : 'Abhigali'},
          languageid: {type: 'text', value : '1'},
          language: {type: 'text', value: 'abhi@gmail.com'},
          msg: {type: 'text', value: '9080908090'},
          action: {type: 'action', value: ['delete']}
        }
      ];
      this.actionsData.dataSource = new MatTableDataSource(action);
      this.triggerOutput(this.actionsData.dataSource.data);
    });
  }

  deleteRecord(event): void {
    const removeItem = [event.value];
    this.actionsData.dataSource.data = this.actionsData.dataSource.data.filter(item => !removeItem.includes(item));
    this.actionsData.dataSource = new MatTableDataSource([...this.actionsData.dataSource.data]);
    this.triggerOutput(this.actionsData.dataSource.data);
  }

  triggerOutput(data): void {
    this.data.emit(data);
  }
}
