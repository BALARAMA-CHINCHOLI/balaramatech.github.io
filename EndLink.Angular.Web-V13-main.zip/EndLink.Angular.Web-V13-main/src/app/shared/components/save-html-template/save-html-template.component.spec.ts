import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaveHTMLTemplateComponent } from './save-html-template.component';

describe('SaveHtmlTemplateComponent', () => {
  let component: SaveHTMLTemplateComponent;
  let fixture: ComponentFixture<SaveHTMLTemplateComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SaveHTMLTemplateComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SaveHTMLTemplateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
