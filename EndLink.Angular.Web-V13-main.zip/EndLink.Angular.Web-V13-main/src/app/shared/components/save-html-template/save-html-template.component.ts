import { ChangeDetectorRef, Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import Bee from '@mailupinc/bee-plugin';
import { CategoryService } from 'src/app/services/category.service';
import { TemplateService } from 'src/app/services/dataServices/template.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { messages } from 'src/app/shared/constants';
import { Category } from 'src/app/shared/models/category';
import { Keyword } from 'src/app/shared/models/keyword';
import { Template } from 'src/app/shared/models/template';
import { TemplateTest } from 'src/app/shared/models/template-test';
import html2canvas from 'html2canvas';
import { Thumb } from 'src/app/shared/models/thumb';

@Component({
  selector: 'app-save-html-template',
  templateUrl: './save-html-template.component.html',
  styleUrls: ['./save-html-template.component.scss']
})
export class SaveHTMLTemplateComponent implements OnInit {


  @Input()
  isUpdate: boolean = false;
  @Input()
  isCopy: boolean = false;
  @Input()
  showCancelButton: boolean = true;
  @Input()
  id: number = 0;

  @Output() templateSaved: EventEmitter<void> = new EventEmitter();
  @Output() cancelled: EventEmitter<void> = new EventEmitter();

  template: Template = new Template();
  testModel: TemplateTest = new TemplateTest();
  thumb: Thumb = new Thumb();
  categories: Category[] = [];
  keywords: Keyword[] = [];

  selectedCategories = [];
  selectedKeywords = [];

  categInput = new FormControl();
  keywordInput = new FormControl();

  filteredCategories;
  filteredKeywords;

  beeTest = new Bee();
  submitted = false;

  showEmailRequired: boolean = false;
  data: boolean;
  showBeeEditor: boolean = false;
  beeEditorLoaded: boolean = false;
  capturedImage: any;
  imageChangedEvent: any = '';
  croppedImage: any = '';
  showCropper :boolean =false;
  thumbDiv:boolean =true;
  constructor(private templateService: TemplateService
    , private toaster: ToasterService
    , private categoryService: CategoryService
    , private cdr: ChangeDetectorRef) { }

  ngOnInit(): void {

    if (this.id > 0) {
      this.getTemplate(this.id);
    }

    this.populateDropdowns();
  }

  private populateDropdowns() {
    this.getCategories();
    this.getKeywords();

    this.categInput.valueChanges.subscribe((text) => {
      this.filterMultiList(text, 'categories', 'selectedCategories', 'filteredCategories');
    });
    this.keywordInput.valueChanges.subscribe((text) => {
      this.filterMultiList(text, 'keywords', 'selectedKeywords', 'filteredKeywords');
    });
  }

  private filterMultiList(text, source, selected, output) {
    this[output] = [];
    if (!text) {
      text = '';
    }

    this[source].filter(x => x.name.toLowerCase().indexOf(text) === 0).forEach((item) => {
      if (this[selected].find(x => x.id == item.id) == null) {
        this[output].push(item);
      }
    });
  }

  getCategories() {
    this.categoryService.categories.subscribe(res => {
      this.categories = res;
      this.filterMultiList(null, 'categories', 'selectedCategories', 'filteredCategories');
    });
  }

  getKeywords() {
    this.templateService.getKeyWords().subscribe((res: any) => {
      this.keywords = res.responseObject;
      this.filterMultiList(null, 'keywords', 'selectedKeywords', 'filteredKeywords');
    });
  }

  toggleBeeEditor(isValid: boolean) {
    this.submitted = true;
    if (!isValid) {
      return;
    }

    this.showBeeEditor = !this.showBeeEditor;
  }

  getTemplate(id: number) {
    this.templateService.getTemplate(id).subscribe((res: any) => {
      this.template = res.responseObject;

      this.template.categories.forEach(item => {
        this.selectedCategories.push({ id: item.category.id, name: item.category.name })
      });

      this.template.keywords.forEach(item => {
        this.selectedKeywords.push({ id: item.keyword.id, name: item.keyword.name })
      });
    });
  }

  closebeeEditor() {
    this.showBeeEditor = false;
  }
   get_url_extension( url ) {
    return url.split(/[#?]/)[0].split('.').pop().trim();
  }
   saveTemplate(data: any) {
    this.croppedImage=null;   
    this.thumbDiv=true;
     $("#tempHtml").html(data.templateHtml);
     this.showBeeEditor = false;
     this.DownloadImg()
     this.thumbDiv=true;
     this.template.templateJson = data.templateJson;
     this.template.templateHtml = data.templateHtml;
     setTimeout(() => {
      this.cdr.detectChanges();
     }, 100);
    //  setTimeout(() => {
    //   this.cdr.detectChanges();
    //   this.submit(true, true);
    //  });
  }
  DownloadImg(){
    let that =this;
    var bar = new Promise((resolve:any, reject) => {
      $("#tempHtml img").each(function(i,v){
        let src =$(v).attr('src');
        let base64="";
        if(src.startsWith('http')){
          that.templateService.download(src).subscribe((res: any) => {
            let ext =that.get_url_extension(src)
            var urlCreator = window.URL || window.webkitURL;
            var imageUrl = urlCreator.createObjectURL(res);
            $(v).attr('src',imageUrl);
            if($("#tempHtml img").length-1==i)
               resolve();
           // $(v).attr('src','data:image/'+ext+';base64, '+res);
          });
        }
      });
      if($("#tempHtml img").length==0)
        resolve();
    });
    bar.then(() => {
      this.Thumbnail();  
     });
  }

  Thumbnail() {
   setTimeout(() => {
     html2canvas(document.querySelector("#tempHtml"),{ allowTaint: false,useCORS:true}).then((canvas:HTMLCanvasElement) => {
      this.thumbDiv=false;
       var image = new Image();
       image.src = canvas.toDataURL();
       // this.croppedImage = canvas.toDataURL('image/png', 1);
       // this.showCropper =true;
       let that =this;
       image.onload = function () {
         that.croppedImage = that.thumbnail2(image);
         that.thumb.base64 = that.croppedImage;
         that.thumb.fileName = that.template.name.replace(" ","_")+"_"+that.template.id + "_thumb.png";
         that.templateService.upload(that.thumb).subscribe((res:any)=>{
           that.template.thumbnailUrl = res.responseObject;
         })
       };
    });
   }); 
  
  }
  thumbnail1(image) {
    var canvas = this.createCanvas(48 , 48);
    canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
    return canvas.toDataURL();
  }
   thumbnail2(image) {
    var size = {
      width: 40 * (image.width / image.height),
      height: 50,
    }
  
    var c1 = this.createCanvas(size.width*4 , size.height*4 );
    c1.getContext('2d').drawImage(image, 0, 0, c1.width, c1.height);
    var c2 = this.createCanvas(size.width * 2, size.height*2 );
    c2.getContext('2d').drawImage(c1, 0, 0, c2.width, c2.height);
  
    var r = this.createCanvas(size.width, size.height);
    r.getContext('2d').drawImage(c2, 0, 0, r.width, r.height);
  
    return r.toDataURL( 'png', 0.8);
  }
  createCanvas(width, height):any {
    return $('<canvas>').attr({
      width: width || 48,
      height: height || 48,
    }).get(0);
  }
  editTemplate() {
    this.showBeeEditor = true;
  }

  deleteTemplate() {
    this.template.templateHtml = '';
    this.template.templateJson = '';
    this.template.thumbnailUrl = '';

    setTimeout(() => {
      this.cdr.detectChanges();
    });
  }

  cancel() {
    this.cancelled.emit();
  }

  submit(isValid, skipBeeCheck: boolean = false) {
    if (this.showBeeEditor == true && !skipBeeCheck) {
      return;
    }

    this.submitted = true;
    if (!isValid) {
      return;
    }
    if(this.croppedImage?.length ==0){
      this.toaster.showErrorMessage('Thumbnail creation is in progress. Please wait...');
      return;
    }
    if (!this.template.templateJson || this.template.templateJson == '') {
      this.toaster.showErrorMessage('Please add template');
      return;
    }
    
    this.showBeeEditor = false;
    this.template.categories = this.selectedCategories.map(category => { return { category: { id: category.id } } });
    this.template.keywords = this.selectedKeywords.map(keyword => { return { keyword: { id: keyword.id } } });

    if (this.id > 0) {
      this.templateService.update(this.template).subscribe((res: any) => {
        if (!res.isError) {
          this.toaster.showSuccessMessage(messages.templateUpdateSuccess);
        } else {
          this.toaster.showErrorMessage(res.message);
        }
        this.templateSaved.emit();

        setTimeout(() => {
          this.cdr.detectChanges();
        }, 100);
      });
    } else {
      this.templateService.create(this.template).subscribe((res: any) => {
        if (!res.isError) {
          this.toaster.showSuccessMessage(messages.templateCreateSuccess);
        } else {
          this.toaster.showErrorMessage(res.message);
        }
        this.templateSaved.emit();

        setTimeout(() => {
          this.cdr.detectChanges();
        }, 100);
      });
    }
  }

  previewTemplate() {
    this.beeTest.preview();
  }

  removeChip(comMethod, fromSource, input) {
    const index = this[fromSource].indexOf(comMethod);
    if (index >= 0) {
      this[fromSource].splice(index, 1);
      this[input].setValue('');
    }
  }

  selectAutoComplete(event: MatAutocompleteSelectedEvent, source, selection, input, target): void {
    const item = this[source].find(x => x.id == event.option.value);

    if (!item) {
      return;
    }
    event.option.deselect();
    this[selection].push(item);
    target.value = '';
    this[input].setValue('', { emitEvent: true });
    target.blur();
  }

  filterfn(from, selectedValues, input) {
    return this[from].filter(value => (value.name.toLowerCase().indexOf(input) === 0 && !this[selectedValues].includes(value.name)));
  }
  space(event) {
    this.template.name = this.template?.name?.replace(/^\s+|\s+$/g, '');
    this.template.description = this.template?.description?.replace(/^\s+|\s+$/g, '');
    if (this.template?.name?.length == null) {
      this.data = false;
    }
  }

  sendTestEmail() {
    if (!this.testModel.email || this.testModel.email == '') {
      this.showEmailRequired = true;
      return;
    }
    this.showEmailRequired = false;

    this.beeTest.send();
  }
  

}
