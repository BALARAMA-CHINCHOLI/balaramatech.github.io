import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-list-card',
  templateUrl: './list-card.component.html',
  styleUrls: ['./list-card.component.scss']
})
export class ListCardComponent implements OnInit {
  @Input() source;
  @Output() action = new EventEmitter();
  constructor(private router: Router) { }

  ngOnInit(): void {
    
  }

  isColumnAvailable(columnName) {
   return !!this.source?.headerData?.find(data => data.prop == columnName);
  }

  navigateTo(action, item) {
    this.action.emit({action: action, item :item});
  }

  commonAction(actionName, item) {
    if(actionName == 'switch') {
      item.isActive = !item.isActive;
    }
    this.action.emit({ action: actionName, item: item })
  }

}
