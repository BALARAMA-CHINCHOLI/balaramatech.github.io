import { Component, Input, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { TimelineViewComponent } from './timeline-view/timeline-view.component';

@Component({
  selector: 'app-timeline',
  templateUrl: './timeline.component.html',
  styleUrls: ['./timeline.component.scss']
})
export class TimelineComponent implements OnInit {
  timeline: boolean;
  listview: boolean;

  @Input() response: any;
  constructor(private dialog: MatDialog) { }

  ngOnInit(): void {
    this.timeline = false;
    this.listview = true;
    // document.getElementById("list").style.border = "2px solid var(--primary)";
  }

  listviewfun() {
    this.timeline = false;
    this.listview = true;
    // document.getElementById("list").style.border = "2px solid var(--primary)";
    // document.getElementById("timeline").style.border = "none";

  }

  timelinefun() {
    this.timeline = true;
    this.listview = false;
    // document.getElementById("timeline").style.border = "2px solid var(--primary)";
    // document.getElementById("list").style.border = "none";
  }

  view(item) {
    this.dialog.open(TimelineViewComponent, { data: item, width: '85vw', height: '80vh' });
  }

}
