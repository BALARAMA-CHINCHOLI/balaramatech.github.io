import { Component, OnInit, Output, EventEmitter, Input } from '@angular/core';
import { PersonService } from 'src/app/services/person.service';
import { ScrollerService } from 'src/app/services/scroller-service.service';
import { WorkflowService } from 'src/app/services/workflow.service';
import { SortingType } from 'src/app/shared/enums/sorting-type';
import { ListModel } from '../../models/list-model';
import { Person } from '../../models/person';
import { veiwfilter } from '../../models/search-filter';
declare var $: any;

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.scss']
})
export class ProfileComponent implements OnInit {
  tableData: any = {
    headerData: [],
    rowData: [],
    noRecordFound: true
  }
  list: ListModel<any> = {
    list: [],
    hasNextPage: false
  };
  filter: veiwfilter = {
    id : 0,
    category : 1,
    term:"workflow",
    paging: {
      pageNumber: 1,
      pageSize: 10
    },
    sorting: {
      order: SortingType.Desc,
      sortBy: 'Name'
    }
  };
  scrollerSubscribe$: any;
  list$: any;

  @Input() id: number = 0;
  @Output() edit = new EventEmitter();
  @Input() flag :string ='';

  public personDetails: Person = null;


  constructor(private personService: PersonService,
    private scroller: ScrollerService,
    private editpatientservice: WorkflowService) { }

  ngOnInit(): void {

    if (this.id && this.id > 0) {
      this.getPerson();
    }

    this.tableData.headerData = header_data;
    this.tableData.noRecordFound = false;
    this.filter.id = this.id;
    this.getHistory();
    this.scrollerSubscribe$ = this.scroller.scroller$.pipe().subscribe((res) => {
      if (this.list.hasNextPage) {
        this.filter.paging.pageNumber++;
        this.getList();
      }
    });

  }
nameNullCheck(firstName,middleName,lastName){
  var data:any ='';
  if(middleName !== null){
    data =firstName + " " + middleName + " " + lastName;
  }
  else{
    data =firstName +  " " + lastName;
  }
  return data
}

  getPerson() {
    this.personService.get(this.id).subscribe((data) => {
      if (data.responseObject) {
        this.personDetails = data.responseObject;
      }
    });
  }
  
  getList() {
    this.list$ = this.editpatientservice.viewpatient(this.filter)
      .subscribe((data: any) => {
        if (this.filter.paging.pageNumber == 1) {
          this.list.list = data.responseObject || [];
          this.tableData.rowData = [];
        } else {
          data.responseObject.forEach((item) => {
            this.list.list.push(item);
          });
        }

        this.tableData.rowData = this.list.list;

        if (this.list.list.length == 0) {
          this.tableData.noRecordFound = true;
        }else{
          this.tableData.noRecordFound = false;
        }

        this.list.hasNextPage = data.responseObject && data.responseObject.length > 0;
      });
  }

  getHistory() {
    this.filter.term = 'workflow';
    this.list$ = this.editpatientservice.viewpatient(this.filter)
      .subscribe((data: any) => {
        if (this.filter.paging.pageNumber == 1) {
          this.list.list = data.responseObject || [];
          this.tableData.rowData = [];
        } else {
          data.responseObject.forEach((item) => {
            this.list.list.push(item);
          });
        }

        this.tableData.rowData = this.list.list;
        this.filter.term = 'campaign';
        this.list$ = this.editpatientservice.viewpatient(this.filter)
          .subscribe((data: any) => {
            if (this.filter.paging.pageNumber == 1) {
              this.list.list = data.responseObject || [];
              this.tableData.rowData = [];
            } else {
              data.responseObject.forEach((item) => {
                this.list.list.push(item);
              });
            }
    
            this.tableData.rowData = this.list.list;
    
            if (this.list.list.length == 0) {
              this.tableData.noRecordFound = true;
            }else{
              this.tableData.noRecordFound = false;
            }
    
            this.list.hasNextPage = data.responseObject && data.responseObject.length > 0;
          });
      });
      
  }

  onTabChanged(event){
    this.tableData.rowData = [];
    this.list.list =[];
    this.filter.paging.pageNumber = 1;
    this.filter.term = event.index == 0 ?'history': event.index == 1 ? 'group' : event.index == 2 ? 'workflow'  : event.index == 3 ? 'campaign' : event.index == 4 ? 'external':"";
    if(event.index == 0){
      this.getHistory();
    }else{
      this.getList();
    }
  }
  
  getAlias() {
    if (!this.personDetails) {
      return '';
    }

    return this.personDetails.firstName.substring(0, 1);
  }

  getChannelIcon(channel) {
    switch (channel) {
      case 'SMS':
        return '../../../../assets/images/sms.png';
        break;
      case 'Voice':
        return '../../../../assets/images/voice.png';
        break;
      case 'MMS':
        return '../../../../assets/images/mms.png';
        break;
        case 'Email':
          return '../../../../assets/images/email.png';
          break;
      default:
        return '../../../../assets/images/sms.png';
        break;
    }
  }

  editMember() {
    this.edit.emit();
  }
  
  ngOnDestroy() {
    this.scrollerSubscribe$.unsubscribe();
  }

}


export const header_data: any[] = [
  { title: "Name", type: "text", prop: 'Name' },
  { title: "Language", type: "text", prop: 'language' },
  { title: "Message", type: "text", prop: 'message' },
  { title: "Date & Time", type: "text", prop: 'date' },
  { title: "Type", type: "text", prop: 'type' }
]


