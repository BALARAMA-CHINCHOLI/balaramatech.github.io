import {
  Component,
  EventEmitter,
  Input,
  OnInit,
  Output,
  OnChanges,
  OnDestroy,
  ViewChild,
  AfterViewInit,
} from '@angular/core';
import { PaginationInstance } from 'ngx-pagination/dist/ngx-pagination.module';
import { FormControl } from '@angular/forms';
import { MatTableDataSource } from '@angular/material/table';
import { PageService } from 'src/app/services/page.service';
import { SortingType } from '../../enums/sorting-type';
import { Sorting } from '../../models/sorting';
import { fromEvent, of } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { CampaignStatusType } from '../../enums/campaign-status-type';

@Component({
  selector: 'app-table',
  templateUrl: './table.component.html',
  styleUrls: ['./table.component.scss'],
})
export class TableComponent
  implements OnInit, OnChanges, OnDestroy, AfterViewInit {
  toppings = new FormControl();
  toppingList = [];
  pageCount: number;
  filterData: any = {
    globalSearch: '',
    sortHeader: '',
    sorOrder: '',
    filter: [],
  };
  @Output() pageActions = new EventEmitter<{
    action: string;
    filterData: any;
    rowData: any;
  }>();
  @Input() pageData: any;
  @Input() tableData: any;
  @Input() IsEdit: boolean;
  @Input() IsDelete: boolean;
  @Input() IsView: boolean;
  @Input() IsDownload: boolean;
  @Input() IsAbort: boolean;
  @Input() IsCopy: boolean;
  @Input() hideAction: boolean;
  @Input() hideFilter: boolean;
  @Input() title: string;
  @Input() IsApprove: boolean;
  @Input() IsReject: boolean;
  @Input() titleActions: any[];
  @Input() IsSelect: boolean;

  @ViewChild('search') search;

  dataSource = new MatTableDataSource();

  searchSubscription$;
  serviceSearch: string;
  isMoreOpen = false;
  propertyValues: [];
  constructor(public page: PageService) { }

  ngOnInit() {
    if (!this.hideFilter) {
      this.toppingList = this.tableData.headerData.filter((x) => x.isFilter);
    }
  }

  openMore() {
    this.isMoreOpen = !this.isMoreOpen;
  }

  ngAfterViewInit() {
    // this.searchSubscription$ = fromEvent(this.search.nativeElement, 'input')
    //   .pipe(debounceTime(700))
    //   .subscribe((res) => {
    //     this.loadFilterData();
    //     this.pageActions.emit({
    //       action: 'search',
    //       filterData: this.filterData,
    //       rowData: null,
    //     });
    //   });
  }

  ngOnChanges(change) { }

  loadFilterData() {
    this.filterData.globalSearch = this.serviceSearch;
    this.filterData.filter = this.toppings.value;
  }

  commonAction(actionName, item) {
    this.pageActions.emit({
      action: actionName,
      filterData: this.filterData,
      rowData: item,
    });
  }
  clearFilter() {
    this.serviceSearch = '';
    this.filterData.globalSearch = this.serviceSearch;
    this.filterData.filter = [];
    this.pageActions.emit({
      action: 'clear',
      filterData: this.filterData,
      rowData: null,
    });
  }
  sortColumn(item) {
    if (!item.isAsc && !item.isDes) {
      item.isAsc = true;
    } else {
      item.isAsc = !item.isAsc;
      item.isDes = !item.isDes;
    }
    this.filterData.sortHeader = item.sortProp ?? item.title;
    this.filterData.sortOrder = item.isAsc ? SortingType.Asc : SortingType.Desc;
    this.pageActions.emit({
      action: 'sort',
      filterData: this.filterData,
      rowData: null,
    });
  }

  getProperty(data) {
    let len = data.split(',').length;
    this.propertyValues = data.split(',').slice(3, len);
  }

  ngOnDestroy() {
    if (!!this.searchSubscription$) {
      this.searchSubscription$.unsubscribe();
    }
  }
}
