import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import Bee from '@mailupinc/bee-plugin';
import { TemplateService } from 'src/app/services/dataServices/template.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { beeCredentials } from 'src/app/shared/constants';
import { TemplateTest } from '../../models/template-test';

@Component({
  selector: 'bee-editor',
  templateUrl: './bee-editor.component.html',
  styleUrls: ['./bee-editor.component.scss']
})
export class BeeEditorComponent implements OnInit {

  @Input()
  templateJson: string = '';

  @Input()
  showBackButton: boolean = true;
  @Input()
  backButtonText: string = 'Create Template';

  @Input()
  showPreviewButton: boolean = true;

  @Input()
  showTestEmail: boolean = true;

  @Output() templateSaved: EventEmitter<any> = new EventEmitter();
  @Output() goBack: EventEmitter<void> = new EventEmitter();


  beeTest = new Bee();
  beeEditorLoaded: boolean = false;

  testTemplate: TemplateTest = new TemplateTest();

  specialLinks = [{
    type: 'unsubscribe',
    label: 'SpecialLink.Unsubscribe',
    link: 'http://[unsubscribe]/'
  }, {
    type: 'subscribe',
    label: 'SpecialLink.Subscribe',
    link: 'http://[subscribe]/'
  }];

  mergeTags = [
    { name: 'Appt AM/PM', value: '<%apptAMPM%>' },
    { name: 'Appt Day', value: '<%apptDD%>' },
    { name: 'Appt Day Description', value: '<%apptDay%>' },
    { name: 'Appt Month Day', value: '<%apptMMDD%>' },
    { name: 'Appt Month Day Year', value: '<%apptMMDDYY%>' },
    { name: 'Appt Month', value: '<%apptMM%>' },
    { name: 'Appt Name', value: '<%apptName%>' },
    { name: 'Appt Short Time', value: '<%apptTime%>' },
    { name: 'Appt Year', value: '<%apptYY%>' },
    { name: 'Location Address 1', value: '<%lcAddress1%>' },
    { name: 'Location Address 2', value: '<%lcAddress2%>' },
    { name: 'Location City', value: '<%lcCity%>' },
    { name: 'Location Email', value: '<%lcEmail%>' },
    { name: 'Location Name', value: '<%lcName%>' },
    { name: 'Location Preferred Name', value: '<%lcPrefName%>' },
    { name: 'Location Phone', value: '<%lcPhone%>' },
    { name: 'Location SMS', value: '<%lcSMS%>' },
    { name: 'Location State', value: '<%lcState%>' },
    { name: 'Location Web', value: '<%lcWeb%>' },
    { name: 'Location Zipcode', value: '<%lcZip%>' },
    { name: 'Map', value: '<%Map%>' },
    { name: 'Person Address 1', value: '<%prAddress1%>' },
    { name: 'Person Address 2', value: '<%prAddress2%>' },
    { name: 'Person City', value: '<%prCity%>' },
    { name: 'Person Email', value: '<%prEmail%>' },
    { name: 'Person First Name', value: '<%prFirst%>' },
    { name: 'Person Full Name', value: '<%prFull%>' },
    { name: 'Person Last Name', value: '<%prLast%>' },
    { name: 'Person Mobile', value: '<%prMobile%>' },
    { name: 'Person Phone', value: '<%prPhone%>' },
    { name: 'Person State', value: '<%prState%>' },
    { name: 'Person Work Phone', value: '<%prWorkPhone%>' },
    { name: 'Person Zipcode', value: '<%prZip%>' },
    { name: 'Provider Name', value: '<%Name%>' },
    { name: 'Resource Address 1', value: '<%rsAddress1%>' },
    { name: 'Resource Address 2', value: '<%rsAddress2%>' },
    { name: 'Resource City', value: '<%rsCity%>' },
    { name: 'Resource Email', value: '<%rsEmail%>' },
    { name: 'Resource First Name', value: '<%rsFirst%>' },
    { name: 'Resource Full Name', value: '<%rsFull%>' },
    { name: 'Resource Last Name', value: '<%rsLast%>' },
    { name: 'Resource Mobile', value: '<%rsMobile%>' },
    { name: 'Resource Preferred Name', value: '<%rsPrefFirst%>' },
    { name: 'Resource Preferred Full Name', value: '<%rsPrefFull%>' },
    { name: 'Resource Phone', value: '<%rsPhone%>' },
    { name: 'Resource State', value: '<%rsState%>' },
    { name: 'Reply Form', value: '<%replyForm%>' },
    { name: 'Specialty', value: '<%specialty%>' }
  ];

  mergeContents = [{
    name: 'content 1',
    value: '[content1]'
  }, {
    name: 'content 2',
    value: '[content1]'
  }];

  beeConfig = {
    uid: 'ruben',
    container: 'bee-plugin-container',
    autosave: 15,
    language: 'en-US',
    specialLinks: this.specialLinks,
    mergeTags: this.mergeTags,
    mergeContents: this.mergeContents,
    onSave: (jsonData, htmlData) => {
      this.templateSaved.emit({ templateJson: jsonData, templateHtml: htmlData });
    },
    onSaveAsTemplate: (jsonFile) => {
      return jsonFile;
    },
    onError: (errorMessage) => {
    },
    onSend: (html) => {
      this.testTemplate.templateHtml = html;
      this.templateService.test(this.testTemplate).subscribe(() => {
        this.toaster.showSuccessMessage('Test email sent');
      });
    }
  }

  constructor(private templateService: TemplateService,
    private toaster: ToasterService) { }

  ngOnInit(): void {
    this.testTemplate.templateName = 'Test Email';
    this.initiateBeePlugin();
  }

  initiateBeePlugin() {

    if (!this.beeEditorLoaded) {
      this.beeTest.getToken(beeCredentials.clientId, beeCredentials.clientSecret)
        .then((res) => {
          let json = {};
          if (this.templateJson && this.templateJson != '') {
            json = JSON.parse(this.templateJson);
          }

          this.beeTest.start(this.beeConfig, json);
          this.beeEditorLoaded = true;
        });
    } else {
      let json = {};
      if (this.templateJson && this.templateJson != '') {
        json = JSON.parse(this.templateJson);
      }

      this.beeTest.start(this.beeConfig, json);
    }
  }

  saveTemplate() {
    this.beeTest.save();
  }

  back() {
    this.goBack.emit();
  }

  previewTemplate() {
    this.beeTest.preview();
  }

  sendTestEmail() {
    if (!this.testTemplate || !this.testTemplate.email || this.testTemplate.email == '') {
      return;
    }

    this.beeTest.send();
  }

}
