import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddSMSDialogComponent } from './add-smsdialog.component';

describe('AddSMSDialogComponent', () => {
  let component: AddSMSDialogComponent;
  let fixture: ComponentFixture<AddSMSDialogComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddSMSDialogComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddSMSDialogComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
