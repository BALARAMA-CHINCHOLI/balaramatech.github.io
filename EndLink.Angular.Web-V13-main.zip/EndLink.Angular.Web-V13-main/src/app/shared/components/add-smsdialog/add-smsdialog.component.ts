import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { LandingPageService } from 'src/app/services/landing-page.service';
import { LanguageService } from 'src/app/services/language.service';
import { TemplateService } from 'src/app/services/template.service';
import { SortingType } from '../../enums/sorting-type';
import { TemplateFilter } from '../../models/template-filter';
import * as _ from 'lodash';
import { CommunicationChannelType } from '../../enums/communication-channel-type';

@Component({
  selector: 'app-add-smsdialog',
  templateUrl: './add-smsdialog.component.html',
  styleUrls: ['./add-smsdialog.component.scss']
})
export class AddSMSDialogComponent implements OnInit {
  landingPageValue = {
    category: '',
    domain: ''
  };
  resultValue = {
    id: CommunicationChannelType.SMS,
    name: CommunicationChannelType[CommunicationChannelType.SMS],
    languageId: 0,
    languageName: '',
    messageContent: '',
    action: 'delete'
  };

  languages: any[] = [];
  templates: any[] = [];
  landingPages: any[] = [];

  errorFlag = false;

  constructor(public dialogRef: MatDialogRef<any>, private languageService: LanguageService,
              private templateService: TemplateService, private landingPageService: LandingPageService) { }

  ngOnInit(): void {
    this.getLanguages();
    this.getTemplates();
    this.getLandingPages();
  }

  private getLanguages(): void {
    this.languageService.list().subscribe((data) => {
      if (data.responseObject) {
        this.languages = data.responseObject;

        if (this.languages.length > 0) {
          this.resultValue.languageId = this.languages[0].id;
          this.resultValue.languageName = this.languages[0].name;
        }
      }
    });
  }

  private getTemplates(): void {
    const templateFilter: TemplateFilter = {
      paging: {
        pageNumber: 1,
        pageSize: 1000
      },
      sorting: {
        order: SortingType.Asc,
        sortBy: 'Name'
      },
      IsActive: true,
      categoryId: 9
    };

    this.templateService.list(templateFilter).subscribe((data) => {
      if (data.responseObject && data.responseObject.list) {
        this.templates = data.responseObject.list;
      }
    });
  }

  private getLandingPages(): void {
    this.landingPageService.list().subscribe((data) => {
      if (data.responseObject) {
        this.landingPages = data.responseObject;

        if (this.landingPages.length > 0) {
          this.landingPageValue.domain = this.landingPages[0].name;
        }
      }
    });
  }

  addField(data): void {
    if (data.type == 'Audio') {
      this.resultValue.messageContent += ' <a href="' + data.value + '">' + data.name + '</a>';
    } else {
      this.resultValue.messageContent += data.value;
    }

    this.errorFlag = false;
  }

  addlandingPage(): void {
    this.resultValue.messageContent += 'http://' + this.landingPageValue.domain + '/A/L/P/' + this.landingPageValue.category;
  }

  sendData(): void {
    if (this.resultValue.messageContent === '') {
      this.errorFlag = true;
      return;
    }
    else {
      this.errorFlag = false;
      this.dialogRef.close(this.resultValue);
    }
  }

  close(): void {
    this.dialogRef.close(false);
  }

  selectChange(): void {
    this.resultValue.languageName = _.find(this.languages, item => item.id === this.resultValue.languageId).name;
  }

  validateContent(): void {
    if (this.resultValue.messageContent === '') {
      this.errorFlag = true;
    }
    else {
      this.errorFlag = false;
    }
  }
}
