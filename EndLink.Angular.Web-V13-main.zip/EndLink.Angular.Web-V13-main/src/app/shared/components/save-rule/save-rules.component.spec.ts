import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SaveRulesComponent } from './save-rules.component';

describe('SaveRulesComponent', () => {
  let component: SaveRulesComponent;
  let fixture: ComponentFixture<SaveRulesComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ SaveRulesComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(SaveRulesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
