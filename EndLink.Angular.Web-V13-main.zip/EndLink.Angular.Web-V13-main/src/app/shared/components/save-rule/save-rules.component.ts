import { Component, ElementRef, EventEmitter, Input, OnInit, Output, ViewChild } from '@angular/core';
import { FormControl, NgForm } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { EventTypeParameterService } from 'src/app/services/event-type-parameter.service';
import { EventWorkflowTypeService } from 'src/app/services/event-workflowType.service';
import { OperatorService } from 'src/app/services/operator.service';
import { RuleService } from 'src/app/services/rule.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { paths } from 'src/app/shared/constants';
import { SortingType } from 'src/app/shared/enums/sorting-type';
import { Response } from 'src/app/shared/models/response';
import { DataType, EventType, EventTypeParameter, Operator, Rule, RuleDetail } from 'src/app/shared/models/rule';
import { SearchFilter } from 'src/app/shared/models/search-filter';
import { SuccessPopupComponent } from '../success-popup/success-popup.component';

@Component({
  selector: 'app-save-rules',
  templateUrl: './save-rules.component.html',
  styleUrls: ['./save-rules.component.scss']
})
export class SaveRulesComponent implements OnInit {
  rule: Rule = new Rule();
  eventTypes: EventType[] = [];
  filteredEventTypes: any;
  eventTypeParameters: EventTypeParameter[] = [];
  operators: Operator[] = [];
  eventTypefilter: SearchFilter = {
    SearchText: '',
    getAll: true,
    paging: {
      pageNumber: 1,
      pageSize: 10
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'Name'
    }
  };
  submitted = false;
  isEdit = false;

  @Input() id: number = 0;
  @Input() eventTypeId: number;
  @Input() hideButtons: boolean = false;
  @Input() disableEventType: boolean = false;
  @Output() ruleSaved: EventEmitter<number> = new EventEmitter();
  data: boolean;
  sid: any;
  rname: boolean;
  rdesc: boolean;
  equalCurrentDateOperatorId: number;

  dateTypeParameters = [];

  @ViewChild('saveButton', { read: ElementRef }) saveButton: ElementRef<HTMLElement>;
  dataSourceControl = new FormControl();

  constructor(private eventTypeService: EventWorkflowTypeService,
    private eventTypeParameterService: EventTypeParameterService,
    private operatorService: OperatorService,
    private toaster: ToasterService,
    private ruleService: RuleService,
    private dialog: MatDialog,
    private router: Router) {
    this.rule.eventType.id = this.eventTypeId;
    this.rule.ruleDetails.push(this.getNewRuleDetail());
  }

  ngOnInit() {
    if (this.id > 0) {
      this.isEdit = true;
      this.getRule(this.id);
    }
    this.getEventTypes();

    this.dataSourceControl.valueChanges.subscribe((text) => {
      this.filteredEventTypes = this._filter(text);
    });
  }

  private _filter(value: string) {
    if (!value || value == '') {
      return this.eventTypes;
    }

    const filterValue = value.toString().toLowerCase();

    return this.eventTypes.filter(option => option.name.toLowerCase().includes(filterValue));
  }

  getRule(id: number) {
    this.ruleService.get(id).subscribe((data: Response) => {
      const rule = data.responseObject;

      rule.ruleDetails.forEach((item: RuleDetail) => {
        item.dataType = item.eventTypeParameter.dataType;
        item.eventTypeParameterValueList = item.eventTypeParameter.parameterValues;

        this.getOperators(item.eventTypeParameter.dataType.id, item);
      });

      this.getEventTypeParameters(rule.eventType.id);

      this.rule = rule;
      this.setGroupPosition();
    });
  }

  selectAutoComplete(event: MatAutocompleteSelectedEvent): void {
    const item = this.eventTypes.find(x => x.id == event.option.value);

    if (!item) {
      return;
    }
    this.rule.eventType.id = item.id;
    this.rule.eventType.name = item.name;
    this.dataSourceControl.setValue(item.name);
    this.eventTypeChange(null);
  }

  getEventTypes() {
    this.eventTypeService.list(this.eventTypefilter).subscribe((data: Response) => {
      this.eventTypes = data.responseObject.list;
      this.filteredEventTypes = this.eventTypes;

      if (this.eventTypeId && this.eventTypeId > 0) {
        const eventType = this.eventTypes.find(x => x.id == this.eventTypeId);

        if (eventType != null) {
          this.rule.eventType.id = eventType.id;
          this.rule.eventType.name = eventType.name;
        }

        this.getEventTypeParameters(this.eventTypeId);
      }
    });
  }

  getEventTypeParameters(eventTypeId: number) {
    this.eventTypeParameterService.list(eventTypeId).subscribe((data: Response) => {
      this.eventTypeParameters = data.responseObject;

      this.eventTypeParameters.forEach((item) => {
        if (item.dataType.name == 'Date') {
          this.dateTypeParameters.push(item);
        }
      });
    });
  }

  getOperators(dataTypeId: number, ruleDetail: RuleDetail) {
    this.operatorService.list(dataTypeId).subscribe((data: Response) => {
      ruleDetail.operatorList = data.responseObject;
    });
  }

  eventTypeChange($event) {
    this.rule.eventDateParameterId = null;
    this.getEventTypeParameters(this.rule.eventType.id);
    this.rule.ruleDetails = [];
    this.rule.ruleDetails.push(this.getNewRuleDetail());
  }

  eventTypeParameterChange(ruleDetail: RuleDetail) {
    const parameter = this.eventTypeParameters.find(x => x.id == ruleDetail.eventTypeParameter.id);
    if (parameter != null) {
      this.getOperators(parameter.dataType.id, ruleDetail);
      ruleDetail.eventTypeParameterValueList = parameter.parameterValues;
      ruleDetail.dataType = parameter.dataType;
    }
  }

  addRuleDetail() {
    if (this.rule && this.rule.ruleDetails && this.rule.ruleDetails.length >= 50) {
      this.toaster.showErrorMessage('You can only add maximum 50 rows.');
      return;
    }

    this.rule.ruleDetails.push(this.getNewRuleDetail());
  }

  removeRuleDetail(index) {
    this.rule.ruleDetails.splice(index, 1);

    // reset sequence
    this.rule.ruleDetails.forEach((item, index) => {
      item.seqNo = index + 1;
    });
  }

  group() {
    const groupedDetails = this.rule.ruleDetails.filter(x => x.isGroup);

    if (!groupedDetails || groupedDetails.length < 1) {
      return;
    }
    if (groupedDetails.filter(x => x.group > 0).length > 0) {
      this.toaster.showErrorMessage('Intersecting groups is not allowed');
      return;
    }


    let lastItemSeq = groupedDetails[0].seqNo;
    let itemsInSequence = true;

    // validating that grouped items should be in sequence
    groupedDetails.forEach((item, index) => {
      if (index > 0 && item.seqNo != (lastItemSeq + 1)) {
        itemsInSequence = false;
      }
      lastItemSeq = item.seqNo;;
    });

    if (!itemsInSequence) {
      this.toaster.showErrorMessage('Grouped items must be in a sequence');
      return;
    }

    let lastMaxGroupNumber = Math.max.apply(null, this.rule.ruleDetails.map(x => x.group));

    if (!lastMaxGroupNumber) {
      lastMaxGroupNumber = 0;
    }

    const newGroupNumber = lastMaxGroupNumber + 1;

    this.rule.ruleDetails.forEach((item) => {
      if (item.isGroup) {
        item.group = newGroupNumber;
        item.isGroup = false;
      }
    });
    this.setGroupPosition();
  }

  private setGroupPosition() {
    var current = 0;
    this.rule.ruleDetails.forEach((item, index) => {
      if (item.group > 0) {

        // first item
        if (current == 0) {
          item.groupPosition = 'First';
          current = item.group;
        } else {
          var nextItemGroup = 0;
          if ((index + 1) <= this.rule.ruleDetails.length - 1) {
            nextItemGroup = this.rule.ruleDetails[index + 1].group;
          }

          if (nextItemGroup == item.group) {
            item.groupPosition = 'Intermediate';
          } else {
            item.groupPosition = 'Last';
            current = 0;
          }
        }
      }
    });
  }

  space(event) {
    this.rule.name = this.rule.name?.trim();
    this.rule.description = this.rule.description?.trim();
    switch (this.sid) {
      case '1': {
        if (this.rule.name.length == null) {
          this.rname = false

        }
        else {
          this.rname = true
        }
      }
        break;
      case '2': {

        if (this.rule.description.length == null) {
          this.rdesc = false

        }
        else {
          this.rdesc = true
        }
      }
        break;
    }



  }


  save(isValid) {
    this.submitted = true;

    if (!isValid) {
      return;
    }

    if (this.rule.eventType.id < 1 || this.rule.ruleDetails.length < 1 || !this.validateRuleDetails()) {
      return;
    }

    if (this.rule.id > 0) {
      this.ruleService.update(this.rule).subscribe((data) => {
        if (data.isError) {
          this.toaster.showErrorMessage(data.message);
        } else {
          this.ruleSaved.emit(data.responseObject);
          let successDialog = this.dialog.open(SuccessPopupComponent, { data: { successMessage: 'Rule updated successfully' } });
          // this.toaster.showSuccessMessage('Rule updated successfully');
        }
      });
    } else {
      this.ruleService.create(this.rule).subscribe((data) => {
        if (data.isError) {
          this.toaster.showErrorMessage(data.message);
        } else {
          this.ruleSaved.emit(data.responseObject);
          let successDialog = this.dialog.open(SuccessPopupComponent, { data: { successMessage: 'Rule created successfully' } });
          // this.toaster.showSuccessMessage('Rule created successfully');
        }
      });
    }

  }

  goback() {
    this.router.navigate([paths.rulesList]);
  }

  isEqualOperatorSelected(ruleDetail: RuleDetail) {
    if (!ruleDetail.operatorList || ruleDetail.operatorList.length < 1) {
      return false;
    }

    const equalCurrentDateOperator = ruleDetail.operatorList.find(x => x.name == '= Current Date');

    if (equalCurrentDateOperator == null) {
      return false;
    }

    return ruleDetail.operator.id == equalCurrentDateOperator.id;
  }

  private validateRuleDetails(): Boolean {
    let isValid = true;

    this.rule.ruleDetails.forEach((item) => {
      if (item.eventTypeParameter.id < 1 || item.operator.id < 1) {
        isValid = false;
      }

      if (isValid && !this.isEqualOperatorSelected(item) && (item.value == '' || item.value == '0')) {
        isValid = false;
      }

    });

    return isValid;
  }

  private getNewRuleDetail(): RuleDetail {
    const detail = new RuleDetail();
    detail.isAnd = true;
    detail.seqNo = this.rule.ruleDetails.length + 1;
    detail.dataType = <DataType>{ name: 'String' };
    return detail;
  }
}
