import { Component, EventEmitter, OnInit, Output } from '@angular/core';
import { MatTableDataSource } from '@angular/material/table';
import { PersonService } from 'src/app/services/person.service';
import { PersonCategoryType } from '../../enums/person-category';
import { PersonFilter } from '../../models/person-filter';

@Component({
  selector: 'app-select-members',
  templateUrl: './select-members.component.html',
  styleUrls: ['./select-members.component.scss']
})
export class SelectMembersComponent implements OnInit {
  membersFilter: PersonFilter = new PersonFilter();
  searchData = {
    dataSource: new MatTableDataSource(),
    headerData: [
      {def: 'FirstName', prop: 'FirstName', title: 'First Name', type: 'text'},
      {def: 'LastName', prop: 'LastName', title: 'Last Name', type: 'text'},
      {def: 'mail', prop: 'mail', title: 'Email', type: 'text'},
      {def: 'cell', prop: 'cell', title: 'Cellphone', type: 'text'},
      {def: 'action', prop: 'action', title: 'Action', type: 'action'}
    ]
  };

  personCategory = [];

  @Output() action = new EventEmitter()

  constructor(private personService: PersonService) { }

  ngOnInit(): void {
    this.getPersonCategory();
  }

  getPersonCategory(): void {
    for (const [propertyKey, propertyValue] of Object.entries(PersonCategoryType)) {
      if (!Number.isNaN(Number(propertyKey))) {
        continue;
      }
      this.personCategory.push({ id: propertyValue,
                                  name: propertyKey,
                                  checked: (propertyValue === 1 ? true : false) });
    }
    this.membersFilter.category = PersonCategoryType.Patient;
  }

  addMember(event): void {
    this.action.emit(Object.assign(event.value, {category: this.membersFilter.category}));
  }

  searchPerson(): void {
    this.membersFilter.isactive = true;

    if (this.membersFilter.name && this.membersFilter.name.length > 0
          && (this.membersFilter.name.length < 3 || this.membersFilter.name.length > 250)) {
      alert('Enter Minimum 3 and Maximum 250 characters in Name field to search.');
      return;
    } else if (this.membersFilter.email && this.membersFilter.email.length > 0
          && (this.membersFilter.email.length < 3 || this.membersFilter.email.length > 250)) {
      alert('Enter Minimum 3 and Maximum 250 characters in Email field to search.');
      return;
    } else if (this.membersFilter.cellPhone && this.membersFilter.cellPhone.length > 0 && this.membersFilter.cellPhone.length < 3) {
      alert('Enter Minimum 3 characters in Cell Phone field to search.');
      return;
    }

    const objArray = [];

    this.personService.list(this.membersFilter).subscribe((data) => {
      if (data.responseObject && data.responseObject.list) {
        data.responseObject.list.forEach(element => {
          objArray.push({
            id: element.id, FirstName: element.firstName , LastName: element.lastName, mail: element.personalEmail,
                    cell: element.cellPhone, action: ['add']});
        });
        this.searchData.dataSource = new MatTableDataSource([...objArray]);
      }
    });
  }

  resetPerson(): void {
    this.membersFilter.isactive = true;
    this.membersFilter.name = '';
    this.membersFilter.cellPhone = '';
    this.membersFilter.email = '';
  }
}
