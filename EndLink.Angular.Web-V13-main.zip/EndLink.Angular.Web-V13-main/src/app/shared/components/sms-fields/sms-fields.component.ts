import { Component, EventEmitter, OnInit, Output, Input } from '@angular/core';
import {
  Directive,
  HostListener, ViewChild,
  ElementRef, Renderer2,
} from '@angular/core';

import { MatTableDataSource } from '@angular/material/table';
import { MergeFieldService } from '../../../services/merge-field.service';
import { SortingType } from '../../enums/sorting-type';
import { SearchFilter } from '../../models/search-filter';
import { AudioService } from '../../../services/audio.service';
import { EventTypeParameterService } from 'src/app/services/event-type-parameter.service';
import { WorkflowService } from 'src/app/services/workflow.service';

@Component({
  selector: 'app-sms-fields',
  templateUrl: './sms-fields.component.html',
  styleUrls: ['./sms-fields.component.scss']
})
export class SmsFieldsComponent implements OnInit {

  @ViewChild('mergesearch') mergesearch: ElementRef;


  fieldsData = {
    dataSource: new MatTableDataSource(),
    headerData: [
      { def: 'name', prop: 'name', title: 'Name' },
      { def: 'action', prop: 'action', title: 'Action' }
    ]
  };
  searchText = '';
  sortOrder = SortingType.Asc;
  mergewraper: boolean;
  @Input() eventTypeId: number = 0;
  @Input() type: string;
  @Output() addFieldProp = new EventEmitter();

  constructor(private mergeFieldServicie: MergeFieldService
    , private audioServicie: AudioService
    , private workflowService: WorkflowService, private renderer: Renderer2) {

    this.renderer.listen('window', 'click', (e: Event) => {
      /**
       * Only run when toggleButton is not clicked
       * If we don't check this, all clicks (even on the toggle button) gets into this
       * section which in the result we might never see the menu open!
       * And the menu itself is checked here, and it's where we check just outside of
       * the menu and button the condition abbove must close the menu
       */
      if (e.target !== this.mergesearch.nativeElement) {
        this.mergewraper = false;
      }
    });

  }

  ngOnInit(): void {
    this.mergewraper = false;
    if (this.type === 'MergeFields') {
      this.getMergeFields();
    } else if (this.type === 'Audio') {
      this.getAudios();
    }
  }

  private getMergeFields(): void {

    if (this.eventTypeId > 0) {
      this.workflowService.getWorkflowMergeFields(this.eventTypeId).subscribe((data) => {
        if (data.responseObject) {
          this.fieldsData.dataSource = new MatTableDataSource(data.responseObject);
        }
      });
    } else {

      const searchFilter: SearchFilter = {
        SearchText: this.searchText,
        paging: {
          pageNumber: 1,
          pageSize: 15
        },
        sorting: {
          order: this.sortOrder,
          sortBy: 'Name'
        },
        IsActive: true
      };

      this.mergeFieldServicie.list(searchFilter).subscribe((data) => {
        if (data.responseObject.list) {
          this.fieldsData.dataSource = new MatTableDataSource(data.responseObject.list);
        }
      });
    }
  }

  private getAudios(): void {
    const searchFilter: SearchFilter = {
      SearchText: this.searchText,
      paging: {
        pageNumber: 1,
        pageSize: 15
      },
      sorting: {
        order: this.sortOrder,
        sortBy: 'Name'
      },
      IsActive: true
    };

    this.audioServicie.list(searchFilter).subscribe((data) => {
      if (data.responseObject.list) {
        this.fieldsData.dataSource = new MatTableDataSource(data.responseObject.list);
      }
    });
  }

  getHeaderColumns(): string[] {
    return this.fieldsData?.headerData?.map(header => header.def);
  }

  addField(event): void {
    if (this.type === 'MergeFields') {
      this.addFieldProp.emit({ name: event.name, value: event.value, type: 'MergeFields' });
    } else if (this.type === 'Audio') {
      this.addFieldProp.emit({ name: event.name, value: event.audioUrl, type: 'Audio' });
    }
    this.mergewraper = !this.mergewraper;

  }

  searchFilter(): void {
    this.mergewraper = !this.mergewraper;
    if (this.type === 'MergeFields') {
      this.getMergeFields();
    } else if (this.type === 'Audio') {
      this.getAudios();
    }
  }

  sortColumn(): void {
    if (this.sortOrder === SortingType.Asc) {
      this.sortOrder = SortingType.Desc;
    }
    else {
      this.sortOrder = SortingType.Asc;
    }

    if (this.type === 'MergeFields') {
      this.getMergeFields();
    } else if (this.type === 'Audio') {
      this.getAudios();
    }
  }
}
