import { Component, OnInit } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { LanguageService } from 'src/app/services/language.service';
import * as _ from 'lodash';
import { CommunicationChannelType } from '../../enums/communication-channel-type';

@Component({
  selector: 'app-add-voice-dialog',
  templateUrl: './add-voice-dialog.component.html',
  styleUrls: ['./add-voice-dialog.component.scss']
})
export class AddVoiceDialogComponent implements OnInit {
  resultValue = {
    id: CommunicationChannelType.Voice,
    name: CommunicationChannelType[CommunicationChannelType.Voice],
    languageId: 0,
    languageName: '',
    messageContent: '',
    action: 'delete'
  };

  languages: any[] = [];

  errorFlag = false;

  constructor(public dialogRef: MatDialogRef<any>, private languageService: LanguageService) { }

  ngOnInit(): void {
    this.getLanguages();
  }

  private getLanguages(): void {
    this.languageService.list().subscribe((data) => {
      if (data.responseObject) {
        this.languages = data.responseObject;

        if (this.languages.length > 0) {
          this.resultValue.languageId = this.languages[0].id;
          this.resultValue.languageName = this.languages[0].name;
        }
      }
    });
  }

  addField(data): void {
    if (data.type == 'Audio') {
      this.resultValue.messageContent += data.value;
    } else {
      this.resultValue.messageContent += data.value;
    }

    this.errorFlag = false;
  }

  sendData(): void {
    if (this.resultValue.messageContent === '') {
      this.errorFlag = true;
      return;
    }
    else {
      this.errorFlag = false;
      this.dialogRef.close(this.resultValue);
    }
  }

  close(): void {
    this.dialogRef.close(false);
  }

  selectChange(): void {
    this.resultValue.languageName = _.find(this.languages, item => item.id === this.resultValue.languageId).name;
  }

  validateContent(): void {
    if (this.resultValue.messageContent === '') {
      this.errorFlag = true;
    }
    else {
      this.errorFlag = false;
    }
  }
}
