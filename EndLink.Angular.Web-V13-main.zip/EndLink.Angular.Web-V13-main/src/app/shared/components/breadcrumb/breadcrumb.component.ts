import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { BreadcrumbService } from 'src/app/services/breadcrumb.service';

@Component({
  selector: 'app-breadcrumb',
  templateUrl: './breadcrumb.component.html',
  styleUrls: ['./breadcrumb.component.scss'],
})
export class BreadcrumbComponent implements OnInit {
  breadcrumbs$: Observable<any[]>;
  title = '';
  constructor(public breadcrumbService: BreadcrumbService) {
    this.breadcrumbs$ = breadcrumbService.breadcrumbs$;
  }
  ngOnInit(): void {
    this.breadcrumbService.currentData.subscribe((data: any) => {
      this.title = data.title || '';
    });
    // this.breadcrumbs$.subscribe((breadcrumbs) => {
    //   this.title = breadcrumbs[breadcrumbs.length - 1].title;
    // });
  }
}
