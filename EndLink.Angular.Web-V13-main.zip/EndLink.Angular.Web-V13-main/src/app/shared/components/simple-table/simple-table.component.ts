import { Component, OnChanges, ViewChild, Input, Output, EventEmitter } from '@angular/core';
import {MatSort} from '@angular/material/sort';


@Component({
  selector: 'app-simple-table',
  templateUrl: './simple-table.component.html',
  styleUrls: ['./simple-table.component.scss']
})
export class SimpleTableComponent implements OnChanges {

  @Input() data;
  @Output() action = new EventEmitter();
  @ViewChild(MatSort) sort: MatSort;

  constructor() {
    const users = Array.from({length: 15}, (_, k) => createNewUser(k + 1));
  }

  ngOnChanges() {
    if(!!this.data?.dataSource) {
      this.data.dataSource.sort = this.sort; 
    }
  }

  getHeaderColumns() {
    return this.data?.headerData?.map(header => header.def);
  }

  triggerAction(value, action) {
    this.action.emit({action: action, value: value});
  }

}

function createNewUser(id) {
  return {
    id: id.toString(),
    type: (Math.round(Math.random() * 100)%2 ) == 0 ? 'Patients': 'Employees',
    member: Math.round(Math.random()* 100).toString()
  };
}