import {
  HttpErrorResponse, HttpEvent,
  HttpHandler, HttpInterceptor,
  HttpRequest,
  HttpResponse
} from "@angular/common/http";
import { Injectable } from "@angular/core";
import { Router } from "@angular/router";
import { Observable, throwError } from "rxjs";
import { catchError, tap } from "rxjs/operators";
import { AuthenticationService } from "../../services/authentication.service";
import { paths } from "../constants";

@Injectable()
export class AuthInterceptor implements HttpInterceptor {
  private AUTH_HEADER = "Authorization";
  private get token() { return localStorage.getItem('endlink.token'); };

  constructor(private authService: AuthenticationService,
    private router: Router) {

  }

  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    if (!req.headers.has("Content-Type")) {
      // req = req.clone({
      //   headers: req.headers.set("Content-Type", "application/json")
      // });
    }

    req = this.addAuthenticationToken(req);

    return next.handle(req).pipe(
      tap(evt => {
        if (evt instanceof HttpResponse) {
          if (evt.body && evt.body.apiStatusCode == 401) {
            this.authService.logout();
          } else if (evt.body && evt.body.apiStatusCode == 403) {
            this.router.navigateByUrl(paths.unauthorised);
          }
        }
      }),
      catchError((error: HttpErrorResponse) => {
        if (error && error.status === 401) {
          this.authService.logout();
          return throwError(error);
        }
        
        if (error && error.status === 403) {
          this.router.navigateByUrl(paths.unauthorised);
        }
      })
    );
  }

  private addAuthenticationToken(request: HttpRequest<any>): HttpRequest<any> {
    // If we do not have a token yet then we should not set the header.
    // Here we could first retrieve the token from where we store it.
    if (!this.token) {
      return request;
    }
    return request.clone({
      headers: request.headers.set(this.AUTH_HEADER, "Bearer " + this.token)
    });
  }
}
