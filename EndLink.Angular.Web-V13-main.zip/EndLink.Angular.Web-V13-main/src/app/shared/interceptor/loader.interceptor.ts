import { Injectable, Injector } from "@angular/core";
import {
  HttpEvent,
  HttpRequest,
  HttpHandler,
  HttpInterceptor,
  HttpParams
} from "@angular/common/http";
import { Observable, Subject } from "rxjs";
import { finalize, delay, debounceTime } from "rxjs/operators";
import { LoaderService } from "../../services/loader.service";

@Injectable()
export class LoaderInterceptor implements HttpInterceptor {
  constructor(private injector: Injector) {}
  intercept(
    req: HttpRequest<any>,
    next: HttpHandler
  ): Observable<HttpEvent<any>> {
    // if (!req.url.includes("albums")) {
    //   return next.handle(req);
    // }
    console.warn("LoaderInterceptor");
    let params = new HttpParams();
    const loaderService = this.injector.get(LoaderService);
    const loader$ = new Subject();
    if (!!!req.params.get('hideGlobalLoader')) {
      // push one observable to register the current api call
      loaderService.loaderSubject$.push(loader$.asObservable());
      loaderService.show(loaderService.loaderSubject$);
      params = req.params;
    } else {
      req.params.keys().forEach(param=> {
        if(param != 'hideGlobalLoader') {
          params = params.set(param, req.params.get(param));
        }
      })
    }
    const request = req.clone({
      params: params
    })

    return next.handle(request).pipe(
      finalize(() =>  loader$.next(false))
    );
  }
}
