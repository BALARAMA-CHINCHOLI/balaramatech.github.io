export enum ApprovalTypes {
  Campaign = 'Campaign',
  Rule = 'Rule',
  Workflow = 'Workflow'
}
