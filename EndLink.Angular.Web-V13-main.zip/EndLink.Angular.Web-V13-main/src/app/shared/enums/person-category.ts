export enum PersonCategoryType {
    Patient = 1,
    Employee = 2,
    // Caregiver = 3
}