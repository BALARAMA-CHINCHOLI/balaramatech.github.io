export enum Role {
    Buyer = 3,
    Admin = 1,
    Supplier = 2
}