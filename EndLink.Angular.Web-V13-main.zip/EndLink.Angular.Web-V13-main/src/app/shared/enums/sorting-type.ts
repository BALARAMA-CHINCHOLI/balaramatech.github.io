export enum SortingType {
    Asc = 0,
    Desc = 1
}