export enum CommunicationChannelType {
  SMS = 1,
  Voice = 2,
  Email = 3,
  DNC = 4,
  MMS = 5,
}
