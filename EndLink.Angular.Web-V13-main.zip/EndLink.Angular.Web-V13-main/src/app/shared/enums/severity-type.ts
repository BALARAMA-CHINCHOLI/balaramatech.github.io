export enum SeverityType {
    Info = 1,
    Warning = 2,
    Error = 3
}