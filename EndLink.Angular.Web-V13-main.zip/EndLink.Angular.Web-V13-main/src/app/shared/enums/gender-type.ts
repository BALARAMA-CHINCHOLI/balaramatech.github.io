export enum GenderType {
    Male = 1,
    Female = 2,
    Unknown = 3
}