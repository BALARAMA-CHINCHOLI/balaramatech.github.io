export enum NotificationType
{
    BusinessUnit = 1,
    Campaign = 2,
    Workflow = 3,
    Approval = 4
}