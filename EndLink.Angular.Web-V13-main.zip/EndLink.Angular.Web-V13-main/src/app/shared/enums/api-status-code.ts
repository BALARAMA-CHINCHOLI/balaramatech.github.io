export enum ApiStatusCode {
    None = 0,
    Ok = 200,
    UnAuth = 401,
    InternalError = 500
}