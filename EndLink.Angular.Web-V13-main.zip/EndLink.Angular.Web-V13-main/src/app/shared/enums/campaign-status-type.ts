export enum CampaignStatusType
{
    Draft = 1,
    In_Progress = 2,
    Pending_Approval = 3,
    Rejected = 4,
    Approved = 5,
    Error = 6,
    Aborted = 7,
    Sent = 8,
    Processing = 9
}
