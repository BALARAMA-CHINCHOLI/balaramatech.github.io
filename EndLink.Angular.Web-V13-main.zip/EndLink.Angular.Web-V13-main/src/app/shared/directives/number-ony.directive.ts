import { Directive, HostListener } from '@angular/core';

@Directive({
  selector: '[numberOnly]',
})
export class NumberOnlyDirective {
  constructor() {}
  @HostListener('keypress', ['$event']) blockCharacters(e: KeyboardEvent) {
    let numberRegex = new RegExp('[0-9]+');
    if (!numberRegex.test(e.key)) {
      e.preventDefault();
    }
  }
}
