import { InfiniteScrollerDirective } from './infinite-scroller.directive';

xdescribe('InfiniteScrollerDirective', () => {
  it('should create an instance', () => {
    // const directive = new InfiniteScrollerDirective();
    // expect(directive).toBeTruthy();
  });
});
