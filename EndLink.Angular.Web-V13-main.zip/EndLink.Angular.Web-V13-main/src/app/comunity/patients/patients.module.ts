import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Ng2TelInputModule } from 'ng2-tel-input';
import { SharedModule } from 'src/app/shared/shared.module';
import { AddPatientComponent } from './add-patient/add-patient.component';
import { AddCaregiversComponent } from './caregivers/caregiver-add/add-caregivers.component';
import { CaregiverListComponent } from './caregivers/caregiver-list/caregiver-list.component';
import { PatientsRoutingModule } from './patients-routing.module';
import { PatientsComponent } from './patients.component';
import { ViewPatientComponent } from './view-patient/view-patient.component';



@NgModule({
  declarations: [PatientsComponent, AddPatientComponent, ViewPatientComponent, CaregiverListComponent, AddCaregiversComponent],
  imports: [
    CommonModule,
    FormsModule,
    Ng2TelInputModule,
    ReactiveFormsModule,
    SharedModule,
    PatientsRoutingModule
  ]
})
export class PatientsModule { }
