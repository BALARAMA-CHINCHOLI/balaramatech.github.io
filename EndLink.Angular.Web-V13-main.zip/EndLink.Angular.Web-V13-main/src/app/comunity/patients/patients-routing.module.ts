import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from 'src/app/shared/helpers/auth.guard';
import { AddPatientComponent } from './add-patient/add-patient.component';
import { PatientsComponent } from './patients.component';
import { ViewPatientComponent } from './view-patient/view-patient.component';

const routes: Routes = [
  {
    path: '',
    component: PatientsComponent,
    pathMatch: 'full',
    canActivate: [AuthGuard]
  },
  {
    path: 'add',
    component: AddPatientComponent,
    data: { breadcrumb: 'Add Patient', title: 'Add Patient', isSinglePage: true },
    canActivate: [AuthGuard]
  },
  {
    path: 'edit/:id',
    component: AddPatientComponent,
    data: { breadcrumb: 'Edit Patient', title: 'Edit Patient', isSinglePage: true },
    canActivate: [AuthGuard]
  },
  {
    path: 'view/:id',
    component: ViewPatientComponent,
    data: { breadcrumb: 'View Patient', title: 'View Patient', isSinglePage: true },
    canActivate: [AuthGuard]
  },
  {
    path: '**',
    redirectTo: ''
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class PatientsRoutingModule { }