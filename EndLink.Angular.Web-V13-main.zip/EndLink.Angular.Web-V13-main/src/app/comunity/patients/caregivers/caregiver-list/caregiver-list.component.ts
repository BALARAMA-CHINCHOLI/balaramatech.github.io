import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { CaregiversService } from 'src/app/services/dataServices/caregivers.service';
import { RelationshipTypeService } from 'src/app/services/dataServices/relationshipType.service';
import { ScrollerService } from 'src/app/services/scroller-service.service';
import { SortingType } from 'src/app/shared/enums/sorting-type';
import { ListModel } from 'src/app/shared/models/list-model';
import { Person } from 'src/app/shared/models/person';
import { PersonFilter } from 'src/app/shared/models/person-filter';
import { PersonCaregiver } from 'src/app/shared/models/personCaregiver';

@Component({
  selector: 'app-caregiver-list',
  templateUrl: './caregiver-list.component.html',
  styleUrls: ['./caregiver-list.component.scss'],
})
export class CaregiverListComponent implements OnInit {

  @Input() patientId: number = 0;
  @Input() addedCaregivers: PersonCaregiver[] = [];

  @Output() caregiverAdded: EventEmitter<PersonCaregiver> = new EventEmitter();
  @Output() cancelAdd: EventEmitter<void> = new EventEmitter();
  @Output() addNewCaregiver: EventEmitter<void> = new EventEmitter();

  selectedCaregiver: Person;
  model: PersonCaregiver = new PersonCaregiver();

  filter: PersonFilter = {
    paging: {
      pageNumber: 1,
      pageSize: 10,
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'Name',
    },
    term: ''
  };

  list: ListModel<Person> = {
    list: [],
    hasNextPage: false,
  };

  careGiverList$: any;
  scroller$: any;

  relationshipTypes = [];

  constructor(
    private scroller: ScrollerService,
    private careGiverService: CaregiversService,
    private relationshipTypeService: RelationshipTypeService
  ) { }

  pageData: any = {
    pageSize: 10,
    currentPage: 1,
    totalItems: 20,
  };
  showList: boolean = false;

  ngOnInit() {
    this.scroller$ = this.scroller.scroller$.subscribe((res) => {
      if (this.list.hasNextPage && this.showList) {
        this.filter.paging.pageNumber++;
        this.getCareGivers();
      }
    });
    this.getRelationshipTypes();
  }

  search() {
    this.showList = true;
    this.filter.paging.pageNumber = 1;
    this.getCareGivers();
  }


  getCareGivers() {
    this.careGiverList$ = this.careGiverService
      .list(this.filter)
      .subscribe((data: any) => {
        if (this.filter.paging.pageNumber == 1) {
          this.list = data.responseObject;
        } else {
          data.responseObject.list.forEach((item) => {
            this.list.list.push(item);
          });
        }

        this.list.hasNextPage =
          data.responseObject.list && data.responseObject.list.length > 0;
      });
  }

  getRelationshipTypes() {
    this.relationshipTypeService.list()
      .subscribe((data: any) => {
        this.relationshipTypes = data.responseObject.list;
      });
  }

  addCaregiver() {
    this.addNewCaregiver.emit();
  }

  isSelected(item) {
    return this.selectedCaregiver && this.selectedCaregiver.id == item.id;
  }

  isAdded(item) {
    return this.addedCaregivers && this.addedCaregivers.length > 0 && this.addedCaregivers.find(x => x.caregiverId == item.id);
  }

  select(item) {
    this.selectedCaregiver = item;
  }

  cancel() {
    this.cancelAdd.emit();
  }

  save() {
    if (!this.selectedCaregiver || !this.model.relationshipTypeId) {
      return;
    }

    this.model.caregiverId = this.selectedCaregiver.id;
    this.model.caregiverName = this.selectedCaregiver.fullName;
    this.model.personId = this.patientId;
    this.model.relationshipTypeName = this.relationshipTypes.find(x => x.value == this.model.relationshipTypeId).name;

    this.caregiverAdded.emit(this.model);
  }

  public ngOnDestroy() {
    if (this.careGiverList$) {
      this.careGiverList$.unsubscribe();
    }
    this.scroller$.unsubscribe();
  }
}
