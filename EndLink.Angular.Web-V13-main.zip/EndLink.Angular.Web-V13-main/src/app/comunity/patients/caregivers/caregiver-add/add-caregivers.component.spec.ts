import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AddCaregiversComponent } from './add-caregivers.component';

describe('AddCaregiversComponent', () => {
  let component: AddCaregiversComponent;
  let fixture: ComponentFixture<AddCaregiversComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AddCaregiversComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AddCaregiversComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
