import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { CommunicationChannelService } from 'src/app/services/communication-channel.service';
import { CaregiversService } from 'src/app/services/dataServices/caregivers.service';
import { GroupService } from 'src/app/services/group.service';
import { TagService } from 'src/app/services/tag.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { GenderType } from 'src/app/shared/enums/gender-type';
import { SortingType } from 'src/app/shared/enums/sorting-type';
import { Address } from 'src/app/shared/models/address';
import { CommunicationChannel } from 'src/app/shared/models/communication-channel';
import { Group } from 'src/app/shared/models/group';
import { GroupPerson } from 'src/app/shared/models/group-person';
import { Person } from 'src/app/shared/models/person';
import { PersonCommunicationMethods } from 'src/app/shared/models/person-communication-methods';
import { PersonTag } from 'src/app/shared/models/person-tag';
import { PersonCaregiver } from 'src/app/shared/models/personCaregiver';
import { SearchFilter } from 'src/app/shared/models/search-filter';
import { Tag } from 'src/app/shared/models/tag';
import { Response } from '../../../../shared/models/response';

@Component({
  selector: 'app-add-caregivers',
  templateUrl: './add-caregivers.component.html',
  styleUrls: ['./add-caregivers.component.scss']
})
export class AddCaregiversComponent implements OnInit {
  @Input() patientId: number = 0;
  @Input() caregiverId: number = 0;

  @Input() relationshipTypeId: number = null;

  @Output() caregiverAdded: EventEmitter<PersonCaregiver> = new EventEmitter();
  @Output() cancelAdd: EventEmitter<void> = new EventEmitter();

  model: Person = new Person();

  communications: CommunicationChannel[] = [];
  groups: Group[] = [];
  tags: Tag[] = [];

  selectedCommunications = [];
  selectedGroups = [];
  selectedTags = [];

  comInput = new FormControl();
  groupInput = new FormControl();
  tagInput = new FormControl();

  filteredComs = [];
  filteredGroups = [];
  filteredTags = [];
  genderList = [
    {
      id: GenderType.Male,
      name: 'Male'
    },
    {
      id: GenderType.Female,
      name: 'Female'
    },
    {
      id: GenderType.Unknown,
      name: 'Unknown'
    }
  ];

  personFilter: SearchFilter = {
    SearchText: '',
    getAll: true,
    paging: {
      pageNumber: 1,
      pageSize: 10
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'Name'
    }
  };

  submitted: boolean = false;
  today: Date = new Date();
  isEditPage: boolean = false;

  relationshipTypes = [
    { name: 'Brother', value: 1 },
    { name: 'Sister', value: 2 },
    { name: 'Mother', value: 3 },
    { name: 'Father', value: 4 },
    { name: 'Other', value: 5 }
  ];

  constructor(private commChannelService: CommunicationChannelService
    , private tagService: TagService
    , private groupService: GroupService
    , private careGiverService: CaregiversService
    , private toaster: ToasterService) { }

  ngOnInit(): void {
    if(this.relationshipTypeId == 0){
      this.relationshipTypeId = null;
    }
    
    if (this.caregiverId && this.caregiverId > 0) {
      this.isEditPage = true;
      this.getCareGiver(this.caregiverId);
    } else {
      this.populateDropdowns();
    }
  };

  checkDropdowns() {
    if (!(this.communications.length > 0 && this.tags.length > 0 && this.groups.length > 0)) {
      this.populateDropdowns();
    }
  }

  private populateDropdowns() {
    this.getCommunicationChannels();
    this.getTags();
    this.getGroups();

    this.comInput.valueChanges.subscribe((text) => {
      this.filterMultiList(text, 'communications', 'selectedCommunications', 'filteredComs');
    });
    this.groupInput.valueChanges.subscribe((text) => {
      this.filterMultiList(text, 'groups', 'selectedGroups', 'filteredGroups');
    });
    this.tagInput.valueChanges.subscribe((text) => {
      this.filterMultiList(text, 'tags', 'selectedTags', 'filteredTags');
    });
  }


  removeChip(comMethod, fromSource, input) {
    const index = this[fromSource].indexOf(comMethod);
    if (index >= 0) {
      this[fromSource].splice(index, 1);
      this[input].setValue('');
    }
  }

  displayNull(value) {
    return null;
  }

  selectAutoComplete(event: MatAutocompleteSelectedEvent, source, selection, input, target): void {
    const item = this[source].find(x => x.id == event.option.value);

    if (!item) {
      return;
    }
    event.option.deselect();
    this[selection].push(item);
    target.value = '';
    this[input].setValue('', { emitEvent: true });
    target.blur();
  }

  getCommunicationChannels() {
    this.commChannelService.list().subscribe((data) => {
      if (data.responseObject) {
        this.communications = data.responseObject;
        this.filterMultiList(null, 'communications', 'selectedCommunications', 'filteredComs');
      }
    })
  }

  getTags() {
    this.tagService.list().subscribe((data) => {
      if (data.responseObject) {
        this.tags = data.responseObject;
        this.filterMultiList(null, 'tags', 'selectedTags', 'filteredTags');
      }
    })
  }

  getGroups() {
    this.groupService.list(this.personFilter).subscribe((data: Response) => {
      this.groups = data.responseObject.list;
      this.filterMultiList(null, 'groups', 'selectedGroups', 'filteredGroups');
    })
  }

  getCareGiver(id: number) {
    this.careGiverService.get(id).subscribe((data: Response) => {
      if (data.responseObject) {

        if (!data.responseObject.address) {
          data.responseObject.address = new Address();
        }

        this.model = data.responseObject;

        if (this.model.cellPhone) {
          var formated_CellPhone = '(' + this.model.cellPhone.substring(0, 3) + ')' + " " + this.model.cellPhone.substring(3, 6) + "-" + this.model.cellPhone.substring(6, 11);
          this.model.cellPhone = formated_CellPhone;
        }
        if (this.model.workPhone) {
          var formated_WorkPhone = '(' + this.model.workPhone.substring(0, 3) + ')' + " " + this.model.workPhone.substring(3, 6) + "-" + this.model.workPhone.substring(6, 11);
          this.model.workPhone = formated_WorkPhone;
        }
        if (this.model.homePhone) {
          var formated_HomePhone = '(' + this.model.homePhone.substring(0, 3) + ')' + " " + this.model.homePhone.substring(3, 6) + "-" + this.model.homePhone.substring(6, 11);
          this.model.homePhone = formated_HomePhone;
        }

        this.model.tags.forEach(item => {
          this.selectedTags.push({ id: item.tag.id, name: item.tag.name })
        });

        this.model.communicationMethods.forEach(item => {
          this.selectedCommunications.push({ id: item.communicationChannel.id, name: item.communicationChannel.name })
        });

        this.model.groups.forEach(item => {
          this.selectedGroups.push({ id: item.id, name: item.name })
        });

        this.populateDropdowns();
      }
    })
  }

  save(isValid) {

    this.submitted = true;
    this.model.firstName = this.model.firstName?.replace(/^\s+|\s+$/g, '');
    this.model.middleName = this.model.middleName?.replace(/^\s+|\s+$/g, '');
    this.model.lastName = this.model.lastName?.replace(/^\s+|\s+$/g, '');
    this.model.address.line = this.model.address?.line?.replace(/^\s+|\s+$/g, '');
    this.model.address.cityName = this.model.address?.cityName?.replace(/^\s+|\s+$/g, '');
    this.model.address.stateName = this.model.address?.stateName?.replace(/^\s+|\s+$/g, '');
    
    if (!isValid || !this.relationshipTypeId || this.relationshipTypeId < 1) {
      return;
    }

    if((!this.model.cellPhone || this.model.cellPhone == '') && (!this.model.personalEmail || this.model.personalEmail == '')){
      this.toaster.showErrorMessage('Please enter either Cell phone or Personal Email');
      return;
    }

    this.model.communicationMethods = [];
    this.selectedCommunications.forEach((item) => {
      this.model.communicationMethods.push(<PersonCommunicationMethods>{
        id: item.id
      });
    });

    this.model.tags = [];
    this.selectedTags.forEach((item) => {
      this.model.tags.push(<PersonTag>{
        id: item.id
      });
    });

    this.model.groups = [];
    this.selectedGroups.forEach((item) => {
      this.model.groups.push(<GroupPerson>{
        id: item.id
      });
    });

    if (!this.model.id || this.model.id < 1) {

      this.careGiverService.create(this.model).subscribe((data: Response) => {
        if (data.isError) {
          this.toaster.showErrorMessage(data.message);
        } else {
          this.model.id = data.responseObject;
          this.emitCaregiver();
        }
      });
    } else {
      this.careGiverService.update(this.model).subscribe((data: Response) => {
        if (data.isError) {
          this.toaster.showErrorMessage(data.message);
        } else {
          this.emitCaregiver();
        }
      });
    }
  }

  private filterMultiList(text, source, selected, output) {
    this[output] = [];
    if (!text) {
      text = '';
    }

    this[source].filter(x => x.name.toLowerCase().indexOf(text) === 0).forEach((item) => {
      if (this[selected].find(x => x.id == item.id) == null) {
        this[output].push(item);
      }
    });
  }

  checkRegex(value, reg) {
    let exp = new RegExp(reg);
    if (!value.key.match(exp)) {
      value.preventDefault();
      return false;
    }
    return true;
  }

  checkZipFormat() {
    /*if(this.model.address.zipcode.length == 5)*/ {
      this.model.address.zipcode = this.model.address.zipcode;
    }
  }

  onCountryChange(event, field) {
    this['model'][field + 'Country'] = event.iso2;
    this['model'][field + 'CountryDialCode'] = event.dialCode;
  }



  emitCaregiver() {
    let personCaregiver = new PersonCaregiver();
    personCaregiver.caregiverId = this.model.id;
    personCaregiver.caregiverName = this.model.firstName;

    if (this.model.middleName && this.model.middleName != '') {
      personCaregiver.caregiverName += ' ' + this.model.middleName;
    }
    personCaregiver.caregiverName += ' ' + this.model.lastName;
    personCaregiver.personId = this.patientId;
    personCaregiver.relationshipTypeId = this.relationshipTypeId;
    personCaregiver.relationshipTypeName = this.relationshipTypes.find(x => x.value == this.relationshipTypeId).name;

    this.caregiverAdded.emit(personCaregiver);
  }

  cancel() {
    this.cancelAdd.emit();
  }
}
