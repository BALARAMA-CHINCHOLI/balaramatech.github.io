import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { paths } from 'src/app/shared/constants';

@Component({
  selector: 'app-view-patient',
  templateUrl: './view-patient.component.html',
  styleUrls: ['./view-patient.component.scss']
})
export class ViewPatientComponent implements OnInit {

  id: number;

  constructor(private router: Router
    , private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.params.subscribe(data => {
      this.id = +data['id'];
    });
  }

  editProfile() {
    this.router.navigate([paths.patientEdit + this.id]);
  }

}