import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatAutocompleteSelectedEvent } from '@angular/material/autocomplete';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { CommunicationChannelService } from 'src/app/services/communication-channel.service';
import { GroupService } from 'src/app/services/group.service';
import { PatientService } from 'src/app/services/patient.service';
import { TagService } from 'src/app/services/tag.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { ConfirmationComponent } from 'src/app/shared/components/confirmation/confirmation.component';
import { paths } from 'src/app/shared/constants';
import { GenderType } from 'src/app/shared/enums/gender-type';
import { Address } from 'src/app/shared/models/address';
import { CommunicationChannel } from 'src/app/shared/models/communication-channel';
import { Group } from 'src/app/shared/models/group';
import { GroupPerson } from 'src/app/shared/models/group-person';
import { Person } from 'src/app/shared/models/person';
import { PersonCommunicationMethods } from 'src/app/shared/models/person-communication-methods';
import { PersonTag } from 'src/app/shared/models/person-tag';
import { PersonCaregiver } from 'src/app/shared/models/personCaregiver';
import { SearchFilter } from 'src/app/shared/models/search-filter';
import { Tag } from 'src/app/shared/models/tag';
import { SuccessPopupComponent } from '../../../shared/components/success-popup/success-popup.component';
import { SortingType } from '../../../shared/enums/sorting-type';
import { Response } from '../../../shared/models/response';



@Component({
  selector: 'app-add-patient',
  templateUrl: './add-patient.component.html',
  styleUrls: ['./add-patient.component.scss']
})
export class AddPatientComponent implements OnInit {
  model: Person;
  personFilter: SearchFilter = {
    SearchText: '',
    getAll: true,
    paging: {
      pageNumber: 1,
      pageSize: 10
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'Name'
    }
  };
  communications: CommunicationChannel[] = [];
  groups: Group[] = [];
  tags: Tag[] = [];

  selectedCommunications = [];
  selectedGroups = [];
  selectedTags = [];

  comInput = new FormControl();
  groupInput = new FormControl();
  tagInput = new FormControl();

  filteredComs = [];
  filteredGroups = [];
  filteredTags = [];
  genderList = [
    {
      id: GenderType.Male,
      name: 'Male'
    },
    {
      id: GenderType.Female,
      name: 'Female'
    },
    {
      id: GenderType.Unknown,
      name: 'Unknown'
    }
  ];

  submitted: boolean = false;
  today: Date = new Date();
  isEditPage: boolean = false;

  showCaregiverList: boolean = false;
  selectedCaregiver: PersonCaregiver = null;

  constructor(private commChannelService: CommunicationChannelService
    , private tagService: TagService
    , private groupService: GroupService
    , private patientService: PatientService
    , private toaster: ToasterService
    , private router: Router
    , private route: ActivatedRoute
    , private dialog: MatDialog) { }

  ngOnInit(): void {
    this.route.params.subscribe(data => {
      const id = +data['id'];

      if (id && id > 0) {
        this.isEditPage = true;
        this.getPatient(id);
      } else {
        this.model = new Person();
      }
    })

  };

  checkDropdowns() {
    if (!(this.communications.length > 0 && this.tags.length > 0 && this.groups.length > 0)) {
      this.populateDropdowns();
    }
  }

  private populateDropdowns() {
    this.getCommunicationChannels();
    this.getTags();
    this.getGroups();

    this.comInput.valueChanges.subscribe((text) => {
      this.filterMultiList(text, 'communications', 'selectedCommunications', 'filteredComs');
    });
    this.groupInput.valueChanges.subscribe((text) => {
      this.filterMultiList(text, 'groups', 'selectedGroups', 'filteredGroups');
    });
    this.tagInput.valueChanges.subscribe((text) => {
      this.filterMultiList(text, 'tags', 'selectedTags', 'filteredTags');
    });
  }


  removeChip(comMethod, fromSource, input) {
    const index = this[fromSource].indexOf(comMethod);
    if (index >= 0) {
      this[fromSource].splice(index, 1);
      this[input].setValue('');
    }
  }

  displayNull(value) {
    return null;
  }

  selectAutoComplete(event: MatAutocompleteSelectedEvent, source, selection, input, target): void {
    const item = this[source].find(x => x.id == event.option.value);

    if (!item) {
      return;
    }
    event.option.deselect();
    this[selection].push(item);
    target.value = '';
    this[input].setValue('', { emitEvent: true });
    target.blur();
  }

  getCommunicationChannels() {
    this.commChannelService.list().subscribe((data) => {
      if (data.responseObject) {
        this.communications = data.responseObject;
        this.filterMultiList(null, 'communications', 'selectedCommunications', 'filteredComs');
      }
    })
  }

  getTags() {
    this.tagService.list().subscribe((data) => {
      if (data.responseObject) {
        this.tags = data.responseObject;
        this.filterMultiList(null, 'tags', 'selectedTags', 'filteredTags');
      }
    })
  }

  getGroups() {
    this.groupService.list(this.personFilter).subscribe((data: Response) => {
      this.groups = data.responseObject.list;
      this.filterMultiList(null, 'groups', 'selectedGroups', 'filteredGroups');
    })
  }

  getPatient(id: number) {
    this.patientService.get(id).subscribe((data) => {
      if (data.responseObject) {

        if (!data.responseObject.address) {
          data.responseObject.address = new Address();
        }

        this.model = data.responseObject;

        if (this.model.cellPhone) {
          var formated_CellPhone = '(' + this.model.cellPhone.substring(0, 3) + ')' + " " + this.model.cellPhone.substring(3, 6) + "-" + this.model.cellPhone.substring(6, 11);
          this.model.cellPhone = formated_CellPhone;
        }
        if (this.model.workPhone) {
          var formated_WorkPhone = '(' + this.model.workPhone.substring(0, 3) + ')' + " " + this.model.workPhone.substring(3, 6) + "-" + this.model.workPhone.substring(6, 11);
          this.model.workPhone = formated_WorkPhone;
        }
        if (this.model.homePhone) {
          var formated_HomePhone = '(' + this.model.homePhone.substring(0, 3) + ')' + " " + this.model.homePhone.substring(3, 6) + "-" + this.model.homePhone.substring(6, 11);
          this.model.homePhone = formated_HomePhone;
        }

        this.model.tags.forEach(item => {
          this.selectedTags.push({ id: item.tag.id, name: item.tag.name })
        });

        this.model.communicationMethods.forEach(item => {
          this.selectedCommunications.push({ id: item.communicationChannel.id, name: item.communicationChannel.name })
        });

        this.model.groups.forEach(item => {
          this.selectedGroups.push({ id: item.id, name: item.name })
        });

        this.populateDropdowns();
      }
    })
  }

  save(isValid) {

    this.submitted = true;
    this.model.firstName = this.model.firstName?.replace(/^\s+|\s+$/g, '');
    this.model.middleName = this.model.middleName?.replace(/^\s+|\s+$/g, '');
    this.model.lastName = this.model.lastName?.replace(/^\s+|\s+$/g, '');
    this.model.address.line = this.model.address?.line?.replace(/^\s+|\s+$/g, '');
    this.model.address.cityName = this.model.address?.cityName?.replace(/^\s+|\s+$/g, '');
    this.model.address.stateName = this.model.address?.stateName?.replace(/^\s+|\s+$/g, '');

    if (!isValid) {
      this.submitted = true;
      return;
    }

    this.model.communicationMethods = [];
    this.selectedCommunications.forEach((item) => {
      this.model.communicationMethods.push(<PersonCommunicationMethods>{
        id: item.id
      });
    });

    this.model.tags = [];
    this.selectedTags.forEach((item) => {
      this.model.tags.push(<PersonTag>{
        id: item.id
      });
    });

    this.model.groups = [];
    this.selectedGroups.forEach((item) => {
      this.model.groups.push(<GroupPerson>{
        id: item.id
      });
    });

    if (!this.model.id || this.model.id < 1) {

      this.patientService.create(this.model).subscribe((data) => {
        if (data.isError) {
          this.toaster.showErrorMessage(data.message);
        } else {
          let successDialog = this.dialog.open(SuccessPopupComponent, { data: { successMessage: 'Patient added successfully' } })
          successDialog.afterClosed().subscribe(res => this.router.navigate([paths.patientList]))
        }
      });
    } else {
      this.patientService.update(this.model).subscribe((data) => {
        if (data.isError) {
          this.toaster.showErrorMessage(data.message);
        } else {
          let successDialog = this.dialog.open(SuccessPopupComponent, { data: { successMessage: 'Patient updated successfully' } })
          successDialog.afterClosed().subscribe(res => this.router.navigate([paths.patientList]))
        }
      });
    }
  }

  cancel() {
    this.router.navigate([paths.patientList]);
  }

  private filterMultiList(text, source, selected, output) {
    this[output] = [];
    if (!text) {
      text = '';
    }

    this[source].filter(x => x.name.toLowerCase().indexOf(text) === 0).forEach((item) => {
      if (this[selected].find(x => x.id == item.id) == null) {
        this[output].push(item);
      }
    });
  }

  checkRegex(value, reg) {
    let exp = new RegExp(reg);
    if (!value.key.match(exp)) {
      value.preventDefault();
      return false;
    }
    return true;
  }

  checkZipFormat() {
    /*if(this.model.address.zipcode.length == 5)*/ {
      this.model.address.zipcode = this.model.address.zipcode;
    }
  }

  onCountryChange(event, field) {
    this['model'][field + 'Country'] = event.iso2;
    this['model'][field + 'CountryDialCode'] = event.dialCode;
  }

  showCaregivers() {
    this.showCaregiverList = true;
  }

  caregiverAdded(personCaregiver: PersonCaregiver) {
    const item = this.model.caregivers.find(x => x.caregiverId == personCaregiver.caregiverId);
    if (item != null) {
      const index = this.model.caregivers.indexOf(item);

      this.model.caregivers[index] = personCaregiver;
    } else {
      this.model.caregivers.push(personCaregiver);
    }
    this.showCaregiverList = false;
    this.selectedCaregiver = null;
  }

  addCaregiver() {
    this.showCaregiverList = false;
    this.selectedCaregiver = {
      caregiverId: 0,
      id: 0,
      personId: this.model.id,
      caregiverName: '',
      relationshipTypeId: 0,
      relationshipTypeName: ''
    };
  }

  editCaregiver(item) {
    this.selectedCaregiver = item;
  }

  deleteCaregiver(index) {
    let statusSwitch = this.dialog.open(ConfirmationComponent, {
      data: {
        message: 'Are you sure you want to remove this caregiver from Patient?',
        icon: 'warning',
        action: 'Delete',
      },
      width: '30vw',
    });
    statusSwitch.afterClosed().subscribe((result) => {
      if (result) {
        this.model.caregivers.splice(index, 1);
      }
    });
  }

  cancelAddCaregiver() {
    this.showCaregiverList = false;
    this.selectedCaregiver = null;
  }

  cancelList() {
    this.showCaregiverList = false;
  }

  getAlias(name) {
    if (!name) {
      return '';
    }

    return name.substring(0, 1);
  }
}
