import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { SharedModule } from '../shared/shared.module';
import { ComunityComponent } from './comunity.component';
import { routes } from './comunuty-routing.module';
import { GroupsComponent } from './groups/groups.component';

@NgModule({
  declarations: [
    GroupsComponent,
    ComunityComponent,
  ],
  imports: [
    CommonModule,
    SharedModule,
    RouterModule,
    RouterModule.forChild(routes),
  ],
})
export class ComunityModule {}
