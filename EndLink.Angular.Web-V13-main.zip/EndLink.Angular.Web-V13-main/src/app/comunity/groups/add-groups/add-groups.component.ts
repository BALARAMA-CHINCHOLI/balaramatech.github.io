import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { MatTableDataSource } from '@angular/material/table';
import { ActivatedRoute, Router } from '@angular/router';
// import { group } from 'console';
import { EmployeeService } from 'src/app/services/employee.service';
import { GroupService } from 'src/app/services/group.service';
import { PatientService } from 'src/app/services/patient.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { AddGroup, Group ,Search} from 'src/app/shared/models/group';
import { GenderType } from 'src/app/shared/enums/gender-type';
import * as _ from 'lodash'
import { SuccessPopupComponent } from '../../../shared/components/success-popup/success-popup.component';
import { SearchFilter } from '../../../shared/models/search-filter';
import { MembersService } from 'src/app/services/members.service';
import { CampaignService } from 'src/app/services/campaign.service';

declare var $: any;

@Component({
  selector: 'app-add-groups',
  templateUrl: './add-groups.component.html',
  styleUrls: ['./add-groups.component.scss']
})
export class AddGroupsComponent implements OnInit, OnDestroy {
  searchResults = [];
  memberType = 'patient';
  searchTerm = '';
  name='';
  description='';
  check:boolean;
  id:any;
  duplicate:boolean = false;
  isActive:Boolean;
  selectedData = [];
  memberFilter = new Search();
  model:Group = new Group();
  group = <Group>{};
  jsonObject = <AddGroup>{};
  jsonObjectValue: AddGroup = <AddGroup>{};
  files = [];
  isFilterOpen = false;
  groupFilter = new SearchFilter();
  genderList = [
    {
      id: GenderType.Male,
      name: 'Male',
    },
    {
      id: GenderType.Female,
      name: 'Female',
    },
    {
      id: GenderType.Unknown,
      name: 'Unknown',
    },
  ];
  submitted:boolean = false;
  isDisabled: boolean = false;
  isUpdate: boolean;
  data: boolean;
  selectedTab = 'searchadd';
  constructor(
    private groupService: GroupService,
    private patientService: PatientService,
    private employeeService: EmployeeService,
    private toastr: ToasterService,
    private dialog: MatDialog,
    private router: Router,
    private route: ActivatedRoute,
    private membersService: MembersService,
    private campaignService: CampaignService
  ) { }

  ngOnInit(): void {
    this.route.params.subscribe(param => {
      if (!!param?.id) {
        this.getGroupDetails(param.id);
        this.id = param.id
        this.isUpdate = true;
        this.check = true;
      }

    });
    if (this.id != null)
      this.groupFilter.paging = {
        pageNumber: 1,
        pageSize: 10,
      };
    this.groupService.bulkGroupsList.subscribe((values) => {
      this.searchMember();
      this.searchResults.forEach((result) => {
        result.selected = !!values.find((value) => result.id == value.id);
      });
    });

    this.groupService.bulkGroups.subscribe((files) => {
      const selectedFiles = files;
      this.files = selectedFiles.map((file) => ({
        ...file,
        name: file.fileName || file.name,
      }));
    });

    this.membersService.selectedMembers.subscribe( values => {
      this.selectedData = values;
      this.searchResults.forEach(match => {
        const matchedMember = values.find(member => match.id == member.id);
        match.selected = !!matchedMember;
      });
    })

  }
  search(event){
    this.searchTerm = event.target.value;

  }

  toggleFilter(): void {
    this.isFilterOpen = !this.isFilterOpen;
  }

  getGroupDetails(Id: number){
    this.groupService.getGroup(Id).subscribe(
      (res) => {
        this.jsonObjectValue = res.responseObject;
        this.model = res.responseObject;
        this.name = this.model.name;
        this.description = this.model.description;
        this.isActive = this.model.isActive;
        this.membersService.selectedMembers.next(this.model.persons);
        this.campaignService.isRecipientsUpdated = true;
        const groupUploads = res.responseObject.files.map((file) => ({
          ...file,
          FileUrl: file.fileUrl,
        }));
        this.groupService.bulkGroups.next(
          groupUploads
        );

        },
      (err) => {
        this.toastr.showErrorMessage(err.message);
      }
    );
  }
  searchMember() {
    if (!!this.memberType) {
      this.memberFilter.term = this.searchTerm;
      switch (this.memberType) {
        case 'patient':
          this.patientService.list(this.memberFilter).subscribe(
            (res) => {
              this.searchResults = res.responseObject.list.map(patient => {
                const selectedMember = this.selectedData.find(member => member.id === patient.id);
                return {...patient, selected: !!selectedMember};
              });
              this.check = false;
            },
            (err) => {
              this.toastr.showErrorMessage(err.message);
            }
          );
          break;
        case 'employee':
          this.employeeService.list(this.memberFilter).subscribe(
            (res) => {
              this.searchResults = res.responseObject.list;
              this.check = false;
            },
            (err) => {
              this.toastr.showErrorMessage(err.message);
            }
          );
          break;
      }
    } else {
      this.toastr.showErrorMessage('Error, Please select member type');
    }
  }

  updateSelectedMember(event, member, cbselected) {
    member.selected = !member.selected;
    if (event == true) {
      this.selectedData.push(member);
    }
     else {
       const existingSelection = this.selectedData.findIndex(record => record.id === member.id);
       if(existingSelection != -1) {
        this.selectedData.splice(existingSelection, 1);
            return;
       }
    }
    this.membersService.selectedMembers.next(this.selectedData);
    this.campaignService.isRecipientsUpdated = true;
  }
  // updateSelectedMember1(event, name, cbselected) {
  //   if (event.path[0].selected == true) {
  //     this.selectedData.push(name);
  //   }  else {
  //     if (this.selectedData.length > 0) {
  //       for (var i = 0; i < this.selectedData.length; i++) {
  //         if (this.selectedData[i].firstName == name.firstName) {
  //           this.selectedData.splice(i, 1);
  //           return;
  //         }
  //       }
  //     }
  //   }
  // }
  space(event){
    this.name=this.name.replace(/^\s+|\s+$/g, '');
    this.description=this.description.replace(/^\s+|\s+$/g, '');
    if (this.name.length==null) {
      this.data = false;
    }
  }
  submit(isValid){
    this.submitted = true;
    // this.name=this.name.replace(/^\s+|\s+$/g, '');
    // this.description=this.description.replace(/^\s+|\s+$/g, '');
    if (isValid) {
      if ( this.selectedTab == 'searchadd' && ( !this.selectedData || this.selectedData.length < 1)) {
        this.toastr.showErrorMessage("Please add patient or employee to the group");
        return;
      }
      this.submitted = true;
        if (this.isUpdate && this.duplicate == false) {
          this.group.id = this.id;
          this.group.name = this.name;
          this.group.isActive = Boolean(this.isActive);
          this.group.description = this.description;
          this.group.persons = this.selectedData;
          this.group.files = this.groupService.bulkGroups.value.map(file => ({ ...file, isUploaded: false }));
          this.jsonObject = this.group;
          this.groupService.update(this.jsonObject).subscribe((res: any) => {
            this.submitted = false;
            if (!res.isError) {
              let successDialog = this.dialog.open(SuccessPopupComponent, { data: { successMessage: 'Group updated successfully' } });
              successDialog.afterClosed().subscribe(res => this.router.navigate(['/comunity/groups']));
              this.selectedData = [];
              this.membersService.selectedMembers.next([]);
              this.campaignService.isRecipientsUpdated = true;
            } else {
              this.toastr.showErrorMessage(res.message);
            }
          });
        } else if (this.duplicate == false) {

          this.group.name = this.name;
          this.group.description = this.description;
          this.group.persons = this.selectedData;
          this.group.files = this.groupService.bulkGroups.value;
          this.jsonObject = this.group;
          this.groupService.create(this.jsonObject).subscribe((res: any) => {
            this.submitted = false;
            if (!res.isError) {
              let successDialog = this.dialog.open(SuccessPopupComponent, { data: { successMessage: 'Group added successfully' } });
              successDialog.afterClosed().subscribe(res => this.router.navigate(['/comunity/groups']))
            } else {
              this.toastr.showErrorMessage(res.message);
            }
          });
        }
    }
  }
   clearSearch() {
    this.memberFilter = new Search();
    this.searchMember();
  }
  back() {
    window.history.back();
  }
  downloadSample() {
    this.groupService.donwloadSample().subscribe((res) => {
      window.open(res.responseObject, '_blank').focus();
    });
  }

  onFileDropped(event) {
    this.files = this.files.concat(Object.values(event));
    var ext = this.files[0].name.substring(this.files[0].name.lastIndexOf('.') + 1);
    if (ext.toLowerCase() == 'csv' || this.files[0].name == null) {
      this.isValidFile = true;
      this.uploadFile({ files: event });
    }
    else {
      this.isValidFile = false;
    }
  }

  isValidFile: boolean = true;

  fileBrowseHandler(files) {
    this.files = this.files.concat([...files.target.files]);
    var ext = this.files[0].name.substring(this.files[0].name.lastIndexOf('.') + 1);
    if (ext.toLowerCase() == 'csv' || this.files[0].name == null) {
      this.isValidFile = true;
      this.uploadFile(files.target);
    }
    else {
      this.isValidFile = false;
    }

  }

  getHeaderArray(csvRecordsArr: any): any[] {
    const headers = (csvRecordsArr[0]).split(',');
    const headerArray = [];
    for (const header of headers) {
      headerArray.push(header);
    }
    return headerArray;
  }

  uploadFile(file) {
    if (!!file) {
      const reader = new FileReader();
      reader.readAsText(file.files[0]);
      var fileType = file;
      var fileExt = fileType.accept.substring(fileType.accept.lastIndexOf('.') + 1);
      var ext = file.value.substring(file.value.lastIndexOf('.') + 1);
      if (ext.toLowerCase() == 'csv') {
        this.isValidFile = true;
        reader.onload = () => {
          const csvData = reader.result;
          const csvRecordsArray = (csvData as string).split('\n').length;
          this.groupService.fileUpload(file.files[0], 'group').subscribe(
            (res) => {
              file.url = res.responseObject;
              this.groupService.bulkGroups.next([
                { name: file.files[0].name, FileUrl: res.responseObject, totalCount: (csvRecordsArray - 2), isUploaded: true },
              ]);
            },
            (err) => {
              this.toastr.showErrorMessage(err.message);
            }
          );
        };
      }
      else {
        this.isValidFile = false;
      }
    }
  }

  //file upload js starts
  readURL(input) {
    if (input.files && input.files[0]) {
      var reader = new FileReader();

      reader.onload = function (e) {
        $('.file-upload-image').attr('src', e.target.result);

        $('.image-title').html(input.files[0].name);
      };

      reader.readAsDataURL(input.files[0]);
    } else {
    }
  }

  removeUpload(index) {
    this.files.splice(index, 1);
    this.groupService.bulkGroups.next([]);
  }

  downloadCSV() {
    this.groupService.donwload(
      this.groupService.bulkGroups.value[0].FileUrl
    );
  }

  ngOnDestroy(): void {
    this.groupService.bulkGroups.next([]);
    this.membersService.selectedMembers.next([]);
    this.campaignService.isRecipientsUpdated = true;
  }
}

