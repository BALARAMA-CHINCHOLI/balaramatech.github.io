import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddGroupsComponent } from './add-groups/add-groups.component';
import { GroupsComponent } from './groups.component';
import { ViewGroupsComponent } from './view-groups/view-groups.component';

const routes: Routes = [
  {
    path : '',
    component: GroupsComponent,
    pathMatch: 'full'
  },
  {
    path: 'add',
    component: AddGroupsComponent,
    data: { breadcrumb: 'Add Group', title: 'Add Group', isSinglePage: true }
  },
  {
    path: 'edit/:id',
    component: AddGroupsComponent,
    data: { breadcrumb: 'Edit Groups', title:'Edit Groups', isSinglePage:true }
  },
  {
    path: 'view/:id',
    component: ViewGroupsComponent,
    data: { breadcrumb: 'View Groups' , title:'View Groups' }
  },
{
  path : '**',
  redirectTo : ''
}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class GroupsRoutingModule { }
