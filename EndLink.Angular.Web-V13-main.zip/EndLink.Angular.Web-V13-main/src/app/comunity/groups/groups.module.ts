import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { GroupsRoutingModule } from './groups-routing.module';
import { ViewGroupsComponent } from './view-groups/view-groups.component';
import { AddGroupsComponent } from './add-groups/add-groups.component';
import { SharedModule } from 'src/app/shared/shared.module';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AddCampaignSharedModule } from 'src/app/shared/modules/add-campaign-shared/add-campaign-shared.module';


@NgModule({
  declarations: [ViewGroupsComponent, AddGroupsComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    SharedModule,
    GroupsRoutingModule,
    AddCampaignSharedModule
  ]
})
export class GroupsModule { }
