import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { GroupService } from 'src/app/services/group.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { AddGroup, Group, Search } from 'src/app/shared/models/group';

@Component({
  selector: 'app-view-groups',
  templateUrl: './view-groups.component.html',
  styleUrls: ['./view-groups.component.scss']
})
export class ViewGroupsComponent implements OnInit {

  searchResults = [];
  memberType = '';
  searchTerm = '';
  name='';
  description='';
  selectedData = [];
  memberFilter = new Search();
  model:Group = new Group();
  group = <Group>{};
  jsonObject = <AddGroup>{};
  jsonObjectValue: AddGroup = <AddGroup>{};
  isDisabled: boolean = false;
  constructor(
    private groupService: GroupService,
    private router: Router,
    private toastr: ToasterService,
    private route: ActivatedRoute
  ) { }

  ngOnInit(): void {
    this.route.params.subscribe(param => {
      if (!!param?.id) {
        this.getGroupDetails(param.id);
        // this.isUpdate = true;
        this.isDisabled = (this.route.snapshot.url.join().split(',')[0] != 'edit');
      }
    });
  }
  getGroupDetails(Id: number){
    this.groupService.getGroup(Id).subscribe(
      (res) => {
        // this.searchResults = res.responseObject.list 
        this.jsonObjectValue = res.responseObject;
        this.model = res.responseObject;
        this.name = this.model.name;
        this.description = this.model.description;
        this.selectedData = this.model.persons;           },
      (err) => {
        this.toastr.showErrorMessage(err.message);
      }
    );
  }
  back() {
    window.history.back();
  }
}
