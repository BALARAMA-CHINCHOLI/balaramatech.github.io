import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { ExcelService } from 'src/app/services/excel.service';
import { GroupService } from 'src/app/services/group.service';
import { ScrollerService } from 'src/app/services/scroller-service.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { ConfirmationComponent } from 'src/app/shared/components/confirmation/confirmation.component';
import { messages, paths } from 'src/app/shared/constants';
import { SortingType } from 'src/app/shared/enums/sorting-type';
import { Group } from 'src/app/shared/models/group';
import { ListModel } from 'src/app/shared/models/list-model';
import { SearchFilter } from 'src/app/shared/models/search-filter';

@Component({
  selector: 'app-groups',
  templateUrl: './groups.component.html',
  styleUrls: ['./groups.component.scss'],
})
export class GroupsComponent implements OnInit {
  filter: SearchFilter = {
    SearchText: '',
    getAll: false,
    paging: {
      pageNumber: 1,
      pageSize: 10,
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'Name',
    },
  };

  list: ListModel<Group> = {
    list: [],
    hasNextPage: false,
  };
  public exportList: any[] = [];

  list$: any;
  scroller$: any;
  titleActions = [{ name: 'Add Groups', url: paths.groupCreate }];

  constructor(
    private router: Router,
    private scroller: ScrollerService,
    private groupService: GroupService,
    private toaster: ToasterService,
    private dialog: MatDialog,
    private excelService: ExcelService
  ) {}

  private header_data: any[] = [
    {
      title: 'Name',
      type: 'text',
      prop: 'name',
      sortProp: 'name',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Description',
      type: 'text',
      prop: 'description',
      sortProp: 'description',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Members',
      type: 'text',
      prop: 'memberCount',
      sortProp: 'memberCount',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Status',
      type: 'slide',
      prop: 'isActive',
      sortProp: 'isActive',
      sort: false,
      isFilter: false,
    },
  ];

  tableData: any = {
    headerData: [],
    rowData: [],
    noRecordFound: true,
  };

  ngOnInit() {
    this.tableData.noRecordFound = true;
    this.tableData.headerData = this.header_data;
    this.scroller$ = this.scroller.scroller$
      .pipe
      //throttle(ev => this.employeeList$)
      ()
      .subscribe((res) => {
        if (this.list.hasNextPage) {
          this.filter.paging.pageNumber++;
          this.getList();
        }
      });

    this.getList();
  }

  tableActions(event) {
    switch (event.action) {
      case 'view': {
        this.groupService.selectedGroup = event.rowData;
        this.router.navigate([paths.groupView + event.rowData.id], {
          queryParams: { type: 'view' },
        });
        break;
      }
      case 'edit': {
        this.groupService.selectedGroup = event.rowData;
        this.router.navigate([paths.groupEdit + event.rowData.id], {
          queryParams: { type: 'edit' },
        });
        break;
      }
      case 'navigate': {
        this.router.navigate([event.rowData.url]);
      }
      case 'download': {
        const item = this.list.list.find((x) => x.id == event.rowData.id);

        if (item == null) {
          return;
        }

        this.download(item.id);
        break;
      }
      case 'delete': {
        const item = this.list.list.find((x) => x.id == event.rowData.id);

        if (item == null) {
          return;
        }
        let del = this.dialog.open(ConfirmationComponent, {
          data: {
            message: 'Are you sure you want to delete?',
            icon: 'warning',
            action: 'Delete',
          },
          width: '30vw',
        });
        del.afterClosed().subscribe((result) => {
          if (result) {
            this.delete(item.id);
          } else {
            event.rowData.id = !event.rowData.id;
          }
        });
        break;
      }
      case 'sort': {
        this.filter.paging.pageNumber = 1;
        this.filter.sorting = {
          order: event.filterData.sortOrder,
          sortBy: event.filterData.sortHeader,
        };

        this.getList();
        break;
      }
      case 'switch': {
        const item = this.list.list.find((x) => x.id == event.rowData.id);

        if (item == null) {
          return;
        }

        let statusSwitch = this.dialog.open(ConfirmationComponent, {
          data: {
            message: 'Are you sure you want to change this status?',
            icon: 'warning',
            action: 'Update',
          },
          width: '30vw',
        });
        statusSwitch.afterClosed().subscribe((result) => {
          if (result) {
            this.changeStatus(item);
          } else {
            event.rowData.isActive = !event.rowData.isActive;
          }
        });
        break;
      }
      case 'search': {
        this.filter.SearchText = event.filterData.globalSearch;
        this.filter.paging.pageNumber = 1;
        this.getList();
        break;
      }
      case 'clear': {
        this.filter.SearchText = '';
        this.filter.paging.pageNumber = 1;
        this.getList();
        break;
      }
    }
  }

  getList() {
    this.list$ = this.groupService.list(this.filter).subscribe((data) => {
      if (this.filter.paging.pageNumber == 1) {
        this.list = data.responseObject;
        this.tableData.rowData = [];
      } else {
        data.responseObject.list.forEach((item) => {
          this.list.list.push(item);
        });
      }

      this.tableData.rowData = this.list.list;

      if (this.list.list.length > 0) {
        this.tableData.noRecordFound = false;
      }

      this.list.hasNextPage =
        data.responseObject.list && data.responseObject.list.length > 0;
    });
  }

  public changeStatus(item: Group) {
    this.groupService.updateStatus(item).subscribe(() => {
      /*this.toaster.showSuccessMessage(messages.statusChangedSuccess);*/
    });
  }

  public delete(id: number) {
    this.groupService.delete(id).subscribe(() => {
      this.getList();
    });
  }

  public download(id: number) {
    this.groupService.download(id).subscribe((data) => {
      this.exportList = data.responseObject;
      setTimeout(() => {
        this.excelService.exportAsExcelFile('printtable', 'Group');
      }, 500);
    });
  }

  public ngOnDestroy() {
    this.list$.unsubscribe();
    this.scroller$.unsubscribe();
  }
}
