import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { paths } from 'src/app/shared/constants';

@Component({
  selector: 'app-view-employee',
  templateUrl: './view-employee.component.html',
  styleUrls: ['./view-employee.component.scss']
})
export class ViewEmployeeComponent implements OnInit {

  id: number;

  constructor(private router: Router
    , private route: ActivatedRoute) { }

  ngOnInit(): void {
    this.route.params.subscribe(data => {
      this.id = +data['id'];
    });
  }

  editProfile() {
    this.router.navigate([paths.employeeEdit + this.id]);
  }

}
