import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { AuthGuard } from 'src/app/shared/helpers/auth.guard';
import { AddEmployeeComponent } from './add-employee/add-employee.component';
import { EmployeeComponent } from './employee.component';
import { ViewEmployeeComponent } from './view-employee/view-employee.component';

const routes: Routes = [
    {
        path: '',
        component: EmployeeComponent,
        pathMatch: 'full',
        canActivate: [AuthGuard]
    },
    {
        path: 'add',
        component: AddEmployeeComponent,
        data: { breadcrumb: 'Add Employee' , title:'Add Employee'},
        canActivate: [AuthGuard]
    },
    {
        path: 'edit/:id',
        component: AddEmployeeComponent,
        data: { breadcrumb: 'Edit Employee' ,title: 'Edit Employee',},
        canActivate: [AuthGuard]
    },
    {
        path: 'view/:id',
        component: ViewEmployeeComponent,
        data: { breadcrumb: 'View Employee' , title:'View Employee' },
        canActivate: [AuthGuard]
    },
    {
        path: '**',
        redirectTo: ''
    }
];

@NgModule({
    imports: [RouterModule.forChild(routes)],
    exports: [RouterModule]
})
export class EmployeeRoutingModule { }
