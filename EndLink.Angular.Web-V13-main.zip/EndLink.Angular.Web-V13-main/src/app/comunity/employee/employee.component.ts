import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { EmployeeService } from 'src/app/services/employee.service';
import { ScrollerService } from 'src/app/services/scroller-service.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { ConfirmationComponent } from 'src/app/shared/components/confirmation/confirmation.component';
import { messages, paths } from 'src/app/shared/constants';
import { SortingType } from 'src/app/shared/enums/sorting-type';
import { ListModel } from 'src/app/shared/models/list-model';
import { Person } from 'src/app/shared/models/person';
import { PersonFilter } from 'src/app/shared/models/person-filter';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.scss'],
})
export class EmployeeComponent implements OnInit {
  filter: PersonFilter = {
    searchText: '',
    paging: {
      pageNumber: 1,
      pageSize: 10,
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'Name',
    },
  };

  list: ListModel<Person> = {
    list: [],
    hasNextPage: false,
  };

  employeeList$: any;
  scroller$: any;
  titleActions = [{ name: 'Add Employees', url: paths.employeeAdd }];

  constructor(
    private router: Router,
    private scroller: ScrollerService,
    private employeeService: EmployeeService,
    private toaster: ToasterService,
    private dialog: MatDialog
  ) {}

  private header_data: any[] = [
    {
      title: 'Member ID',
      type: 'text',
      prop: 'patientId',
      sortProp: 'id',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'First Name',
      type: 'text',
      prop: 'firstName',
      sortProp: 'firstName',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Last Name',
      type: 'text',
      prop: 'lastName',
      sortProp: 'lastName',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Cell Phone',
      type: 'text',
      prop: 'cellPhone',
      sortProp: 'cellPhone',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Email',
      type: 'text',
      prop: 'email',
      sortProp: 'email',
      sort: true,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Channels',
      type: 'array',
      prop: 'channels',
      sortProp: 'channels',
      sort: false,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Groups',
      type: 'text',
      prop: 'groups',
      sortProp: 'groups',
      sort: false,
      isFilter: true,
      isAsc: false,
      isDes: false,
    },
    {
      title: 'Status',
      type: 'slide',
      prop: 'isActive',
      sortProp: 'isActive',
      sort: false,
      isFilter: false,
    },
  ];

  tableData: any = {
    headerData: [],
    rowData: [],
    noRecordFound: true,
  };

  ngOnInit() {
    this.tableData.noRecordFound = true;
    this.tableData.headerData = this.header_data;
    this.scroller$ = this.scroller.scroller$.subscribe((res) => {
      if (this.list.hasNextPage) {
        this.filter.paging.pageNumber++;
        this.getemployees();
      }
    });
    this.getemployees();
    //this.scroller$ = this.scroller.scroller$.subscribe((res) => {
    //  if (this.list.hasNextPage) {
    //    this.filter.paging.pageNumber++;
    //    this.getemployees();
    //  }
    //});
  }

  tableActions(event) {
    switch (event.action) {
      case 'view': {
        this.router.navigate([paths.employeeView + event.rowData.id]);
        break;
      }
      case 'edit': {
        this.router.navigate([paths.employeeEdit + event.rowData.id]);
        break;
      }
      case 'navigate': {
        this.router.navigate([event.rowData.url]);
      }
      case 'sort': {
        this.filter.paging.pageNumber = 1;
        this.filter.sorting = {
          order: event.filterData.sortOrder,
          sortBy: event.filterData.sortHeader,
        };

        this.getemployees();
        break;
      }
      case 'switch': {
        const employee = this.list.list.find((x) => x.id == event.rowData.id);

        if (employee == null) {
          return;
        }

        let statusSwitch = this.dialog.open(ConfirmationComponent, {
          data: {
            message: 'Are you sure you want to change this status?',
            icon: 'warning',
            action: 'Update',
          },
          width: '30vw',
        });
        statusSwitch.afterClosed().subscribe((result) => {
          if (result) {
            this.changeStatus(employee);
          } else {
            event.rowData.isActive = !event.rowData.isActive;
          }
        });
        break;
      }
      case 'search': {
        this.filter.searchText = event.filterData.globalSearch;
        this.filter.paging.pageNumber = 1;
        this.getemployees();
        break;
      }
      case 'clear': {
        this.filter.searchText = '';
        this.filter.paging.pageNumber = 1;
        this.getemployees();
        break;
      }
    }
  }

  search() {
    this.filter.paging.pageNumber = 1;
    this.getemployees();
  }

  getemployees() {
    this.employeeList$ = this.employeeService
      .list(this.filter)
      .subscribe((data) => {
        if (this.filter.paging.pageNumber == 1) {
          this.list = data.responseObject;
          this.tableData.rowData = [];
        } else {
          data.responseObject.list.forEach((item) => {
            this.list.list.push(item);
          });
        }

        const tableData = [];
        this.list.list.forEach((item) => {
          tableData.push(this.parseTableData(item));
        });

        this.tableData.rowData = tableData;

        if (this.list.list.length > 0) {
          this.tableData.noRecordFound = false;
        }

        this.list.hasNextPage =
          data.responseObject.list && data.responseObject.list.length > 0;
      });
  }

  public changeStatus(employee: Person) {
    employee.isActive = !employee.isActive;

    this.employeeService.updateStatus(employee).subscribe((x) => {
      if(!x.isError)
      this.toaster.showSuccessMessage(messages.statusChangedSuccess);
      else
      this.toaster.showErrorMessage("An error occured.");
    });
  }

  private parseTableData(person: Person) {
    const channels = [];

    person.communicationMethods.forEach((item) => {
      channels.push({ id: item.id, name: item.communicationChannel.name });
    });

    return {
      id: person.id,
      patientId: person.patientId,
      firstName: person.firstName,
      lastName: person.lastName,
      cellPhone: person.cellPhone,
      email: person.personalEmail,
      channels: channels,
      groups: person.groups.length,
      isActive: person.isActive,
    };
  }

  public ngOnDestroy() {
    this.employeeList$.unsubscribe();
    this.scroller$.unsubscribe();
  }
}
