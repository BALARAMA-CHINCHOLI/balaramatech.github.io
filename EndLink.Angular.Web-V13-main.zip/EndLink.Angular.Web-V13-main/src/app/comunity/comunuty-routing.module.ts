import { Routes } from '@angular/router';
import { ComunityComponent } from './comunity.component';


export const routes: Routes = [
  {
    path: 'members',
    component: ComunityComponent,
    data: {
      breadcrumb: 'Members'
    },
    children: [
      {
        path: 'patients',
        loadChildren: () => import('./patients/patients.module').then(m => m.PatientsModule),
        data: {
          breadcrumb: 'Patients',
          url : '/comunity/members/patients',
          title: 'Patients'
        }
      },
      { 
        path : 'employee',
        loadChildren: () => import('./employee/employee.module').then(m => m.EmployeeModule),
        data: {
          breadcrumb : 'Employees',
          url : '/comunity/members/employee',
          title: 'Employees'
        }
      },
      {
        path : '',
        redirectTo: 'patients',
        pathMatch: 'full'
      }
    ]
  },
  { 
    path : 'groups',
    loadChildren: () => import('./groups/groups.module').then(m => m.GroupsModule),
    data: {
      breadcrumb : 'Groups',
      url : '/comunity/groups',
      title: 'Groups'
    }
  },
  {
    path : '',
    redirectTo: 'members',
    pathMatch : 'full'
  }
  // {
  //   path:'about/:id',
  //   component: TemplateComponent,
  //   resolve: { data:DashboarResolver},
  // }
];

// @NgModule({
//   imports: [RouterModule.forChild(routes)],
//   exports: [RouterModule]
// })
// export class ComunityRoutingModule { }