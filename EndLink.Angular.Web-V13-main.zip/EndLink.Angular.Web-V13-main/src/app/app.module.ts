import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { DemoMaterialModule } from './material.module';
import { FormsModule } from '@angular/forms';
import { httpInterceptorProviders } from './shared/interceptor';
import { HttpClientModule } from '@angular/common/http';
import { ChartsModule } from 'ng2-charts';
import { DatePipe, HashLocationStrategy, LocationStrategy } from '@angular/common';
import { NgxMaskModule, IConfig } from 'ngx-mask';
import { OwlModule } from 'ngx-owl-carousel';

import {MatInputModule} from '@angular/material/input';
import {Ng2TelInputModule} from 'ng2-tel-input';
import { CKEditorModule } from '@ckeditor/ckeditor5-angular';
import { DateAdapter } from '@angular/material/core';
import { CustomMomentDateAdapter } from './services/custom-date-adapter.service';



export const options: Partial<IConfig> | (() => Partial<IConfig>) = null;

@NgModule({
  declarations: [
    AppComponent
   ],
  imports: [
    BrowserModule,
   FormsModule,
    BrowserAnimationsModule,
    AppRoutingModule,
    MatInputModule,
    HttpClientModule,
    Ng2TelInputModule,
    CKEditorModule,
    DemoMaterialModule,
    ChartsModule,
    NgxMaskModule.forRoot(),
    OwlModule
  ],
  providers: [
              httpInterceptorProviders,
              DatePipe,
              {provide: LocationStrategy, useClass: HashLocationStrategy},
              { provide: DateAdapter, useClass: CustomMomentDateAdapter }
            ],
  bootstrap: [AppComponent]
})
export class AppModule { }
