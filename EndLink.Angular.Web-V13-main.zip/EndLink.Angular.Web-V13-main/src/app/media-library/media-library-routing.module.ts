import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { MediaLibraryComponent } from './mediaLibrary.component';

const routes: Routes = [
  {
    path : '',
    component: MediaLibraryComponent,
    children: [
      {
        path : 'audio',
        loadChildren: () => import('./audio/audio.module').then(m => m.AudioModule),
        data: {
          breadcrumb: 'Audio',
          title: 'Audio'
        }
      },
      {
        path : 'htmlTemplate',
        loadChildren: () => import('./html-template/html-template.module').then(m => m.HtmlTemplateModule),
        data: {
          breadcrumb : 'HTML Template',
          title: 'HTML Templates'
        }
      },
      {
        path : '',
        redirectTo: 'audio',
        pathMatch: 'full'
      }
    ]
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class MediaLibraryRoutingModule { }
