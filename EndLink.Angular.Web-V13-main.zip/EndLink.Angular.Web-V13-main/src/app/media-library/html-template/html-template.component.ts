import { Clipboard } from '@angular/cdk/clipboard';
import { AfterViewInit, Component, OnDestroy, OnInit, ViewChild } from '@angular/core';
import { Router } from '@angular/router';
import { fromEvent } from 'rxjs';
import { debounceTime } from 'rxjs/operators';
import { CategoryService } from 'src/app/services/category.service';
import { TemplateService } from 'src/app/services/dataServices/template.service';
import { ScrollerService } from 'src/app/services/scroller-service.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { messages, paths } from 'src/app/shared/constants';
import { Category } from 'src/app/shared/models/category';
import { ListModel } from 'src/app/shared/models/list-model';
import { Template } from 'src/app/shared/models/template';
import { TemplateFilter } from 'src/app/shared/models/template-filter';

@Component({
  selector: 'app-html-template',
  templateUrl: './html-template.component.html',
  styleUrls: ['./html-template.component.scss']
})
export class HtmlTemplateComponent implements OnInit, OnDestroy, AfterViewInit {
  serviceSearch = '';
  templateFilter: TemplateFilter = {
    paging: {
      pageNumber: 1,
      pageSize: 8
    },
    sorting: {
      order: 1,
      sortBy: 'name'
    },
    IsActive: true
  };
  scroller$: any;
  list: ListModel<Template> = {
    list: [],
    hasNextPage: false
  };
  searchSubscription$: any;
  @ViewChild('search') search;

  categories: Category[] = [];

  constructor(private templateService: TemplateService
    , private scroller: ScrollerService
    , private router: Router
    , private categoryService: CategoryService
    , private toaster: ToasterService) { }

  ngOnInit(): void {
    this.getCategories();
    this.getTemplates();
    this.scroller$ = this.scroller.scroller$.subscribe(res => {
      if (this.list.hasNextPage) {
        this.templateFilter.paging.pageNumber++;
        this.getTemplates();
      }
    });
  }

  ngAfterViewInit() {
    this.searchSubscription$ = fromEvent(this.search.nativeElement, 'input').pipe(debounceTime(700))
      .subscribe(res => {
        this.templateFilter.SearchText = this.serviceSearch;
        this.getTemplates();
      }
      );
  }

  searchTemplates() {
    this.templateFilter.paging.pageNumber = 1;
    this.getTemplates();
  }

  clearSearch() {
    this.serviceSearch = '';
    this.templateFilter.SearchText = this.serviceSearch;
    this.getTemplates();
  }

  getTemplates() {
    this.templateService.list(this.templateFilter).subscribe((res: any) => {
      if (!res.isError) {

        if (this.templateFilter.paging.pageNumber == 1) {
          this.list = res.responseObject;
        } else {
          res.responseObject.list.forEach(item => {
            this.list.list.push(item);
          });
        }

        this.list.hasNextPage = res.responseObject.list && res.responseObject.list.length > 0;
      }
    });
  }

  copyTemplate(template) {
    this.router.navigate([paths.templateCopy + '/' + template.id]);
  }

  addTemplate() {
    this.router.navigate([paths.templateAdd]);
  }

  editTemplate(template) {
    this.router.navigate([paths.templateEdit + '/' + template.id]);
  }

  getCategories() {
    this.categoryService.categories.subscribe(res => {
      this.categories = res;
    });
  }

  filterByCategory() {
    if (this.templateFilter.categoryId && this.templateFilter.categoryId > 0) {
      const category = this.categories.find(x => x.id == this.templateFilter.categoryId);
      this.templateFilter.categoryName = category.name;
    }

    this.templateFilter.paging.pageNumber = 1;
    this.getTemplates();
  }

  archive(template: Template) {
    template.isActive = false;
    this.templateService.update(template).subscribe((res: any) => {
      if (!res.isError) {
        this.toaster.showSuccessMessage(messages.templateArchiveSuccess);
        this.templateFilter.paging.pageNumber = 1;
        this.getTemplates();
      } else {
        this.toaster.showErrorMessage(res.message);
      }
    });
  }

  public ngOnDestroy() {
    this.scroller$.unsubscribe();
  }

}
