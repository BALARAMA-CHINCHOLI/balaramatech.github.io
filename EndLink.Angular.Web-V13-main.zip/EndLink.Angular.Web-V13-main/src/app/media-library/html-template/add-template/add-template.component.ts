import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { paths } from 'src/app/shared/constants';

@Component({
  selector: 'app-add-template',
  templateUrl: './add-template.component.html',
  styleUrls: ['./add-template.component.scss']
})
export class AddTemplateComponent implements OnInit {

  isUpdate: boolean = false;
  isCopy: boolean = false;
  id: number = 0;

  constructor(
    private route: ActivatedRoute
    , private router: Router) { }

  ngOnInit(): void {
    this.isUpdate = this.router.url.indexOf(paths.templateEdit) > -1;
    this.isCopy = this.router.url.indexOf(paths.templateCopy) > -1;

    this.route.params.subscribe(param => {
      if (param?.id) {
        this.id = param.id;
      }
    });
  }

  templateSaved(){
    this.router.navigate([paths.template]);
  }

  cancelled(){
    this.router.navigate([paths.template]);
  }

}
