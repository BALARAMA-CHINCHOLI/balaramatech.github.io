import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { HtmlTemplateRoutingModule } from './html-template-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { HtmlTemplateComponent } from './html-template.component';
import { AddTemplateComponent } from './add-template/add-template.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CategoryService } from 'src/app/services/category.service';


@NgModule({
  declarations: [HtmlTemplateComponent, AddTemplateComponent],
  imports: [
    CommonModule,
    SharedModule,
    FormsModule,
    ReactiveFormsModule,
    HtmlTemplateRoutingModule
  ],
  providers: [CategoryService]
})
export class HtmlTemplateModule { }
