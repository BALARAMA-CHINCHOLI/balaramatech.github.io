import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AddTemplateComponent } from './add-template/add-template.component';
import { HtmlTemplateComponent } from './html-template.component';

const routes: Routes = [
  {
    path : '',
    pathMatch: 'full',
    component: HtmlTemplateComponent
  },
  {
    path : 'add',
    component : AddTemplateComponent,
    data: { breadcrumb: 'Add HTML template', title: 'Add HTML template'}
  },
  {
    path : 'copy/:id',
    component : AddTemplateComponent,
    data: { breadcrumb: 'Copy HTML template', title: 'Copy HTML template'}
  },
  {
    path : 'edit/:id',
    component : AddTemplateComponent,
    data: { breadcrumb: 'Edit HTML template', title: 'Edit HTML template'}
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class HtmlTemplateRoutingModule { }
