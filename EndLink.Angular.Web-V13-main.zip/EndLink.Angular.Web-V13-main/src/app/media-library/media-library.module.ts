import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { MediaLibraryRoutingModule } from './media-library-routing.module';
import { MediaLibraryComponent } from './mediaLibrary.component';


@NgModule({
  declarations: [
    MediaLibraryComponent
  ],
  imports: [
    CommonModule,
    MediaLibraryRoutingModule
  ]
})
export class MediaLibraryModule { }
