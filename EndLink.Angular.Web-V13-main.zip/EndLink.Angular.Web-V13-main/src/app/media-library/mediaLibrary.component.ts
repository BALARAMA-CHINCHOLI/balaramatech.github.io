import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-mediaLibrary',
  templateUrl: './mediaLibrary.component.html',
  styleUrls: ['./mediaLibrary.component.scss']
})
export class MediaLibraryComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
