import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { AudioService } from 'src/app/services/audio.service';
import { Audio } from 'src/app/shared/models/audio';

@Component({
  selector: 'app-edit-audio',
  templateUrl: './edit-audio.component.html',
  styleUrls: ['./edit-audio.component.scss']
})
export class EditAudioComponent implements OnInit {

  submitted: boolean = false;

  constructor(private audioService: AudioService
    , private dialogRef: MatDialogRef<any>
    , @Inject(MAT_DIALOG_DATA) public data: Audio) { }

  ngOnInit(): void {
  }

  update(isValid) {
    this.submitted = true;

    if (!isValid) {
      return;
    }

    this.audioService.update(this.data).subscribe(res => {
      this.submitted = false;
      this.dialogRef.close(true);
    });
  }

}
