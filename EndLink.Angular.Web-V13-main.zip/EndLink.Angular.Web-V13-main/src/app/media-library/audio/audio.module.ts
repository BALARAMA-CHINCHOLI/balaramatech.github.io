import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { AudioRoutingModule } from './audio-routing.module';
import { SharedModule } from 'src/app/shared/shared.module';
import { AudioComponent } from './audio.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { EditAudioComponent } from './edit-audio/edit-audio.component';


@NgModule({
  declarations: [AudioComponent, EditAudioComponent],
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule,
    AudioRoutingModule,
    SharedModule
  ]
})
export class AudioModule { }
