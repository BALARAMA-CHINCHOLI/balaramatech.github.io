import { Component, OnDestroy, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AudioService } from 'src/app/services/audio.service';
import { ToasterService } from 'src/app/services/toaster.service';
import { ConfirmationComponent } from 'src/app/shared/components/confirmation/confirmation.component';
import { messages } from 'src/app/shared/constants';
import { SortingType } from 'src/app/shared/enums/sorting-type';
import { Audio } from 'src/app/shared/models/audio';
import { ListModel } from 'src/app/shared/models/list-model';
import { SearchFilter } from 'src/app/shared/models/search-filter';
import { ScrollerService } from '../../services/scroller-service.service';
import { EditAudioComponent } from './edit-audio/edit-audio.component';

@Component({
  selector: 'app-audio',
  templateUrl: './audio.component.html',
  styleUrls: ['./audio.component.scss']
})
export class AudioComponent implements OnInit, OnDestroy {

  filter: SearchFilter = {
    paging: {
      pageNumber: 1,
      pageSize: 10
    },
    sorting: {
      order: SortingType.Asc,
      sortBy: 'Name'
    }
  };

  list: ListModel<Audio> = {
    list: [],
    hasNextPage: false
  };

  list$: any;
  scroller$: any;
  acceptedFiles = 'audio/basic, audio/L24, audio/mp4, audio/mpeg, audio/ogg, audio/vnd.rn-realaudio, audio/vnd.wave, audio/3gpp, audio/3gpp2, audio/ac3, audio/webm, audio/amr-nb, audio/amr';
  constructor(private router: Router
    , private scroller: ScrollerService
    , private audioService: AudioService
    , private toaster: ToasterService
    , private dialog: MatDialog) { }

  private header_data: any[] = [
    { title: "Name", type: "text", prop: 'name', sortProp: 'name', sort: true, isFilter: true, isAsc: false, isDes: false },
    { title: "Description", type: "text", prop: 'description', sortProp: 'description', sort: true, isFilter: true, isAsc: false, isDes: false },
    { title: "Preview", type: "audio", prop: 'audioUrl', sortProp: 'audioUrl', sort: false, isFilter: true, isAsc: false, isDes: false }
  ];

  tableData: any = {
    headerData: [],
    rowData: [],
    noRecordFound: true
  }

  ngOnInit() {
    this.tableData.noRecordFound = true;
    this.tableData.headerData = this.header_data;
    this.scroller$ = this.scroller.scroller$.subscribe(res => {
      if (this.list.hasNextPage) {
        this.filter.paging.pageNumber++;
        this.getList();
      }
    });

    this.getList();
  }

  tableActions(event) {
    switch (event.action) {
      case 'edit': {
        let editAudio = this.dialog.open(EditAudioComponent, {
          width: '30vw',
          data: Object.assign({}, event.rowData)
        });
        editAudio.afterClosed().subscribe(() => {
          this.filter.paging.pageNumber = 1;
          this.getList();
        });
        break;
      }
      case 'sort': {
        this.filter.paging.pageNumber = 1;
        this.filter.sorting = {
          order: event.filterData.sortOrder,
          sortBy: event.filterData.sortHeader
        };
        this.getList();
        break;
      }
      case 'delete': {
        const item = this.list.list.find(x => x.id == event.rowData.id);

        if (item == null) {
          return;
        }
        let del = this.dialog.open(ConfirmationComponent, {
          data: {

            message: 'Are you sure you want to delete this Audio ?',
            icon: 'delete',
            action: 'Delete',

          },
        });
        del.afterClosed().subscribe((result) => {
          if (result) {
            this.delete(item.id);
            // this.filter.paging.pageNumber = 1;
          // this.getList();
          } else {
            //event.rowData.id = !event.rowData.id;
          }
        });
        // this.audioService.delete(item.id).subscribe(() => {
        //   this.toaster.showSuccessMessage(messages.audioDeleteSuccess);
        //   this.filter.paging.pageNumber = 1;
        //   this.getList();
        // });
        break;
      }
      case 'search': {
        this.filter.SearchText = event.filterData.globalSearch;
        this.filter.paging.pageNumber = 1;
        this.getList();
        break;
      }
      case 'clear': {
        this.filter.SearchText = '';
        this.filter.paging.pageNumber = 1;
        this.getList();
        break;
      }
    }
  }

  public delete(id: number) {
    this.audioService.delete(id).subscribe(() => {
      this.filter.paging.pageNumber = 1;
      this.getList();
      
    });
  }

  getList() {
    this.list$ = this.audioService.list(this.filter).subscribe((data) => {

      if (this.filter.paging.pageNumber == 1) {
        this.list = data.responseObject;
        this.tableData.rowData = [];
      } else {
        data.responseObject.list.forEach(item => {
          this.list.list.push(item);
        });
      }

      this.tableData.rowData = this.list.list;

      if (this.list.list.length > 0) {
        this.tableData.noRecordFound = false;
      }
      this.list.hasNextPage = data.responseObject.list && data.responseObject.list.length > 0;
    });
  }

  public changeStatus(item: Audio) {
    this.audioService.update(item).subscribe(() => {
      this.toaster.showSuccessMessage(messages.statusChangedSuccess);
    });
  }

  onFileSelected(event) {
    const file: File = event.target.files[0];
    const fileName = event.target.files[0].name;
    const ext = file.type;
    const allowedExtensions = this.acceptedFiles.split(",");

    if (allowedExtensions.find(x => x.trim() == ext) == null) {
      this.toaster.showErrorMessage("Only files with extension " + this.acceptedFiles + " are allowed.");
      return;
    }

    if (file) {
      this.audioService.upload(file).subscribe(() => {
        this.toaster.showSuccessMessage(messages.audioUploadSuccess);
        this.filter.paging.pageNumber = 1;
        this.getList();
      });
    }
  }

  public ngOnDestroy() {
    this.list$.unsubscribe();
    this.scroller$.unsubscribe();
  }

}
